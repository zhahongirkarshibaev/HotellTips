package com.hoteltips.data.security

import com.hoteltips.data.local.dao.AuditDao
import com.hoteltips.data.local.entity.AuditLogEntity
import kotlinx.coroutines.CancellationException
import java.time.Instant

/** Журнал событий безопасности и финансовых операций. Секреты в журнал не пишутся. */
class AuditLogger(private val dao: AuditDao) {

    suspend fun log(userId: Long?, action: String, details: String = "") {
        try {
            dao.insert(
                AuditLogEntity(
                    userId = userId,
                    action = action,
                    details = details.take(300),
                    createdAt = Instant.now().toEpochMilli()
                )
            )
            dao.prune()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Сбой журнала не должен ломать основную операцию.
        }
    }
}
