package com.hoteltips.data.security

import android.content.Context
import android.util.Base64
import java.io.File
import java.security.SecureRandom

/**
 * Пароль от зашифрованной БД: 256 случайных бит, сгенерированных при первом запуске.
 * В файле лежит только их шифртекст (AES-GCM, ключ в Android Keystore) —
 * без Keystore этого устройства ни файл ключа, ни сама БД не читаются.
 * Файл — в noBackupFilesDir, то есть не попадает в резервные копии.
 */
class DatabaseKeyProvider(
    private val context: Context,
    private val keystore: KeystoreManager,
    private val databaseName: String
) {
    private val keyFile = File(context.noBackupFilesDir, "db.key")

    fun getOrCreate(): ByteArray {
        if (keyFile.exists()) {
            try {
                return keystore.decrypt(keyFile.readBytes())
            } catch (e: Exception) {
                // Ключ Keystore недоступен (сброс защиты экрана, переустановка и т. п.).
                // Старую БД прочитать невозможно — удаляем и начинаем заново.
                keyFile.delete()
                context.deleteDatabase(databaseName)
            }
        }
        val raw = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val passphrase = Base64.encodeToString(raw, Base64.NO_WRAP).toByteArray(Charsets.UTF_8)
        keyFile.writeBytes(keystore.encrypt(passphrase))
        return passphrase
    }
}
