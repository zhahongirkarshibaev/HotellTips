package com.hoteltips.domain.model

import androidx.annotation.StringRes
import com.hoteltips.R

/**
 * Origin market selected only to preview which payment choices a tourist would see.
 * This is not verified nationality and is not used for real payment routing.
 */
enum class TouristCountry(
    val code: String,
    val flag: String,
    @StringRes val labelRes: Int
) {
    RUSSIA("RU", "🇷🇺", R.string.payment_country_russia),
    CHINA("CN", "🇨🇳", R.string.payment_country_china),
    ITALY("IT", "🇮🇹", R.string.payment_country_italy),
    UNITED_STATES("US", "🇺🇸", R.string.payment_country_us)
}

/** Display-only methods offered by the simulator. No card or wallet credentials are collected. */
enum class SimulatedPaymentMethod(
    val code: String,
    @StringRes val labelRes: Int,
    private val markets: Set<TouristCountry>
) {
    MIR("mir", R.string.payment_method_mir, setOf(TouristCountry.RUSSIA)),
    SBP("sbp", R.string.payment_method_sbp, setOf(TouristCountry.RUSSIA)),
    ALIPAY("alipay", R.string.payment_method_alipay, setOf(TouristCountry.CHINA)),
    WECHAT_PAY("wechat_pay", R.string.payment_method_wechat_pay, setOf(TouristCountry.CHINA)),
    UNIONPAY("unionpay", R.string.payment_method_unionpay, setOf(TouristCountry.CHINA)),
    BANK_CARD("bank_card", R.string.payment_method_bank_card, setOf(TouristCountry.ITALY, TouristCountry.UNITED_STATES)),
    PAYPAL("paypal", R.string.payment_method_paypal, setOf(TouristCountry.ITALY, TouristCountry.UNITED_STATES)),
    MOBILE_WALLET("mobile_wallet", R.string.payment_method_mobile_wallet, setOf(TouristCountry.ITALY, TouristCountry.UNITED_STATES));

    fun supports(country: TouristCountry): Boolean = country in markets

    companion object {
        fun forCountry(country: TouristCountry): List<SimulatedPaymentMethod> =
            entries.filter { it.supports(country) }
    }
}

/** Selectable test result lets the team test success/failure UI before a provider is chosen. */
enum class PaymentSimulationOutcome(@StringRes val labelRes: Int) {
    APPROVED(R.string.payment_outcome_success),
    DECLINED(R.string.payment_outcome_declined),
    CANCELLED(R.string.payment_outcome_cancelled)
}

enum class PaymentStatus {
    APPROVED,
    DECLINED,
    CANCELLED
}

data class PaymentRequest(
    /** Amount is always denominated in the hotel's currency, not the tourist's home currency. */
    val amount: Long,
    val currencyCode: String,
    val description: String,
    val touristCountry: TouristCountry,
    val method: SimulatedPaymentMethod,
    val outcome: PaymentSimulationOutcome
)

data class PaymentReceipt(
    val reference: String,
    val status: PaymentStatus,
    val amount: Long,
    val currencyCode: String,
    val touristCountry: TouristCountry,
    val method: SimulatedPaymentMethod,
    /** Required explicitly so a future provider adapter cannot silently inherit demo status. */
    val isSimulation: Boolean
)

data class SendTipResult(
    val receipt: PaymentReceipt,
    /** True only when an approved simulated payment also resulted in a tip ledger record. */
    val tipRecorded: Boolean
)
