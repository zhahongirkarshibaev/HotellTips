package com.hoteltips.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.hoteltips.data.local.dao.AuditDao
import com.hoteltips.data.local.dao.EmployeeDao
import com.hoteltips.data.local.dao.FeedbackDao
import com.hoteltips.data.local.dao.HotelDao
import com.hoteltips.data.local.dao.TipDao
import com.hoteltips.data.local.dao.UserDao
import com.hoteltips.data.local.dao.WithdrawalDao
import com.hoteltips.data.local.entity.AuditLogEntity
import com.hoteltips.data.local.entity.EmployeeEntity
import com.hoteltips.data.local.entity.FeedbackEntity
import com.hoteltips.data.local.entity.HotelEntity
import com.hoteltips.data.local.entity.TipEntity
import com.hoteltips.data.local.entity.UserEntity
import com.hoteltips.data.local.entity.WithdrawalEntity

@Database(
    entities = [
        HotelEntity::class,
        UserEntity::class,
        EmployeeEntity::class,
        TipEntity::class,
        FeedbackEntity::class,
        WithdrawalEntity::class,
        AuditLogEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun hotelDao(): HotelDao
    abstract fun userDao(): UserDao
    abstract fun employeeDao(): EmployeeDao
    abstract fun tipDao(): TipDao
    abstract fun feedbackDao(): FeedbackDao
    abstract fun withdrawalDao(): WithdrawalDao
    abstract fun auditDao(): AuditDao

    companion object {
        const val NAME = "hotel_tips_secure.db"
        const val LEGACY_NAME = "hotel_tips.db"
    }
}
