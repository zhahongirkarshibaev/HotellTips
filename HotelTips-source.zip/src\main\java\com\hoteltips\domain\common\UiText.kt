package com.hoteltips.domain.common

import android.content.Context
import androidx.annotation.StringRes

/**
 * Текст, который переводится в момент показа, а не в момент создания:
 * ошибки из domain/data хранят id ресурса и аргументы, а интерфейс подставляет
 * строку на языке, выбранном пользователем.
 */
sealed interface UiText {
    data class Res(@StringRes val id: Int, val args: List<Any> = emptyList()) : UiText
    data class Plain(val value: String) : UiText

    fun asString(context: Context): String = when (this) {
        is Res -> context.getString(id, *args.toTypedArray())
        is Plain -> value
    }

    companion object {
        fun res(@StringRes id: Int, vararg args: Any): UiText = Res(id, args.toList())
    }
}
