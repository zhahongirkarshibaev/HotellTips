package com.hoteltips.data.repository

import android.content.Context
import android.util.Base64
import com.hoteltips.data.security.KeystoreManager
import com.hoteltips.domain.model.User
import com.hoteltips.domain.repository.SessionRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Сессия хранится в зашифрованном виде (AES-GCM, ключ в Keystore) вместе со сроком действия.
 * Подменить id пользователя в файле настроек нельзя: без ключа Keystore не создать
 * валидный шифртекст, а повреждённый или истёкший токен просто отбрасывается.
 */
class SessionRepositoryImpl(
    context: Context,
    private val keystore: KeystoreManager
) : SessionRepository {

    private val prefs = context.getSharedPreferences("session", Context.MODE_PRIVATE)
    private val state = MutableStateFlow<Long?>(loadStoredUserId())

    override val userId: StateFlow<Long?> = state.asStateFlow()

    @Volatile
    private var current: User? = null

    override val currentUser: User? get() = current

    override fun start(user: User) {
        val expiresAt = System.currentTimeMillis() + SESSION_TTL_MS
        val payload = "${user.id}:$expiresAt".toByteArray(Charsets.UTF_8)
        val encrypted = Base64.encodeToString(keystore.encrypt(payload), Base64.NO_WRAP)
        prefs.edit().putString(KEY_TOKEN, encrypted).apply()
        current = user
        state.value = user.id
    }

    override fun attach(user: User) {
        current = user
    }

    override fun end() {
        prefs.edit().remove(KEY_TOKEN).apply()
        current = null
        state.value = null
    }

    private fun loadStoredUserId(): Long? {
        val raw = prefs.getString(KEY_TOKEN, null) ?: return null
        return try {
            val text = String(keystore.decrypt(Base64.decode(raw, Base64.NO_WRAP)), Charsets.UTF_8)
            val (id, expiresAt) = text.split(':').map { it.toLong() }
            if (System.currentTimeMillis() > expiresAt) {
                prefs.edit().remove(KEY_TOKEN).apply()
                null
            } else {
                id
            }
        } catch (e: Exception) {
            prefs.edit().remove(KEY_TOKEN).apply()
            null
        }
    }

    private companion object {
        const val KEY_TOKEN = "token"
        /** Сессия живёт 12 часов, затем нужен повторный вход. */
        const val SESSION_TTL_MS = 12L * 60 * 60 * 1000
    }
}
