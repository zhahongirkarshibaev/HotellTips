package com.hoteltips.util

import android.content.Context
import android.content.res.Configuration
import com.hoteltips.domain.model.AppLanguage
import java.util.Locale

/**
 * Язык интерфейса хранится в настройках приложения и применяется при создании Activity
 * (см. MainActivity.attachBaseContext). Смена языка = сохранить + пересоздать Activity;
 * ViewModel при этом сохраняются, поэтому введённые данные не теряются.
 */
object LocaleHelper {
    private const val PREFS = "app_settings"
    private const val KEY_LANGUAGE = "language"

    fun current(context: Context): AppLanguage {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LANGUAGE, null)
        AppLanguage.fromCode(saved)?.let { return it }
        // Первый запуск: берём язык телефона, если он поддерживается, иначе английский.
        return AppLanguage.fromCode(Locale.getDefault().language) ?: AppLanguage.ENGLISH
    }

    fun save(context: Context, language: AppLanguage) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_LANGUAGE, language.code).apply()
    }

    fun wrap(base: Context): Context {
        val locale = Locale.forLanguageTag(current(base).code)
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        return base.createConfigurationContext(config)
    }
}
