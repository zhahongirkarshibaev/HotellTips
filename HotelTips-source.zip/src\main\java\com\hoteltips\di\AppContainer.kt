package com.hoteltips.di

import android.content.Context
import android.util.Base64
import com.hoteltips.data.local.AppDatabase
import com.hoteltips.data.local.DatabaseFactory
import com.hoteltips.data.payment.SimulatedPaymentGateway
import com.hoteltips.data.remote.TipApiClient
import com.hoteltips.data.repository.AuthRepositoryImpl
import com.hoteltips.data.repository.EmployeeRepositoryImpl
import com.hoteltips.data.repository.FeedbackRepositoryImpl
import com.hoteltips.data.repository.HotelRepositoryImpl
import com.hoteltips.data.repository.SessionRepositoryImpl
import com.hoteltips.data.repository.TipRepositoryImpl
import com.hoteltips.data.security.AuditLogger
import com.hoteltips.data.security.KeystoreManager
import com.hoteltips.data.security.Ledger
import com.hoteltips.data.security.PasswordHasher
import com.hoteltips.data.security.QrSigner
import com.hoteltips.data.security.RecordSigner
import com.hoteltips.data.security.SessionAccessGuard
import com.hoteltips.data.translation.MlKitTranslationService
import com.hoteltips.demo.DemoData
import com.hoteltips.domain.repository.AuthRepository
import com.hoteltips.domain.repository.EmployeeRepository
import com.hoteltips.domain.repository.FeedbackRepository
import com.hoteltips.domain.repository.HotelRepository
import com.hoteltips.domain.repository.PaymentGateway
import com.hoteltips.domain.repository.SessionRepository
import com.hoteltips.domain.repository.TipRepository
import com.hoteltips.domain.repository.TranslationService
import com.hoteltips.domain.model.AppLanguage
import com.hoteltips.domain.security.AccessGuard
import com.hoteltips.domain.usecase.CreateInitialAdminUseCase
import com.hoteltips.domain.usecase.EnterGuestFromQrUseCase
import com.hoteltips.domain.usecase.ObserveEmployeeDashboardUseCase
import com.hoteltips.domain.usecase.RegisterGuestUseCase
import com.hoteltips.domain.usecase.SaveEmployeeUseCase
import com.hoteltips.domain.usecase.SendFeedbackUseCase
import com.hoteltips.domain.usecase.SendTipUseCase
import com.hoteltips.domain.usecase.WithdrawUseCase
import com.hoteltips.util.LocaleHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Ручной DI-контейнер: единственное место, где реализации связываются с интерфейсами.
 * Криптография (Keystore, хеширование, подписи) создаётся здесь и наружу не торчит.
 */
class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    // --- Безопасность ---
    private val keystore = KeystoreManager()
    private val passwordHasher by lazy { PasswordHasher(keystore) }
    private val recordSigner by lazy { RecordSigner(keystore) }
    val qrSigner by lazy { QrSigner(keystore) }

    val sessionRepository: SessionRepository = SessionRepositoryImpl(appContext, keystore)
    val accessGuard: AccessGuard = SessionAccessGuard(sessionRepository)

    // --- База данных (шифрованная) ---
    private val database: AppDatabase by lazy { DatabaseFactory.create(appContext, keystore) }
    private val audit by lazy { AuditLogger(database.auditDao()) }
    private val ledger by lazy {
        Ledger(database.tipDao(), database.withdrawalDao(), recordSigner)
    }

    // --- Репозитории ---
    val authRepository: AuthRepository by lazy {
        AuthRepositoryImpl(
            database.userDao(), database.employeeDao(), database.hotelDao(),
            passwordHasher, accessGuard, audit
        )
    }
    val hotelRepository: HotelRepository by lazy {
        HotelRepositoryImpl(database.hotelDao(), accessGuard, audit)
    }
    val employeeRepository: EmployeeRepository by lazy {
        EmployeeRepositoryImpl(database, passwordHasher, accessGuard, ledger, audit)
    }
    val tipRepository: TipRepository by lazy {
        TipRepositoryImpl(database, accessGuard, recordSigner, ledger, audit)
    }
    val feedbackRepository: FeedbackRepository by lazy {
        FeedbackRepositoryImpl(database, accessGuard, audit)
    }

    // --- Сервисы ---
    // Intentionally local-only until the owner supplies a payment provider API.
    val paymentGateway: PaymentGateway = SimulatedPaymentGateway()
    /** Клиент к FastAPI на Timeweb (72.56.89.200:8000). */
    val tipApiClient: TipApiClient by lazy { TipApiClient() }
    val translationService: TranslationService by lazy { MlKitTranslationService() }

    /** Текущий язык интерфейса — на нём гость пишет сообщения, на него переводятся чужие. */
    val currentLanguage: () -> AppLanguage = { LocaleHelper.current(appContext) }

    // --- Сценарии ---
    val observeEmployeeDashboard by lazy {
        ObserveEmployeeDashboardUseCase(employeeRepository, tipRepository, hotelRepository)
    }
    val sendTip by lazy { SendTipUseCase(tipRepository, paymentGateway, tipApiClient) }
    val sendFeedback by lazy { SendFeedbackUseCase(feedbackRepository) }
    val saveEmployee by lazy { SaveEmployeeUseCase(employeeRepository) }
    val registerGuest by lazy { RegisterGuestUseCase(authRepository) }
    /**
     * Стабильный идентификатор установки для QR-гостей.
     * Хранится только в зашифрованном виде (AES-GCM + Keystore).
     */
    private val qrInstallationKey: String by lazy {
        val prefs = appContext.getSharedPreferences("guest_qr_identity", Context.MODE_PRIVATE)
        val encrypted = prefs.getString("installation_key_enc", null)
        if (encrypted != null) {
            runCatching {
                String(keystore.decrypt(Base64.decode(encrypted, Base64.NO_WRAP)), Charsets.UTF_8)
            }.getOrNull()?.takeIf { it.isNotBlank() }?.let { return@lazy it }
        }
        val legacy = prefs.getString("installation_key", null)?.takeIf { it.isNotBlank() }
        val fresh = legacy ?: UUID.randomUUID().toString()
        val blob = Base64.encodeToString(keystore.encrypt(fresh.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        prefs.edit()
            .putString("installation_key_enc", blob)
            .remove("installation_key")
            .apply()
        fresh
    }
    val enterGuestFromQr by lazy { EnterGuestFromQrUseCase(authRepository, qrInstallationKey) }
    val createInitialAdmin by lazy { CreateInitialAdminUseCase(authRepository) }
    val withdraw by lazy { WithdrawUseCase(authRepository, tipRepository) }

    /** Вызывается один раз при старте. В release ничего не создаёт. */
    suspend fun prepare() = withContext(Dispatchers.IO) {
        // Открытие зашифрованной БД и хеширование — не на главном потоке.
        DemoData.seedIfEmpty(database, passwordHasher, recordSigner)
    }
}
