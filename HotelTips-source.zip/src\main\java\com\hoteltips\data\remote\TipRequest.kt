package com.hoteltips.data.remote

data class TipRequest(
    val hotel_id: String,
    val employee_id: String? = null,
    val room_number: String? = null,
    val amount: Double,
    val currency: String = "USD",
    val guest_name: String? = null,
    val message: String? = null
)