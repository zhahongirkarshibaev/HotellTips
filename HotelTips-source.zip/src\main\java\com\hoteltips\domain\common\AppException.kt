package com.hoteltips.domain.common

import androidx.annotation.StringRes
import com.hoteltips.R
import kotlinx.coroutines.CancellationException

/** Ошибка с текстом для пользователя (ресурс + аргументы, переводится при показе). */
class AppException(val uiText: UiText, cause: Throwable? = null) : Exception(cause) {
    constructor(@StringRes id: Int, vararg args: Any) : this(UiText.Res(id, args.toList()), null)
}

/** Оборачивает блок в Result. Отмену корутины не глотает. */
suspend fun <T> safeCall(block: suspend () -> T): Result<T> =
    try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: AppException) {
        Result.failure(e)
    } catch (e: Exception) {
        Result.failure(AppException(UiText.Res(R.string.err_generic), e))
    }

fun Throwable.toUiText(): UiText = (this as? AppException)?.uiText ?: UiText.Res(R.string.err_generic)
