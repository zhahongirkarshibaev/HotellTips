package com.hoteltips.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.hoteltips.data.local.entity.AuditLogEntity
import com.hoteltips.data.local.entity.EmployeeEntity
import com.hoteltips.data.local.entity.EmployeeSummaryRow
import com.hoteltips.data.local.entity.FeedbackEntity
import com.hoteltips.data.local.entity.HotelEntity
import com.hoteltips.data.local.entity.TipEntity
import com.hoteltips.data.local.entity.UserEntity
import com.hoteltips.data.local.entity.WithdrawalEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HotelDao {
    @Insert
    suspend fun insert(hotel: HotelEntity): Long

    @Query("UPDATE hotels SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)

    @Query("DELETE FROM hotels WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM hotels WHERE id = :id")
    suspend fun findById(id: Long): HotelEntity?

    @Query("SELECT * FROM hotels WHERE id = :id")
    fun observeById(id: Long): Flow<HotelEntity?>

    @Query("SELECT * FROM hotels ORDER BY countryCode, cityCode, name COLLATE NOCASE")
    fun observeAll(): Flow<List<HotelEntity>>

    @Query("SELECT * FROM hotels WHERE cityCode = :cityCode AND name = :name COLLATE NOCASE LIMIT 1")
    suspend fun findByCityAndName(cityCode: String, name: String): HotelEntity?

    @Query("SELECT COUNT(*) FROM employees WHERE hotelId = :id")
    suspend fun countEmployees(id: Long): Int

    @Query("SELECT COUNT(*) FROM users WHERE hotelId = :id")
    suspend fun countGuests(id: Long): Int
}

@Dao
interface UserDao {
    @Insert
    suspend fun insert(user: UserEntity): Long

    @Update
    suspend fun update(user: UserEntity)

    @Query("SELECT * FROM users WHERE login = :login LIMIT 1")
    suspend fun findByLogin(login: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun findById(id: Long): UserEntity?

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT COUNT(*) FROM users")
    suspend fun count(): Int

    @Query("UPDATE users SET failedAttempts = :attempts, lockedUntil = :lockedUntil WHERE id = :id")
    suspend fun updateAttempts(id: Long, attempts: Int, lockedUntil: Long)

    @Query(
        "UPDATE users SET passwordHash = :hash, failedAttempts = 0, lockedUntil = 0 WHERE id = :id"
    )
    suspend fun updatePasswordHash(id: Long, hash: String)
}

@Dao
interface EmployeeDao {
    @Insert
    suspend fun insert(employee: EmployeeEntity): Long

    @Update
    suspend fun update(employee: EmployeeEntity)

    @Query("SELECT * FROM employees WHERE id = :id")
    suspend fun findById(id: Long): EmployeeEntity?

    @Query("SELECT * FROM employees WHERE userId = :userId")
    fun observeByUserId(userId: Long): Flow<EmployeeEntity?>

    @Query(
        "SELECT * FROM employees WHERE hotelId = :hotelId AND :room BETWEEN roomFrom AND roomTo LIMIT 1"
    )
    fun observeByRoom(hotelId: Long, room: Int): Flow<EmployeeEntity?>

    @Query(
        "SELECT * FROM employees WHERE hotelId = :hotelId AND :room BETWEEN roomFrom AND roomTo LIMIT 1"
    )
    suspend fun findByRoom(hotelId: Long, room: Int): EmployeeEntity?

    /** Сотрудник того же отеля (кроме [excludeId]), чей диапазон комнат пересекается с [from]..[to]. */
    @Query(
        "SELECT * FROM employees WHERE hotelId = :hotelId AND id != :excludeId " +
            "AND roomFrom <= :to AND roomTo >= :from LIMIT 1"
    )
    suspend fun findOverlapping(hotelId: Long, from: Int, to: Int, excludeId: Long): EmployeeEntity?

    @Query(
        """
        SELECT e.*,
               COALESCE((SELECT SUM(t.amount) FROM tips t WHERE t.employeeId = e.id), 0) AS totalTips,
               (SELECT COUNT(*) FROM tips t WHERE t.employeeId = e.id) AS tipsCount,
               (SELECT COUNT(*) FROM feedback f
                  WHERE f.employeeId = e.id AND f.type = 'COMPLAINT') AS complaintsCount
        FROM employees e
        ORDER BY e.fullName
        """
    )
    fun observeSummaries(): Flow<List<EmployeeSummaryRow>>
}

@Dao
interface TipDao {
    @Insert
    suspend fun insert(tip: TipEntity): Long

    @Query("SELECT * FROM tips WHERE employeeId = :employeeId ORDER BY createdAt DESC")
    fun observeForEmployee(employeeId: Long): Flow<List<TipEntity>>

    @Query("SELECT * FROM tips WHERE employeeId = :employeeId")
    suspend fun getAllForEmployee(employeeId: Long): List<TipEntity>

    @Query("SELECT COUNT(*) FROM tips WHERE guestUserId = :guestId AND createdAt >= :since")
    suspend fun countByGuestSince(guestId: Long, since: Long): Int

    @Query(
        "SELECT COALESCE(SUM(amount), 0) FROM tips WHERE guestUserId = :guestId AND createdAt >= :since"
    )
    suspend fun sumByGuestSince(guestId: Long, since: Long): Long
}

@Dao
interface FeedbackDao {
    @Insert
    suspend fun insert(feedback: FeedbackEntity): Long

    @Query("SELECT * FROM feedback WHERE employeeId = :employeeId ORDER BY createdAt DESC")
    fun observeForEmployee(employeeId: Long): Flow<List<FeedbackEntity>>

    @Query("SELECT COUNT(*) FROM feedback WHERE guestUserId = :guestId AND createdAt >= :since")
    suspend fun countByGuestSince(guestId: Long, since: Long): Int
}

@Dao
interface WithdrawalDao {
    @Insert
    suspend fun insert(withdrawal: WithdrawalEntity): Long

    @Query("SELECT * FROM withdrawals WHERE employeeId = :employeeId")
    fun observeForEmployee(employeeId: Long): Flow<List<WithdrawalEntity>>

    @Query("SELECT * FROM withdrawals WHERE employeeId = :employeeId")
    suspend fun getAllForEmployee(employeeId: Long): List<WithdrawalEntity>
}

@Dao
interface AuditDao {
    @Insert
    suspend fun insert(entry: AuditLogEntity): Long

    /** Храним последние 5000 записей. */
    @Query(
        "DELETE FROM audit_log WHERE id <= (SELECT MAX(id) FROM audit_log) - 5000"
    )
    suspend fun prune()
}
