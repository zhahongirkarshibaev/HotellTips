package com.hoteltips.domain.usecase

import com.hoteltips.domain.model.DayTips
import com.hoteltips.domain.model.Employee
import com.hoteltips.domain.model.EmployeeDashboard
import com.hoteltips.domain.model.Hotel
import com.hoteltips.domain.model.Tip
import java.time.Clock
import java.time.LocalDate

/** Чистая функция без побочных эффектов — легко тестируется. */
object DashboardCalculator {

    /** [tips] — от новых к старым. */
    fun build(
        employee: Employee,
        hotel: Hotel?,
        tips: List<Tip>,
        withdrawn: Long,
        clock: Clock
    ): EmployeeDashboard {
        val zone = clock.zone
        val today = LocalDate.now(clock)

        val sumByDate: Map<LocalDate, Long> = tips
            .groupBy { it.createdAt.atZone(zone).toLocalDate() }
            .mapValues { (_, list) -> list.sumOf { it.amount } }

        fun sumLast(days: Int): Long {
            var total = 0L
            for (offset in 0 until days) {
                total += sumByDate[today.minusDays(offset.toLong())] ?: 0L
            }
            return total
        }

        val week = (6 downTo 0).map { offset ->
            val date = today.minusDays(offset.toLong())
            DayTips(date, sumByDate[date] ?: 0L)
        }

        return EmployeeDashboard(
            employee = employee,
            hotel = hotel,
            available = tips.sumOf { it.amount } - withdrawn,
            today = sumLast(1),
            last7Days = sumLast(7),
            last30Days = sumLast(30),
            week = week,
            recentTips = tips.take(50)
        )
    }
}
