package com.hoteltips.ui.employee

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hoteltips.R
import com.hoteltips.domain.common.UiText
import com.hoteltips.domain.common.toUiText
import com.hoteltips.domain.model.AppLanguage
import com.hoteltips.domain.model.EmployeeDashboard
import com.hoteltips.domain.model.Feedback
import com.hoteltips.domain.repository.FeedbackRepository
import com.hoteltips.domain.repository.TranslationService
import com.hoteltips.domain.usecase.ObserveEmployeeDashboardUseCase
import com.hoteltips.domain.usecase.WithdrawUseCase
import com.hoteltips.ui.common.TranslationUi
import com.hoteltips.util.toMoney
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EmployeeUiState(
    val isLoading: Boolean = true,
    /** null после загрузки = профиль сотрудника удалён администратором. */
    val dashboard: EmployeeDashboard? = null,
    val feedback: List<Feedback> = emptyList(),
    val translations: Map<String, TranslationUi> = emptyMap(),
    val isWithdrawing: Boolean = false
)

private data class LocalState(
    val translations: Map<String, TranslationUi> = emptyMap(),
    val isWithdrawing: Boolean = false
)

class EmployeeViewModel(
    userId: Long,
    observeDashboard: ObserveEmployeeDashboardUseCase,
    private val withdraw: WithdrawUseCase,
    private val feedbackRepository: FeedbackRepository,
    private val translator: TranslationService,
    private val currentLanguage: () -> AppLanguage
) : ViewModel() {

    private val local = MutableStateFlow(LocalState())
    private val _events = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = _events.receiveAsFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val state: StateFlow<EmployeeUiState> = observeDashboard(userId)
        .flatMapLatest { dashboard ->
            val feedbackFlow = if (dashboard == null) {
                flowOf(emptyList())
            } else {
                feedbackRepository.observeForEmployee(dashboard.employee.id)
            }
            combine(feedbackFlow, local) { feedback, loc ->
                EmployeeUiState(
                    isLoading = false,
                    dashboard = dashboard,
                    feedback = feedback,
                    translations = loc.translations,
                    isWithdrawing = loc.isWithdrawing
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), EmployeeUiState())

    /** Вывод требует пароль: проверяется повторно, даже если приложение уже разблокировано. */
    fun onWithdrawConfirmed(password: String) {
        val dashboard = state.value.dashboard ?: return
        if (local.value.isWithdrawing) return
        viewModelScope.launch {
            local.update { it.copy(isWithdrawing = true) }
            withdraw(dashboard.employee.id, password)
                .onSuccess {
                    _events.trySend(UiText.res(R.string.msg_withdrawn, it.toMoney(dashboard.currency)))
                }
                .onFailure { _events.trySend(it.toUiText()) }
            local.update { it.copy(isWithdrawing = false) }
        }
    }

    /**
     * [key] — уникальный ключ сообщения вместе с языком перевода, например "tip-5:ru":
     * при смене языка интерфейса старые переводы не подставляются.
     */
    fun onTranslateClick(key: String, text: String) {
        val current = local.value.translations[key]
        when {
            current?.loading == true -> return
            current?.text != null -> {
                updateTranslation(key) { it.copy(showing = !it.showing) }
            }
            else -> {
                updateTranslation(key) { TranslationUi(loading = true) }
                viewModelScope.launch {
                    translator.translate(text, currentLanguage())
                        .onSuccess { translated ->
                            updateTranslation(key) { TranslationUi(text = translated, showing = true) }
                        }
                        .onFailure {
                            updateTranslation(key) { TranslationUi() }
                            _events.trySend(it.toUiText())
                        }
                }
            }
        }
    }

    private fun updateTranslation(key: String, transform: (TranslationUi) -> TranslationUi) {
        local.update { loc ->
            val old = loc.translations[key] ?: TranslationUi()
            loc.copy(translations = loc.translations + (key to transform(old)))
        }
    }
}
