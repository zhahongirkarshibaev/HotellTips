package com.hoteltips.ui.guest

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hoteltips.R
import com.hoteltips.domain.common.UiText
import com.hoteltips.domain.common.toUiText
import com.hoteltips.domain.model.AppLanguage
import com.hoteltips.domain.model.Currency
import com.hoteltips.domain.model.Employee
import com.hoteltips.domain.model.FeedbackType
import com.hoteltips.domain.model.Hotel
import com.hoteltips.domain.model.PaymentReceipt
import com.hoteltips.domain.model.PaymentSimulationOutcome
import com.hoteltips.domain.model.PaymentStatus
import com.hoteltips.domain.model.SimulatedPaymentMethod
import com.hoteltips.domain.model.TouristCountry
import com.hoteltips.domain.model.User
import com.hoteltips.domain.repository.EmployeeRepository
import com.hoteltips.domain.repository.HotelRepository
import com.hoteltips.domain.usecase.SendFeedbackUseCase
import com.hoteltips.domain.usecase.SendTipUseCase
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GuestUiState(
    val isLoading: Boolean = true,
    val hotel: Hotel? = null,
    val employee: Employee? = null,
    val selectedPreset: Long? = null,
    val customAmount: String = "",
    val tipMessage: String = "",
    val feedbackType: FeedbackType = FeedbackType.WISH,
    val feedbackText: String = "",
    val isSendingTip: Boolean = false,
    val isSendingFeedback: Boolean = false,
    val paymentCountry: TouristCountry = TouristCountry.RUSSIA,
    val paymentMethod: SimulatedPaymentMethod = SimulatedPaymentMethod.MIR,
    val simulationOutcome: PaymentSimulationOutcome = PaymentSimulationOutcome.APPROVED,
    val lastPaymentReceipt: PaymentReceipt? = null
) {
    /** Валюта определяется страной отеля, в котором живёт гость. */
    val currency: Currency get() = hotel?.currency ?: Currency.VND

    /** Итоговая сумма: своя, если введена, иначе выбранная из быстрых. */
    val amount: Long?
        get() = if (customAmount.isNotBlank()) customAmount.toLongOrNull() else selectedPreset
}

class GuestViewModel(
    private val guest: User,
    employees: EmployeeRepository,
    hotels: HotelRepository,
    private val sendTip: SendTipUseCase,
    private val sendFeedback: SendFeedbackUseCase,
    private val currentLanguage: () -> AppLanguage
) : ViewModel() {

    private val _state = MutableStateFlow(GuestUiState())
    val state: StateFlow<GuestUiState> = _state.asStateFlow()

    private val _events = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = _events.receiveAsFlow()

    init {
        val hotelId = guest.hotelId
        val room = guest.roomNumber
        if (hotelId == null || room == null) {
            _state.update { it.copy(isLoading = false) }
        } else {
            viewModelScope.launch {
                combine(
                    hotels.observeById(hotelId),
                    employees.observeByRoom(hotelId, room)
                ) { hotel, employee -> hotel to employee }
                    .collect { (hotel, employee) ->
                        _state.update {
                            it.copy(
                                isLoading = false,
                                hotel = hotel,
                                employee = employee,
                                // Средняя из быстрых сумм выбрана по умолчанию.
                                selectedPreset = it.selectedPreset
                                    ?: if (it.customAmount.isBlank()) hotel?.currency?.presets?.getOrNull(1) else null
                            )
                        }
                    }
            }
        }
    }

    fun onPresetSelected(amount: Long) =
        _state.update { it.copy(selectedPreset = amount, customAmount = "", lastPaymentReceipt = null) }

    fun onCustomAmountChange(text: String) = _state.update {
        val digits = text.filter(Char::isDigit).take(12)
        it.copy(
            customAmount = digits,
            selectedPreset = if (digits.isEmpty()) it.selectedPreset else null,
            lastPaymentReceipt = null
        )
    }

    fun onPaymentCountryChange(country: TouristCountry) = _state.update {
        it.copy(
            paymentCountry = country,
            paymentMethod = SimulatedPaymentMethod.forCountry(country).first(),
            lastPaymentReceipt = null
        )
    }

    fun onPaymentMethodChange(method: SimulatedPaymentMethod) = _state.update {
        if (method.supports(it.paymentCountry)) {
            it.copy(paymentMethod = method, lastPaymentReceipt = null)
        } else it
    }

    fun onSimulationOutcomeChange(outcome: PaymentSimulationOutcome) = _state.update {
        it.copy(simulationOutcome = outcome, lastPaymentReceipt = null)
    }

    fun onTipMessageChange(text: String) = _state.update { it.copy(tipMessage = text.take(500)) }
    fun onFeedbackTypeChange(type: FeedbackType) = _state.update { it.copy(feedbackType = type) }
    fun onFeedbackTextChange(text: String) = _state.update { it.copy(feedbackText = text.take(500)) }

    fun onSendTip() {
        val s = _state.value
        val employee = s.employee ?: return
        val amount = s.amount
        if (s.isSendingTip) return
        if (amount == null) {
            _events.trySend(UiText.res(R.string.err_enter_amount))
            return
        }
        _state.update { it.copy(isSendingTip = true, lastPaymentReceipt = null) }
        viewModelScope.launch {
            // Tourist country/method select a DEMO flow only; amount remains in hotel currency.
            sendTip(
                guest = guest,
                employee = employee,
                amount = amount,
                message = s.tipMessage,
                languageCode = currentLanguage().code,
                currencyCode = s.currency.code,
                touristCountry = s.paymentCountry,
                paymentMethod = s.paymentMethod,
                simulationOutcome = s.simulationOutcome
            )
                .onSuccess { result ->
                    _state.update { st ->
                        st.copy(
                            tipMessage = if (result.tipRecorded) "" else st.tipMessage,
                            lastPaymentReceipt = result.receipt
                        )
                    }
                    when (result.receipt.status) {
                        PaymentStatus.APPROVED -> _events.trySend(
                            UiText.res(R.string.payment_sim_success_toast, result.receipt.reference)
                        )
                        PaymentStatus.DECLINED -> _events.trySend(
                            UiText.res(R.string.payment_sim_declined_toast, result.receipt.reference)
                        )
                        PaymentStatus.CANCELLED -> _events.trySend(
                            UiText.res(R.string.payment_sim_cancelled_toast, result.receipt.reference)
                        )
                    }
                }
                .onFailure { _events.trySend(it.toUiText()) }
            _state.update { it.copy(isSendingTip = false) }
        }
    }

    fun onSendFeedback() {
        val s = _state.value
        val employee = s.employee ?: return
        if (s.isSendingFeedback) return
        _state.update { it.copy(isSendingFeedback = true) }
        viewModelScope.launch {
            sendFeedback(guest, employee, s.feedbackType, s.feedbackText, currentLanguage().code)
                .onSuccess {
                    _state.update { st -> st.copy(feedbackText = "") }
                    _events.trySend(UiText.res(R.string.msg_feedback_sent))
                }
                .onFailure { _events.trySend(it.toUiText()) }
            _state.update { it.copy(isSendingFeedback = false) }
        }
    }
}
