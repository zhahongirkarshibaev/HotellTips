package com.hoteltips.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class TipApiClient(
    private val baseUrl: String = ApiConfig.BASE_URL,
    private val client: OkHttpClient = defaultClient()
) {
    suspend fun createTip(body: TipCreateRequest): Result<TipRemoteResponse> =
        withContext(Dispatchers.IO) {
            runCatching {
                val json = JSONObject()
                    .put("hotel_id", body.hotel_id)
                    .put("amount", body.amount)
                    .put("currency", body.currency)

                if (body.room_number != null) json.put("room_number", body.room_number)
                if (body.guest_name != null) json.put("guest_name", body.guest_name)
                if (body.message != null) json.put("message", body.message)
                if (body.employee_id != null) json.put("employee_id", body.employee_id)

                val request = Request.Builder()
                    .url("${baseUrl.trimEnd('/')}/tips/")
                    .post(json.toString().toRequestBody(JSON_MEDIA))
                    .header("Accept", "application/json")
                    .header("Content-Type", "application/json")
                    .header("X-API-Key", ApiConfig.API_KEY)
                    .build()

                client.newCall(request).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        error("Server ${response.code}: ${raw.take(400)}")
                    }
                    parseOne(raw)
                }
            }
        }

    /**
     * GET /tips/ — список с фильтрами (как на сервере).
     */
    suspend fun listTips(
        hotelId: String? = null,
        employeeId: String? = null,
        status: String? = null,
        limit: Int = 50,
        offset: Int = 0
    ): Result<List<TipRemoteResponse>> = withContext(Dispatchers.IO) {
        runCatching {
            val sb = StringBuilder("${baseUrl.trimEnd('/')}/tips/?limit=$limit&offset=$offset")
            if (hotelId != null) sb.append("&hotel_id=").append(hotelId)
            if (employeeId != null) sb.append("&employee_id=").append(employeeId)
            if (status != null) sb.append("&status=").append(status)

            val request = Request.Builder()
                .url(sb.toString())
                .get()
                .header("Accept", "application/json")
                .header("X-API-Key", ApiConfig.API_KEY)
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error("Server ${response.code}: ${raw.take(400)}")
                }
                val arr = JSONArray(raw)
                (0 until arr.length()).map { i -> parseOne(arr.getJSONObject(i).toString()) }
            }
        }
    }

    suspend fun healthCheck(): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            val request = Request.Builder()
                .url("${baseUrl.trimEnd('/')}/")
                .get()
                .build()
            client.newCall(request).execute().use { it.isSuccessful }
        }
    }

    private fun parseOne(raw: String): TipRemoteResponse {
        val o = JSONObject(raw)
        fun strOrNull(key: String): String? =
            if (o.isNull(key)) null
            else o.optString(key).takeIf { it.isNotEmpty() && it != "null" }

        return TipRemoteResponse(
            id = o.getInt("id"),
            hotel_id = o.getString("hotel_id"),
            room_number = strOrNull("room_number"),
            amount = o.getDouble("amount"),
            currency = o.getString("currency"),
            guest_name = strOrNull("guest_name"),
            message = strOrNull("message"),
            payment_status = o.getString("payment_status"),
            created_at = o.getString("created_at"),
            employee_id = strOrNull("employee_id")
        )
    }

    companion object {
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(ApiConfig.CONNECT_TIMEOUT_SEC, TimeUnit.SECONDS)
            .readTimeout(ApiConfig.READ_TIMEOUT_SEC, TimeUnit.SECONDS)
            .writeTimeout(ApiConfig.READ_TIMEOUT_SEC, TimeUnit.SECONDS)
            .build()
    }
}