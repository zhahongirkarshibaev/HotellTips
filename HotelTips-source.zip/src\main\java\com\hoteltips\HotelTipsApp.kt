package com.hoteltips

import android.app.Application
import com.hoteltips.di.AppContainer

class HotelTipsApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
