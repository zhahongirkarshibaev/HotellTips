package com.hoteltips.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hoteltips.di.AppContainer
import com.hoteltips.domain.model.Role
import com.hoteltips.ui.admin.AdminRoot
import com.hoteltips.ui.auth.AuthRoot
import com.hoteltips.ui.common.LoadingBox
import com.hoteltips.ui.common.vmFactory
import com.hoteltips.ui.employee.EmployeeRoot
import com.hoteltips.ui.guest.GuestRoot

@Composable
fun AppRoot(
    container: AppContainer,
    incomingQrCode: String? = null,
    onIncomingQrConsumed: () -> Unit = {}
) {
    val viewModel: MainViewModel = viewModel(factory = vmFactory { MainViewModel(container) })
    val state by viewModel.state.collectAsStateWithLifecycle()

    // A QR link must not silently replace an already authenticated administrator/employee.
    LaunchedEffect(incomingQrCode, state) {
        if (incomingQrCode != null && state is SessionState.LoggedIn) {
            onIncomingQrConsumed()
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        when (val s = state) {
            SessionState.Loading -> LoadingBox()
            SessionState.NeedsSetup -> AuthRoot(container, needsSetup = true)
            SessionState.LoggedOut -> AuthRoot(
                container,
                needsSetup = false,
                initialQrCode = incomingQrCode,
                onInitialQrHandled = onIncomingQrConsumed
            )
            is SessionState.LoggedIn -> when (s.user.role) {
                Role.ADMIN -> AdminRoot(container, onLogout = viewModel::logout)
                Role.EMPLOYEE -> EmployeeRoot(container, s.user, onLogout = viewModel::logout)
                Role.GUEST -> GuestRoot(container, s.user, onLogout = viewModel::logout)
            }
        }
    }
}
