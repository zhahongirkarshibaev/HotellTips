package com.hoteltips.domain.usecase

import com.hoteltips.domain.model.RoomQrPayload
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * Парсер QR номера TipHotel.
 * Принимается только подписанный формат с sig=.
 */
object RoomQrPayloadParser {
    private const val MAX_PAYLOAD_LENGTH = 4096

    private val hotelRegex = Regex(
        """(?i)(?:^|[?&#])[\"']?(?:hotelId|hotel_id|hotel)[\"']?\s*[=:]\s*[\"']?(\d+)"""
    )
    private val roomRegex = Regex(
        """(?i)(?:^|[?&#])[\"']?(?:roomNumber|room_number|roomNo|room_no|room)[\"']?\s*[=:]\s*[\"']?(\d+)"""
    )
    private val sigRegex = Regex(
        """(?i)(?:^|[?&#])[\"']?(?:sig|signature)[\"']?\s*[=:]\s*[\"']?([A-Za-z0-9_\-]+=*)"""
    )
    private val versionRegex = Regex(
        """(?i)(?:^|[?&#])[\"']?(?:v|version)[\"']?\s*[=:]\s*[\"']?(\d+)"""
    )

    fun parse(
        rawValue: String?,
        signatureVerifier: ((hotelId: Long, roomNumber: Int, signature: String) -> Boolean)?
    ): RoomQrPayload? {
        if (signatureVerifier == null) return null
        val raw = rawValue?.trim()?.takeIf { it.isNotEmpty() && it.length <= MAX_PAYLOAD_LENGTH }
            ?: return null
        val decoded = runCatching {
            URLDecoder.decode(raw, StandardCharsets.UTF_8.name())
        }.getOrDefault(raw)
        val candidates = listOf(raw, decoded).distinct()

        for (candidate in candidates) {
            val hotelId = hotelRegex.find(candidate)?.groupValues?.getOrNull(1)?.toLongOrNull()
            val roomNumber = roomRegex.find(candidate)?.groupValues?.getOrNull(1)?.toIntOrNull()
            val signature = sigRegex.find(candidate)?.groupValues?.getOrNull(1)
            val version = versionRegex.find(candidate)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 1

            if (hotelId == null || hotelId <= 0L) continue
            if (roomNumber == null || roomNumber !in 1..999_999) continue
            if (signature.isNullOrBlank()) continue
            if (version != 1) continue

            if (!signatureVerifier(hotelId, roomNumber, signature)) continue

            return RoomQrPayload(hotelId = hotelId, roomNumber = roomNumber)
        }
        return null
    }

    fun parse(rawValue: String?): RoomQrPayload? = parse(rawValue, null)
}
