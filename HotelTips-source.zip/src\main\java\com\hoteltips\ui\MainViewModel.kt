package com.hoteltips.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hoteltips.di.AppContainer
import com.hoteltips.domain.model.User
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn

sealed interface SessionState {
    data object Loading : SessionState

    /** Первый запуск: пользователей ещё нет, нужно создать администратора. */
    data object NeedsSetup : SessionState
    data object LoggedOut : SessionState
    data class LoggedIn(val user: User) : SessionState
}

/** Следит за сессией и решает, что показывать: настройку, вход или одну из трёх ролей. */
class MainViewModel(private val container: AppContainer) : ViewModel() {

    @OptIn(ExperimentalCoroutinesApi::class)
    val state: StateFlow<SessionState> = flow {
        container.prepare()
        emitAll(
            container.sessionRepository.userId.mapLatest { id ->
                when {
                    id == null ->
                        if (container.authRepository.hasAnyUser()) SessionState.LoggedOut
                        else SessionState.NeedsSetup
                    else -> {
                        // Роль и права всегда берём из БД, а не из сохранённой сессии.
                        val user = container.authRepository.getUser(id)
                        if (user == null) {
                            container.sessionRepository.end()
                            SessionState.LoggedOut
                        } else {
                            container.sessionRepository.attach(user)
                            SessionState.LoggedIn(user)
                        }
                    }
                }
            }
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, SessionState.Loading)

    fun logout() = container.sessionRepository.end()
}
