package com.hoteltips.domain.security

import com.hoteltips.domain.model.Role
import com.hoteltips.domain.model.User

/**
 * Единая точка проверки прав. Каждая операция, которая читает или меняет чужие данные
 * либо деньги, обязана пройти через неё — независимо от того, что показывает интерфейс.
 */
interface AccessGuard {
    fun currentUserOrNull(): User?

    /** Текущий вошедший пользователь или AppException. */
    fun requireUser(): User

    /** Текущий пользователь с одной из ролей [roles] или AppException. */
    fun requireRole(vararg roles: Role): User
}
