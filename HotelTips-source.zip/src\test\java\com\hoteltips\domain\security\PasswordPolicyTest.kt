package com.hoteltips.domain.security

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class PasswordPolicyTest {

    @Test
    fun acceptsStrongPassword() {
        assertNull(PasswordPolicy.validate("Lotus2026!bay", "man"))
        assertNull(PasswordPolicy.validate("Tr0pic@lSea9", null))
    }

    @Test
    fun rejectsShortPassword() {
        assertNotNull(PasswordPolicy.validate("Ab1!xyz", null))
    }

    @Test
    fun rejectsPasswordWithoutDigit() {
        assertNotNull(PasswordPolicy.validate("OnlyLetters!", null))
    }

    @Test
    fun rejectsPasswordWithoutLetter() {
        assertNotNull(PasswordPolicy.validate("1234567890!", null))
    }

    @Test
    fun rejectsPasswordWithoutUpper() {
        assertNotNull(PasswordPolicy.validate("lotus2026!bay", null))
    }

    @Test
    fun rejectsPasswordWithoutLower() {
        assertNotNull(PasswordPolicy.validate("LOTUS2026!BAY", null))
    }

    @Test
    fun rejectsPasswordWithoutSpecial() {
        assertNotNull(PasswordPolicy.validate("Lotus2026bay", null))
    }

    @Test
    fun rejectsPasswordEqualToLogin() {
        assertNotNull(PasswordPolicy.validate("Tanaka123!", "Tanaka123!"))
    }

    @Test
    fun rejectsCommonPassword() {
        assertNotNull(PasswordPolicy.validate("admin123", null))
        assertNotNull(PasswordPolicy.validate("Password1", null))
        assertNotNull(PasswordPolicy.validate("admin@123", null))
        assertNotNull(PasswordPolicy.validate("password12", null))
        assertNotNull(PasswordPolicy.validate("Admin12345", null))
    }
}
