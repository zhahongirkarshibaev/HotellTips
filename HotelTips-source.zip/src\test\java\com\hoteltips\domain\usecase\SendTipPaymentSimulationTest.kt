package com.hoteltips.domain.usecase

import com.hoteltips.data.payment.SimulatedPaymentGateway
import com.hoteltips.domain.model.Employee
import com.hoteltips.domain.model.NewTip
import com.hoteltips.domain.model.PaymentSimulationOutcome
import com.hoteltips.domain.model.PaymentStatus
import com.hoteltips.domain.model.SimulatedPaymentMethod
import com.hoteltips.domain.model.Tip
import com.hoteltips.domain.model.TouristCountry
import com.hoteltips.domain.model.User
import com.hoteltips.domain.model.Role
import com.hoteltips.domain.repository.TipRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SendTipPaymentSimulationTest {

    @Test
    fun approvedSimulationRecordsTipInHotelCurrency() = runBlocking {
        val repo = RecordingTipRepository()
        val useCase = SendTipUseCase(repo, SimulatedPaymentGateway(responseDelayMillis = 0))

        val result = useCase(
            guest = guest,
            employee = employee,
            amount = 50_000L,
            message = "Thank you",
            languageCode = "en",
            currencyCode = "VND",
            touristCountry = TouristCountry.CHINA,
            paymentMethod = SimulatedPaymentMethod.ALIPAY,
            simulationOutcome = PaymentSimulationOutcome.APPROVED
        ).getOrThrow()

        assertEquals(PaymentStatus.APPROVED, result.receipt.status)
        assertTrue(result.receipt.isSimulation)
        assertTrue(result.tipRecorded)
        assertEquals(1, repo.savedTips.size)
        assertEquals(50_000L, repo.savedTips.single().amount)
        assertEquals("VND", result.receipt.currencyCode)
        assertEquals("en", repo.savedTips.single().languageCode)
    }

    @Test
    fun declinedSimulationDoesNotRecordTip() = runBlocking {
        val repo = RecordingTipRepository()
        val useCase = SendTipUseCase(repo, SimulatedPaymentGateway(responseDelayMillis = 0))

        val result = useCase(
            guest = guest,
            employee = employee,
            amount = 50_000L,
            message = "",
            languageCode = "ru",
            currencyCode = "VND",
            touristCountry = TouristCountry.RUSSIA,
            paymentMethod = SimulatedPaymentMethod.MIR,
            simulationOutcome = PaymentSimulationOutcome.DECLINED
        ).getOrThrow()

        assertEquals(PaymentStatus.DECLINED, result.receipt.status)
        assertFalse(result.tipRecorded)
        assertTrue(repo.savedTips.isEmpty())
    }

    @Test
    fun cancelledSimulationDoesNotRecordTip() = runBlocking {
        val repo = RecordingTipRepository()
        val useCase = SendTipUseCase(repo, SimulatedPaymentGateway(responseDelayMillis = 0))

        val result = useCase(
            guest = guest,
            employee = employee,
            amount = 50_000L,
            message = "",
            languageCode = "it",
            currencyCode = "VND",
            touristCountry = TouristCountry.ITALY,
            paymentMethod = SimulatedPaymentMethod.BANK_CARD,
            simulationOutcome = PaymentSimulationOutcome.CANCELLED
        ).getOrThrow()

        assertEquals(PaymentStatus.CANCELLED, result.receipt.status)
        assertFalse(result.tipRecorded)
        assertTrue(repo.savedTips.isEmpty())
    }

    @Test
    fun methodFromAnotherMarketIsRejectedBeforePayment() = runBlocking {
        val repo = RecordingTipRepository()
        val useCase = SendTipUseCase(repo, SimulatedPaymentGateway(responseDelayMillis = 0))

        val result = useCase(
            guest = guest,
            employee = employee,
            amount = 50_000L,
            message = "",
            languageCode = "zh",
            currencyCode = "VND",
            touristCountry = TouristCountry.CHINA,
            paymentMethod = SimulatedPaymentMethod.MIR,
            simulationOutcome = PaymentSimulationOutcome.APPROVED
        )

        assertTrue(result.isFailure)
        assertTrue(repo.savedTips.isEmpty())
    }

    private val guest = User(
        id = 12L,
        login = "qr_guest_12",
        displayName = "Guest",
        role = Role.GUEST,
        languageCode = "en",
        hotelId = 1L,
        roomNumber = 410
    )
    private val employee = Employee(
        id = 7L,
        userId = 8L,
        hotelId = 1L,
        fullName = "Test Employee",
        position = "Housekeeping",
        roomFrom = 401,
        roomTo = 420
    )

    private class RecordingTipRepository : TipRepository {
        val savedTips = mutableListOf<NewTip>()

        override suspend fun checkTipAllowed(employeeId: Long, amount: Long): Result<Unit> = Result.success(Unit)
        override suspend fun addTip(tip: NewTip): Result<Unit> {
            savedTips += tip
            return Result.success(Unit)
        }
        override fun observeTips(employeeId: Long): Flow<List<Tip>> = flowOf(emptyList())
        override fun observeWithdrawnTotal(employeeId: Long): Flow<Long> = flowOf(0L)
        override suspend fun withdrawAll(employeeId: Long): Result<Long> = Result.success(0L)
    }
}
