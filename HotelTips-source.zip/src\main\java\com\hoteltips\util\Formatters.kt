package com.hoteltips.util

import com.hoteltips.domain.model.Currency
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

/** 150000, VND -> "150 000 ₫" (неразрывные пробелы, чтобы сумма не переносилась). */
fun Long.toMoney(currency: Currency): String =
    String.format(Locale.US, "%,d", this).replace(',', '\u00A0') + "\u00A0" + currency.symbol

/** Короткое название дня недели на языке интерфейса: Пн / Mon / 月 / 周一. */
fun LocalDate.shortDayName(languageCode: String): String =
    dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.forLanguageTag(languageCode))
