package com.hoteltips.domain.model

/**
 * Public room locator carried by a TipHotel room QR code.
 * The hotel id is required because room numbers are only unique inside a hotel.
 */
data class RoomQrPayload(
    val hotelId: Long,
    val roomNumber: Int
)
