package com.hoteltips.domain.model

import java.time.Instant
import java.time.LocalDate

data class Tip(
    val id: Long,
    val employeeId: Long,
    val guestUserId: Long,
    val roomNumber: Int,
    val amount: Long,
    val message: String,
    val languageCode: String,
    val createdAt: Instant
)

data class NewTip(
    val employeeId: Long,
    val guestUserId: Long,
    val roomNumber: Int,
    val amount: Long,
    val message: String,
    val languageCode: String
)

/** Лимиты по сумме зависят от валюты отеля — см. [Currency]. Здесь только общие. */
object TipLimits {
    const val MAX_COUNT_PER_HOUR = 10
}

data class DayTips(val date: LocalDate, val amount: Long)

data class EmployeeDashboard(
    val employee: Employee,
    val hotel: Hotel?,
    /** Всего получено минус уже выведено. */
    val available: Long,
    val today: Long,
    val last7Days: Long,
    val last30Days: Long,
    /** Ровно 7 дней, последний — сегодня. */
    val week: List<DayTips>,
    val recentTips: List<Tip>
) {
    val currency: Currency get() = hotel?.currency ?: Currency.VND
}
