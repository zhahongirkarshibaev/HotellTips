package com.hoteltips.data.payment

import com.hoteltips.domain.model.PaymentRequest
import com.hoteltips.domain.model.PaymentSimulationOutcome
import com.hoteltips.domain.model.PaymentStatus
import com.hoteltips.domain.model.SimulatedPaymentMethod
import com.hoteltips.domain.model.TouristCountry
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SimulatedPaymentGatewayTest {
    private val gateway = SimulatedPaymentGateway(responseDelayMillis = 0)

    @Test
    fun eachTouristMarketOnlyOffersItsConfiguredDemoMethods() {
        assertEquals(
            listOf(SimulatedPaymentMethod.MIR, SimulatedPaymentMethod.SBP),
            SimulatedPaymentMethod.forCountry(TouristCountry.RUSSIA)
        )
        assertEquals(
            listOf(SimulatedPaymentMethod.ALIPAY, SimulatedPaymentMethod.WECHAT_PAY, SimulatedPaymentMethod.UNIONPAY),
            SimulatedPaymentMethod.forCountry(TouristCountry.CHINA)
        )
        assertEquals(
            listOf(SimulatedPaymentMethod.BANK_CARD, SimulatedPaymentMethod.PAYPAL, SimulatedPaymentMethod.MOBILE_WALLET),
            SimulatedPaymentMethod.forCountry(TouristCountry.ITALY)
        )
        assertEquals(
            listOf(SimulatedPaymentMethod.BANK_CARD, SimulatedPaymentMethod.PAYPAL, SimulatedPaymentMethod.MOBILE_WALLET),
            SimulatedPaymentMethod.forCountry(TouristCountry.UNITED_STATES)
        )
        assertTrue(SimulatedPaymentMethod.entries.all { method ->
            TouristCountry.entries.any(method::supports)
        })
    }

    @Test
    fun approvedSimulationReturnsDemoReceiptAndNoProviderData() = runBlocking {
        val result = gateway.charge(request(PaymentSimulationOutcome.APPROVED))

        assertTrue(result.isSuccess)
        val receipt = result.getOrThrow()
        assertEquals(PaymentStatus.APPROVED, receipt.status)
        assertTrue(receipt.isSimulation)
        assertTrue(receipt.reference.startsWith("SIM-"))
        assertEquals("VND", receipt.currencyCode)
        assertEquals(SimulatedPaymentMethod.MIR, receipt.method)
    }

    @Test
    fun declinedAndCancelledAreRecordedAsNonSuccessfulDemoOutcomes() = runBlocking {
        val declined = gateway.charge(request(PaymentSimulationOutcome.DECLINED)).getOrThrow()
        val cancelled = gateway.charge(request(PaymentSimulationOutcome.CANCELLED)).getOrThrow()

        assertEquals(PaymentStatus.DECLINED, declined.status)
        assertEquals(PaymentStatus.CANCELLED, cancelled.status)
        assertFalse(declined.reference == cancelled.reference)
    }

    @Test
    fun unsupportedMethodIsRejected() = runBlocking {
        val result = gateway.charge(
            request(PaymentSimulationOutcome.APPROVED).copy(
                touristCountry = TouristCountry.CHINA,
                method = SimulatedPaymentMethod.MIR
            )
        )
        assertTrue(result.isFailure)
    }

    @Test
    fun nonPositiveAmountIsRejected() = runBlocking {
        val result = gateway.charge(request(PaymentSimulationOutcome.APPROVED).copy(amount = 0L))
        assertTrue(result.isFailure)
    }

    private fun request(outcome: PaymentSimulationOutcome) = PaymentRequest(
        amount = 50_000L,
        currencyCode = "VND",
        description = "Test tip for room 410",
        touristCountry = TouristCountry.RUSSIA,
        method = SimulatedPaymentMethod.MIR,
        outcome = outcome
    )
}
