package com.hoteltips.domain.repository

import com.hoteltips.domain.model.AppLanguage
import com.hoteltips.domain.model.PaymentReceipt
import com.hoteltips.domain.model.PaymentRequest
import com.hoteltips.domain.model.Employee
import com.hoteltips.domain.model.EmployeeDraft
import com.hoteltips.domain.model.EmployeeSummary
import com.hoteltips.domain.model.Hotel
import com.hoteltips.domain.model.Feedback
import com.hoteltips.domain.model.NewFeedback
import com.hoteltips.domain.model.NewTip
import com.hoteltips.domain.model.Tip
import com.hoteltips.domain.model.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface SessionRepository {
    /** Id пользователя из сохранённой (зашифрованной и неистёкшей) сессии. */
    val userId: StateFlow<Long?>

    /** Проверенный пользователь, от имени которого выполняются операции. Только в памяти. */
    val currentUser: User?

    /** Вход: запоминает пользователя и сохраняет зашифрованную сессию. */
    fun start(user: User)

    /** Восстановление сессии после перезапуска: пользователь уже перечитан из БД. */
    fun attach(user: User)

    fun end()
}

interface AuthRepository {
    suspend fun login(login: String, password: String): Result<User>
    suspend fun registerGuest(
        login: String,
        password: String,
        displayName: String,
        hotelId: Long,
        roomNumber: Int,
        language: AppLanguage
    ): Result<User>

    /** Guest entry by room QR. [installationKey] is private to one app installation. */
    suspend fun enterGuestFromQr(
        installationKey: String,
        hotelId: Long,
        roomNumber: Int,
        displayName: String,
        language: AppLanguage
    ): Result<User>

    suspend fun getUser(id: Long): User?

    /** true, если в системе уже есть хотя бы одна учётная запись. */
    suspend fun hasAnyUser(): Boolean

    /** Первый запуск: создаёт администратора. Работает только пока пользователей нет. */
    suspend fun createInitialAdmin(login: String, password: String, displayName: String): Result<User>

    /** Повторная проверка пароля текущего пользователя перед рискованной операцией. */
    suspend fun verifyPassword(password: String): Result<Unit>

    /** Смена пароля текущим пользователем (нужен старый пароль). */
    suspend fun changePassword(oldPassword: String, newPassword: String): Result<Unit>
}

interface EmployeeRepository {
    fun observeSummaries(): Flow<List<EmployeeSummary>>
    fun observeByUserId(userId: Long): Flow<Employee?>
    fun observeByRoom(hotelId: Long, room: Int): Flow<Employee?>
    suspend fun getDraft(employeeId: Long): EmployeeDraft?
    suspend fun create(draft: EmployeeDraft): Result<Unit>
    suspend fun update(employeeId: Long, draft: EmployeeDraft): Result<Unit>
    suspend fun delete(employeeId: Long): Result<Unit>
}

interface TipRepository {
    /** Проверка лимитов и прав ДО списания денег. */
    suspend fun checkTipAllowed(employeeId: Long, amount: Long): Result<Unit>

    suspend fun addTip(tip: NewTip): Result<Unit>

    /** Чаевые сотрудника, новые первыми. */
    fun observeTips(employeeId: Long): Flow<List<Tip>>
    fun observeWithdrawnTotal(employeeId: Long): Flow<Long>

    /** Выводит весь доступный остаток, возвращает выведенную сумму. */
    suspend fun withdrawAll(employeeId: Long): Result<Long>
}

interface FeedbackRepository {
    suspend fun add(feedback: NewFeedback): Result<Unit>
    fun observeForEmployee(employeeId: Long): Flow<List<Feedback>>
}

/**
 * Порт интеграции оплаты. Сейчас он подключён только к simulator;
 * реальный provider не должен подключаться без отдельного согласованного изменения.
 */
interface PaymentGateway {
    suspend fun charge(request: PaymentRequest): Result<PaymentReceipt>
}

interface TranslationService {
    /** Переводит текст на язык [target]; язык оригинала определяется автоматически. */
    suspend fun translate(text: String, target: AppLanguage): Result<String>
}

interface HotelRepository {
    /** Список отелей открыт всем: он нужен ещё до входа, при регистрации гостя. */
    fun observeAll(): Flow<List<Hotel>>
    fun observeById(id: Long): Flow<Hotel?>

    suspend fun create(countryCode: String, cityCode: String, name: String): Result<Unit>
    suspend fun rename(id: Long, name: String): Result<Unit>

    /** Нельзя удалить отель, в котором есть сотрудники или гости. */
    suspend fun delete(id: Long): Result<Unit>
}
