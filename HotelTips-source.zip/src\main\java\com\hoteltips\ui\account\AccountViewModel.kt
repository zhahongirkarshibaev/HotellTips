package com.hoteltips.ui.account

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hoteltips.di.AppContainer
import com.hoteltips.R
import com.hoteltips.domain.common.UiText
import com.hoteltips.domain.common.toUiText
import com.hoteltips.domain.repository.AuthRepository
import com.hoteltips.ui.common.ChangePasswordDialog
import com.hoteltips.ui.common.vmFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AccountUiState(
    val isSaving: Boolean = false,
    val error: UiText? = null,
    val done: Boolean = false
)

class AccountViewModel(private val auth: AuthRepository) : ViewModel() {

    private val _state = MutableStateFlow(AccountUiState())
    val state: StateFlow<AccountUiState> = _state.asStateFlow()

    fun onSubmit(old: String, new: String, confirm: String) {
        if (_state.value.isSaving) return
        if (new != confirm) {
            _state.update { it.copy(error = UiText.res(R.string.err_passwords_mismatch)) }
            return
        }
        _state.update { it.copy(isSaving = true, error = null) }
        viewModelScope.launch {
            auth.changePassword(old, new)
                .onSuccess { _state.update { AccountUiState(done = true) } }
                .onFailure { e -> _state.update { AccountUiState(error = e.toUiText()) } }
        }
    }

    fun reset() {
        _state.value = AccountUiState()
    }
}

/** Диалог смены собственного пароля — общий для всех ролей. */
@Composable
fun ChangePasswordHost(container: AppContainer, visible: Boolean, onDismiss: () -> Unit) {
    if (!visible) return
    val vm: AccountViewModel = viewModel(
        key = "account-${container.sessionRepository.currentUser?.id}",
        factory = vmFactory { AccountViewModel(container.authRepository) }
    )
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(state.done) {
        if (state.done) {
            Toast.makeText(context, context.getString(R.string.toast_password_changed), Toast.LENGTH_SHORT).show()
            vm.reset()
            onDismiss()
        }
    }

    ChangePasswordDialog(
        isSaving = state.isSaving,
        error = state.error,
        onSubmit = vm::onSubmit,
        onDismiss = {
            vm.reset()
            onDismiss()
        }
    )
}
