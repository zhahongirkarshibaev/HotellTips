package com.hoteltips.data.mapper

import com.hoteltips.data.local.entity.EmployeeEntity
import com.hoteltips.data.local.entity.EmployeeSummaryRow
import com.hoteltips.data.local.entity.FeedbackEntity
import com.hoteltips.data.local.entity.HotelEntity
import com.hoteltips.data.local.entity.TipEntity
import com.hoteltips.data.local.entity.UserEntity
import com.hoteltips.domain.model.Employee
import com.hoteltips.domain.model.EmployeeSummary
import com.hoteltips.domain.model.Feedback
import com.hoteltips.domain.model.Hotel
import com.hoteltips.domain.model.Tip
import com.hoteltips.domain.model.User
import java.time.Instant

fun UserEntity.toDomain() = User(
    id = id,
    login = login,
    displayName = displayName,
    role = role,
    languageCode = languageCode,
    hotelId = hotelId,
    roomNumber = roomNumber
)

fun EmployeeEntity.toDomain() = Employee(
    id = id,
    userId = userId,
    hotelId = hotelId,
    fullName = fullName,
    position = position,
    roomFrom = roomFrom,
    roomTo = roomTo
)

fun TipEntity.toDomain() = Tip(
    id = id,
    employeeId = employeeId,
    guestUserId = guestUserId,
    roomNumber = roomNumber,
    amount = amount,
    message = message,
    languageCode = languageCode,
    createdAt = Instant.ofEpochMilli(createdAt)
)

fun FeedbackEntity.toDomain() = Feedback(
    id = id,
    employeeId = employeeId,
    guestUserId = guestUserId,
    roomNumber = roomNumber,
    type = type,
    text = text,
    languageCode = languageCode,
    createdAt = Instant.ofEpochMilli(createdAt)
)

fun HotelEntity.toDomain() = Hotel(id = id, countryCode = countryCode, cityCode = cityCode, name = name)

fun EmployeeSummaryRow.toDomain(hotel: Hotel?) = EmployeeSummary(
    employee = employee.toDomain(),
    hotel = hotel,
    totalTips = totalTips,
    tipsCount = tipsCount,
    complaintsCount = complaintsCount
)
