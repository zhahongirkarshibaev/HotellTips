package com.hoteltips.data.repository

import androidx.room.withTransaction
import com.hoteltips.R
import com.hoteltips.data.local.AppDatabase
import com.hoteltips.data.local.entity.EmployeeEntity
import com.hoteltips.data.local.entity.UserEntity
import com.hoteltips.data.mapper.toDomain
import com.hoteltips.data.security.AuditLogger
import com.hoteltips.data.security.Ledger
import com.hoteltips.data.security.PasswordHasher
import com.hoteltips.data.security.guardedFlow
import com.hoteltips.domain.common.AppException
import com.hoteltips.domain.common.safeCall
import com.hoteltips.domain.model.Employee
import com.hoteltips.domain.model.EmployeeDraft
import com.hoteltips.domain.model.EmployeeSummary
import com.hoteltips.domain.model.Role
import com.hoteltips.domain.repository.EmployeeRepository
import com.hoteltips.domain.security.AccessGuard
import com.hoteltips.util.toMoney
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class EmployeeRepositoryImpl(
    private val db: AppDatabase,
    private val hasher: PasswordHasher,
    private val guard: AccessGuard,
    private val ledger: Ledger,
    private val audit: AuditLogger
) : EmployeeRepository {

    private val userDao = db.userDao()
    private val employeeDao = db.employeeDao()
    private val hotelDao = db.hotelDao()

    /** Список сотрудников с финансами — только администратору. */
    override fun observeSummaries(): Flow<List<EmployeeSummary>> =
        guard.guardedFlow(
            fallback = emptyList(),
            allow = { it.role == Role.ADMIN }
        ) {
            combine(employeeDao.observeSummaries(), hotelDao.observeAll()) { rows, hotels ->
                val byId = hotels.associateBy { it.id }
                rows.map { row -> row.toDomain(byId[row.employee.hotelId]?.toDomain()) }
            }
        }

    /** Профиль сотрудника — ему самому или администратору. */
    override fun observeByUserId(userId: Long): Flow<Employee?> =
        guard.guardedFlow(
            fallback = null,
            allow = { it.id == userId || it.role == Role.ADMIN }
        ) { employeeDao.observeByUserId(userId).map { it?.toDomain() } }

    /** Сотрудника комнаты видит гость этой комнаты этого отеля или администратор. */
    override fun observeByRoom(hotelId: Long, room: Int): Flow<Employee?> =
        guard.guardedFlow(
            fallback = null,
            allow = {
                it.role == Role.ADMIN ||
                    (it.role == Role.GUEST && it.hotelId == hotelId && it.roomNumber == room)
            }
        ) { employeeDao.observeByRoom(hotelId, room).map { it?.toDomain() } }

    override suspend fun getDraft(employeeId: Long): EmployeeDraft? {
        guard.requireRole(Role.ADMIN)
        val employee = employeeDao.findById(employeeId) ?: return null
        val user = userDao.findById(employee.userId) ?: return null
        // Пароля здесь нет и быть не может: в БД хранится только необратимый хеш.
        return EmployeeDraft(
            hotelId = employee.hotelId,
            fullName = employee.fullName,
            position = employee.position,
            roomFrom = employee.roomFrom,
            roomTo = employee.roomTo,
            login = user.login,
            password = null
        )
    }

    override suspend fun create(draft: EmployeeDraft): Result<Unit> = safeCall {
        val admin = guard.requireRole(Role.ADMIN)
        val password = draft.password ?: throw AppException(R.string.err_set_password)
        val hash = withContext(Dispatchers.Default) { hasher.hash(password) }
        val employeeId = db.withTransaction {
            if (hotelDao.findById(draft.hotelId) == null) throw AppException(R.string.err_hotel_not_found)
            if (userDao.findByLogin(draft.login) != null) throw AppException(R.string.err_login_taken)
            ensureRoomsFree(draft, excludeId = 0)
            val userId = userDao.insert(
                UserEntity(
                    login = draft.login,
                    passwordHash = hash,
                    displayName = draft.fullName,
                    role = Role.EMPLOYEE,
                    languageCode = "ru"
                )
            )
            employeeDao.insert(
                EmployeeEntity(
                    userId = userId,
                    hotelId = draft.hotelId,
                    fullName = draft.fullName,
                    position = draft.position,
                    roomFrom = draft.roomFrom,
                    roomTo = draft.roomTo
                )
            )
        }
        audit.log(admin.id, "EMPLOYEE_CREATED", "employeeId=$employeeId")
    }

    override suspend fun update(employeeId: Long, draft: EmployeeDraft): Result<Unit> = safeCall {
        val admin = guard.requireRole(Role.ADMIN)
        val newHash = draft.password?.let { pwd -> withContext(Dispatchers.Default) { hasher.hash(pwd) } }
        db.withTransaction {
            val employee = employeeDao.findById(employeeId)
                ?: throw AppException(R.string.err_employee_not_found)
            val user = userDao.findById(employee.userId)
                ?: throw AppException(R.string.err_account_not_found)
            if (hotelDao.findById(draft.hotelId) == null) throw AppException(R.string.err_hotel_not_found)

            // Переводить сотрудника в другую страну нельзя: у него накоплен баланс в валюте отеля.
            if (draft.hotelId != employee.hotelId) {
                val oldHotel = hotelDao.findById(employee.hotelId)
                val newHotel = hotelDao.findById(draft.hotelId)
                if (oldHotel?.countryCode != newHotel?.countryCode) {
                    throw AppException(R.string.err_hotel_other_country)
                }
            }

            val sameLogin = userDao.findByLogin(draft.login)
            if (sameLogin != null && sameLogin.id != user.id) throw AppException(R.string.err_login_taken)
            ensureRoomsFree(draft, excludeId = employeeId)

            userDao.update(
                user.copy(
                    login = draft.login,
                    displayName = draft.fullName,
                    passwordHash = newHash ?: user.passwordHash,
                    // Администратор сбросил пароль — снимаем и блокировку входа.
                    failedAttempts = if (newHash != null) 0 else user.failedAttempts,
                    lockedUntil = if (newHash != null) 0 else user.lockedUntil
                )
            )
            employeeDao.update(
                employee.copy(
                    hotelId = draft.hotelId,
                    fullName = draft.fullName,
                    position = draft.position,
                    roomFrom = draft.roomFrom,
                    roomTo = draft.roomTo
                )
            )
        }
        audit.log(
            admin.id,
            if (newHash != null) "EMPLOYEE_UPDATED_PASSWORD_RESET" else "EMPLOYEE_UPDATED",
            "employeeId=$employeeId"
        )
    }

    override suspend fun delete(employeeId: Long): Result<Unit> = safeCall {
        val admin = guard.requireRole(Role.ADMIN)
        val employee = employeeDao.findById(employeeId) ?: throw AppException(R.string.err_employee_not_found)

        // Защита денег сотрудника: нельзя удалить учётную запись с невыведенным остатком.
        val balance = ledger.balanceOf(employeeId)
        if (balance.tampered) {
            audit.log(admin.id, "TAMPERING_DETECTED", "employeeId=$employeeId on delete")
            throw AppException(R.string.err_tampered_delete)
        }
        if (balance.available > 0) {
            val currency = hotelDao.findById(employee.hotelId)?.let {
                com.hoteltips.domain.model.Geo.country(it.countryCode)?.currency
            } ?: com.hoteltips.domain.model.Currency.VND
            throw AppException(R.string.err_has_balance, balance.available.toMoney(currency))
        }
        // Каскадом удалятся профиль, чаевые, обращения и выводы.
        userDao.deleteById(employee.userId)
        audit.log(admin.id, "EMPLOYEE_DELETED", "employeeId=$employeeId")
    }

    private suspend fun ensureRoomsFree(draft: EmployeeDraft, excludeId: Long) {
        val other = employeeDao.findOverlapping(draft.hotelId, draft.roomFrom, draft.roomTo, excludeId)
        if (other != null) {
            throw AppException(
                R.string.err_rooms_taken, other.roomFrom, other.roomTo, other.fullName
            )
        }
    }
}
