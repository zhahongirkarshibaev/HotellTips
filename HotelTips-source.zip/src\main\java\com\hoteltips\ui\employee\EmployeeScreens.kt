package com.hoteltips.ui.employee

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hoteltips.R
import com.hoteltips.di.AppContainer
import com.hoteltips.domain.model.AppLanguage
import com.hoteltips.domain.model.Currency
import com.hoteltips.domain.model.DayTips
import com.hoteltips.domain.model.EmployeeDashboard
import com.hoteltips.domain.model.Feedback
import com.hoteltips.domain.model.FeedbackType
import com.hoteltips.domain.model.Tip
import com.hoteltips.domain.model.User
import com.hoteltips.ui.account.ChangePasswordHost
import com.hoteltips.ui.common.AppCard
import com.hoteltips.ui.common.EmptyState
import com.hoteltips.ui.common.GradientHeader
import com.hoteltips.ui.common.HeaderActions
import com.hoteltips.ui.common.InitialsAvatar
import com.hoteltips.ui.common.LoadingBox
import com.hoteltips.ui.common.LocalAppLanguage
import com.hoteltips.ui.common.PasswordConfirmDialog
import com.hoteltips.ui.common.SectionTitle
import com.hoteltips.ui.common.TranslatableMessage
import com.hoteltips.ui.common.TranslationUi
import com.hoteltips.ui.common.asString
import com.hoteltips.ui.common.placeLabel
import com.hoteltips.ui.common.relativeDay
import com.hoteltips.ui.common.toContentPadding
import com.hoteltips.ui.common.vmFactory
import com.hoteltips.ui.theme.AppShapes
import com.hoteltips.ui.theme.Cyan
import com.hoteltips.ui.theme.Danger
import com.hoteltips.ui.theme.Mint
import com.hoteltips.ui.theme.Navy
import com.hoteltips.util.shortDayName
import com.hoteltips.util.toMoney

@Composable
fun EmployeeRoot(container: AppContainer, user: User, onLogout: () -> Unit) {
    val vm: EmployeeViewModel = viewModel(
        key = "employee-${user.id}",
        factory = vmFactory {
            EmployeeViewModel(
                userId = user.id,
                observeDashboard = container.observeEmployeeDashboard,
                withdraw = container.withdraw,
                feedbackRepository = container.feedbackRepository,
                translator = container.translationService,
                currentLanguage = container.currentLanguage
            )
        }
    )
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var confirmWithdraw by remember { mutableStateOf(false) }
    var showChangePassword by remember { mutableStateOf(false) }
    val context = LocalContext.current

    LaunchedEffect(vm) {
        vm.events.collect { snackbar.showSnackbar(it.asString(context)) }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar {
                val colors = NavigationBarItemDefaults.colors(
                    indicatorColor = MaterialTheme.colorScheme.outline
                )
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text(stringResource(R.string.tab_home)) },
                    colors = colors
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Email, contentDescription = null) },
                    label = { Text(stringResource(R.string.tab_requests)) },
                    colors = colors
                )
            }
        }
    ) { padding ->
        val dashboard = state.dashboard
        when {
            state.isLoading -> LoadingBox()
            dashboard == null -> EmptyState(
                title = stringResource(R.string.employee_profile_missing_title),
                hint = stringResource(R.string.employee_profile_missing_hint),
                modifier = Modifier.padding(padding)
            )
            tab == 0 -> HomeTab(
                dashboard = dashboard,
                state = state,
                padding = padding,
                onWithdraw = { confirmWithdraw = true },
                onTranslate = vm::onTranslateClick,
                onChangePassword = { showChangePassword = true },
                onLogout = onLogout
            )
            else -> FeedbackTab(
                feedback = state.feedback,
                state = state,
                padding = padding,
                onTranslate = vm::onTranslateClick
            )
        }
    }

    if (confirmWithdraw) {
        val available = state.dashboard?.available ?: 0L
        val currency = state.dashboard?.currency ?: Currency.VND
        PasswordConfirmDialog(
            title = stringResource(R.string.withdraw_title),
            text = stringResource(R.string.withdraw_text, available.toMoney(currency)),
            confirmText = stringResource(R.string.withdraw_confirm),
            onConfirm = { password ->
                confirmWithdraw = false
                vm.onWithdrawConfirmed(password)
            },
            onDismiss = { confirmWithdraw = false }
        )
    }

    ChangePasswordHost(
        container = container,
        visible = showChangePassword,
        onDismiss = { showChangePassword = false }
    )
}

// ------------------------------------------------------------------ Главная

@Composable
private fun HomeTab(
    dashboard: EmployeeDashboard,
    state: EmployeeUiState,
    padding: PaddingValues,
    onWithdraw: () -> Unit,
    onTranslate: (String, String) -> Unit,
    onChangePassword: () -> Unit,
    onLogout: () -> Unit
) {
    val thanks = dashboard.recentTips.filter { it.message.isNotBlank() }
    val lang = LocalAppLanguage.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = padding.toContentPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { EmployeeHeader(dashboard, onChangePassword, onLogout) }
        item { BalanceCard(dashboard.available, dashboard.currency, state.isWithdrawing, onWithdraw) }
        item { StatsRow(dashboard) }
        item { WeeklyChartCard(dashboard.week, dashboard.currency) }
        item { SectionTitle(stringResource(R.string.thanks_title)) }
        if (thanks.isEmpty()) {
            item {
                EmptyState(
                    title = stringResource(R.string.thanks_empty_title),
                    hint = stringResource(R.string.thanks_empty_hint)
                )
            }
        } else {
            items(thanks, key = { it.id }) { tip ->
                // В ключ входит язык перевода: при смене языка прежние переводы не подставляются.
                val key = "tip-${tip.id}:${lang.code}"
                ThanksCard(
                    tip = tip,
                    currency = dashboard.currency,
                    translation = state.translations[key],
                    onTranslate = { onTranslate(key, tip.message) }
                )
            }
        }
    }
}

@Composable
private fun EmployeeHeader(
    dashboard: EmployeeDashboard,
    onChangePassword: () -> Unit,
    onLogout: () -> Unit
) {
    val employee = dashboard.employee
    val lang = LocalAppLanguage.current
    GradientHeader {
        InitialsAvatar(employee.initials, size = 64.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                employee.fullName,
                style = MaterialTheme.typography.titleLarge,
                color = Color.White
            )
            val hotel = dashboard.hotel
            Text(
                if (hotel != null) "${hotel.name} · ${stringResource(R.string.rooms_label, employee.roomsLabel)}"
                else stringResource(R.string.rooms_label, employee.roomsLabel),
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.92f)
            )
            if (hotel != null) {
                Text(
                    "${hotel.country?.flag.orEmpty()} ${hotel.placeLabel(lang.code)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }
        HeaderActions(onChangePassword, onLogout)
    }
}

@Composable
private fun BalanceCard(
    available: Long,
    currency: Currency,
    isWithdrawing: Boolean,
    onWithdraw: () -> Unit
) {
    AppCard {
        Text(
            stringResource(R.string.balance_available),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            letterSpacing = 1.sp
        )
        Spacer(Modifier.height(6.dp))
        Text(available.toMoney(currency), style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onWithdraw,
            enabled = available > 0 && !isWithdrawing,
            shape = AppShapes.pill,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Navy,
                disabledContainerColor = Color.White.copy(alpha = 0.25f),
                disabledContentColor = Color.White.copy(alpha = 0.6f)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            if (isWithdrawing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = Navy
                )
            } else {
                Text(stringResource(R.string.withdraw_button), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun StatsRow(d: EmployeeDashboard) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatCard(stringResource(R.string.stat_today), d.today, d.currency, Modifier.weight(1f))
        StatCard(stringResource(R.string.stat_7_days), d.last7Days, d.currency, Modifier.weight(1f))
        StatCard(stringResource(R.string.stat_30_days), d.last30Days, d.currency, Modifier.weight(1f))
    }
}

@Composable
private fun StatCard(label: String, amount: Long, currency: Currency, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp))
            .padding(horizontal = 6.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            amount.toMoney(currency),
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1
        )
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun WeeklyChartCard(week: List<DayTips>, currency: Currency) {
    val maxAmount = (week.maxOfOrNull { it.amount } ?: 0L).coerceAtLeast(1L)
    val chartHeight = 100.dp
    val lang = LocalAppLanguage.current

    AppCard {
        Text(stringResource(R.string.chart_title), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(
            currency.code,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(chartHeight + 28.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            week.forEach { day ->
                val fraction = day.amount.toFloat() / maxAmount.toFloat()
                val barHeight = (chartHeight * fraction).coerceAtLeast(4.dp)
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(26.dp)
                            .height(barHeight)
                            .background(
                                if (day.amount > 0) Mint else Mint.copy(alpha = 0.3f),
                                RoundedCornerShape(6.dp)
                            )
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        day.date.shortDayName(lang.code),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun ThanksCard(
    tip: Tip,
    currency: Currency,
    translation: TranslationUi?,
    onTranslate: () -> Unit
) {
    AppCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(AppLanguage.flagFor(tip.languageCode), fontSize = 18.sp)
            Spacer(Modifier.width(8.dp))
            Text("№ ${tip.roomNumber}", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.weight(1f))
            Text(
                tip.amount.toMoney(currency),
                color = Cyan,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp
            )
        }
        Spacer(Modifier.height(10.dp))
        TranslatableMessage(
            original = tip.message,
            footer = tip.createdAt.relativeDay(),
            translation = translation,
            onTranslateClick = onTranslate
        )
    }
}

// ----------------------------------------------------------------- Обращения

@Composable
private fun FeedbackTab(
    feedback: List<Feedback>,
    state: EmployeeUiState,
    padding: PaddingValues,
    onTranslate: (String, String) -> Unit
) {
    val lang = LocalAppLanguage.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = padding.toContentPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { SectionTitle(stringResource(R.string.requests_title)) }
        if (feedback.isEmpty()) {
            item {
                EmptyState(
                    title = stringResource(R.string.requests_empty_title),
                    hint = stringResource(R.string.requests_empty_hint)
                )
            }
        } else {
            items(feedback, key = { it.id }) { item ->
                val key = "fb-${item.id}:${lang.code}"
                FeedbackCard(
                    item = item,
                    translation = state.translations[key],
                    onTranslate = { onTranslate(key, item.text) }
                )
            }
        }
    }
}

@Composable
private fun FeedbackCard(
    item: Feedback,
    translation: TranslationUi?,
    onTranslate: () -> Unit
) {
    val isComplaint = item.type == FeedbackType.COMPLAINT
    val accent = if (isComplaint) Danger else Mint

    AppCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(AppLanguage.flagFor(item.languageCode), fontSize = 18.sp)
            Spacer(Modifier.width(8.dp))
            Text("№ ${item.roomNumber}", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.weight(1f))
            Text(
                stringResource(item.type.titleRes),
                color = accent,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier
                    .background(accent.copy(alpha = 0.15f), AppShapes.pill)
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }
        Spacer(Modifier.height(10.dp))
        TranslatableMessage(
            original = item.text,
            footer = item.createdAt.relativeDay(),
            translation = translation,
            onTranslateClick = onTranslate
        )
    }
}
