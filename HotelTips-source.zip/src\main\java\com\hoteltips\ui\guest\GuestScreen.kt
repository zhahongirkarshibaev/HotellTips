package com.hoteltips.ui.guest

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hoteltips.R
import com.hoteltips.di.AppContainer
import com.hoteltips.domain.model.Currency
import com.hoteltips.domain.model.Employee
import com.hoteltips.domain.model.FeedbackType
import com.hoteltips.domain.model.User
import com.hoteltips.domain.model.PaymentReceipt
import com.hoteltips.domain.model.PaymentSimulationOutcome
import com.hoteltips.domain.model.PaymentStatus
import com.hoteltips.domain.model.SimulatedPaymentMethod
import com.hoteltips.domain.model.TouristCountry
import com.hoteltips.ui.account.ChangePasswordHost
import com.hoteltips.ui.common.AppCard
import com.hoteltips.ui.common.ConfirmDialog
import com.hoteltips.ui.common.EmptyState
import com.hoteltips.ui.common.GradientHeader
import com.hoteltips.ui.common.HeaderActions
import com.hoteltips.ui.common.InitialsAvatar
import com.hoteltips.ui.common.LoadingBox
import com.hoteltips.ui.common.LocalAppLanguage
import com.hoteltips.ui.common.asString
import com.hoteltips.ui.common.placeLabel
import com.hoteltips.ui.common.toContentPadding
import com.hoteltips.ui.common.vmFactory
import com.hoteltips.util.toMoney

@Composable
fun GuestRoot(container: AppContainer, user: User, onLogout: () -> Unit) {
    val vm: GuestViewModel = viewModel(
        key = "guest-${user.id}",
        factory = vmFactory {
            GuestViewModel(
                guest = user,
                employees = container.employeeRepository,
                hotels = container.hotelRepository,
                sendTip = container.sendTip,
                sendFeedback = container.sendFeedback,
                currentLanguage = container.currentLanguage
            )
        }
    )
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var confirmTip by remember { mutableStateOf(false) }
    var showChangePassword by remember { mutableStateOf(false) }
    val context = LocalContext.current

    LaunchedEffect(vm) {
        vm.events.collect { snackbar.showSnackbar(it.asString(context)) }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        if (state.isLoading) {
            LoadingBox()
            return@Scaffold
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = padding.toContentPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { GuestHeader(user, state, { showChangePassword = true }, onLogout) }

            val employee = state.employee
            if (employee == null) {
                item {
                    AppCard {
                        EmptyState(
                            title = stringResource(R.string.guest_no_employee_title),
                            hint = stringResource(R.string.guest_no_employee_hint)
                        )
                    }
                }
            } else {
                item { EmployeeCard(employee) }
                item {
                    TipCard(
                        state = state,
                        onPreset = vm::onPresetSelected,
                        onCustomAmount = vm::onCustomAmountChange,
                        onMessage = vm::onTipMessageChange,
                        onPaymentCountry = vm::onPaymentCountryChange,
                        onPaymentMethod = vm::onPaymentMethodChange,
                        onSimulationOutcome = vm::onSimulationOutcomeChange,
                        onSend = { confirmTip = true }
                    )
                }
                item {
                    FeedbackCard(
                        state = state,
                        onType = vm::onFeedbackTypeChange,
                        onText = vm::onFeedbackTextChange,
                        onSend = vm::onSendFeedback
                    )
                }
            }
        }
    }

    if (confirmTip) {
        val amount = state.amount
        val name = state.employee?.fullName
        if (amount != null && name != null) {
            ConfirmDialog(
                title = stringResource(R.string.payment_simulation_title),
                text = stringResource(
                    R.string.confirm_payment_simulation_text,
                    amount.toMoney(state.currency),
                    name,
                    stringResource(state.paymentMethod.labelRes),
                    "${state.paymentCountry.flag} ${stringResource(state.paymentCountry.labelRes)}",
                    stringResource(state.simulationOutcome.labelRes)
                ),
                confirmText = stringResource(R.string.payment_sim_confirm),
                onConfirm = {
                    confirmTip = false
                    vm.onSendTip()
                },
                onDismiss = { confirmTip = false }
            )
        }
    }

    ChangePasswordHost(
        container = container,
        visible = showChangePassword,
        onDismiss = { showChangePassword = false }
    )
}

@Composable
private fun GuestHeader(
    user: User,
    state: GuestUiState,
    onChangePassword: () -> Unit,
    onLogout: () -> Unit
) {
    val lang = LocalAppLanguage.current
    val hotel = state.hotel
    GradientHeader {
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(R.string.guest_greeting, user.displayName),
                style = MaterialTheme.typography.titleLarge,
                color = Color.White
            )
            Text(
                if (hotel != null) "${hotel.name} · ${stringResource(R.string.room_number, user.roomNumber ?: 0)}"
                else stringResource(R.string.room_number, user.roomNumber ?: 0),
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.92f)
            )
            if (hotel != null) {
                Text(
                    "${hotel.country?.flag.orEmpty()} ${hotel.placeLabel(lang.code)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }
        HeaderActions(onChangePassword, onLogout)
    }
}

@Composable
private fun EmployeeCard(employee: Employee) {
    AppCard {
        Text(
            stringResource(R.string.guest_your_employee),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            InitialsAvatar(employee.initials, size = 56.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(employee.fullName, style = MaterialTheme.typography.titleLarge)
                Text(
                    "${employee.position} · ${stringResource(R.string.rooms_label, employee.roomsLabel)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun TipCard(
    state: GuestUiState,
    onPreset: (Long) -> Unit,
    onCustomAmount: (String) -> Unit,
    onMessage: (String) -> Unit,
    onPaymentCountry: (TouristCountry) -> Unit,
    onPaymentMethod: (SimulatedPaymentMethod) -> Unit,
    onSimulationOutcome: (PaymentSimulationOutcome) -> Unit,
    onSend: () -> Unit
) {
    val currency: Currency = state.currency
    val amount = state.amount
    val canSend = amount != null && amount in currency.minTip..currency.maxTip && !state.isSendingTip

    AppCard {
        Text(stringResource(R.string.tip_title), style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            currency.presets.forEach { preset ->
                FilterChip(
                    selected = state.selectedPreset == preset,
                    onClick = { onPreset(preset) },
                    label = { Text(preset.toMoney(currency)) }
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = state.customAmount,
            onValueChange = onCustomAmount,
            label = { Text(stringResource(R.string.tip_custom_amount, currency.symbol)) },
            supportingText = {
                Text(
                    stringResource(
                        R.string.tip_range_hint,
                        currency.minTip.toMoney(currency),
                        currency.maxTip.toMoney(currency)
                    )
                )
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        PaymentSimulationOptions(
            state = state,
            onCountry = onPaymentCountry,
            onMethod = onPaymentMethod,
            onOutcome = onSimulationOutcome
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = state.tipMessage,
            onValueChange = onMessage,
            label = { Text(stringResource(R.string.tip_message_label)) },
            minLines = 2,
            maxLines = 4,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = onSend,
            enabled = canSend,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            if (state.isSendingTip) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            } else {
                Text(
                    if (amount != null) stringResource(R.string.tip_send_amount, amount.toMoney(currency))
                    else stringResource(R.string.action_send),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun PaymentSimulationOptions(
    state: GuestUiState,
    onCountry: (TouristCountry) -> Unit,
    onMethod: (SimulatedPaymentMethod) -> Unit,
    onOutcome: (PaymentSimulationOutcome) -> Unit
) {
    var outcomeMenuExpanded by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            stringResource(R.string.payment_simulation_title),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            stringResource(R.string.payment_simulation_notice),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.tertiary
        )

        Text(
            stringResource(R.string.payment_sim_country_label),
            style = MaterialTheme.typography.labelLarge
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TouristCountry.entries.forEach { country ->
                FilterChip(
                    selected = state.paymentCountry == country,
                    onClick = { onCountry(country) },
                    enabled = !state.isSendingTip,
                    label = { Text("${country.flag} ${stringResource(country.labelRes)}") }
                )
            }
        }

        Text(
            stringResource(R.string.payment_sim_method_label),
            style = MaterialTheme.typography.labelLarge
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SimulatedPaymentMethod.forCountry(state.paymentCountry).forEach { method ->
                FilterChip(
                    selected = state.paymentMethod == method,
                    onClick = { onMethod(method) },
                    enabled = !state.isSendingTip,
                    label = { Text(stringResource(method.labelRes)) }
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(R.string.payment_sim_test_result),
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.weight(1f)
            )
            Box {
                TextButton(enabled = !state.isSendingTip, onClick = { outcomeMenuExpanded = true }) {
                    Text(stringResource(state.simulationOutcome.labelRes))
                }
                DropdownMenu(
                    expanded = outcomeMenuExpanded,
                    onDismissRequest = { outcomeMenuExpanded = false }
                ) {
                    PaymentSimulationOutcome.entries.forEach { outcome ->
                        DropdownMenuItem(
                            text = { Text(stringResource(outcome.labelRes)) },
                            onClick = {
                                outcomeMenuExpanded = false
                                onOutcome(outcome)
                            }
                        )
                    }
                }
            }
        }

        state.lastPaymentReceipt?.let { receipt ->
            PaymentSimulationReceipt(receipt = receipt, currency = state.currency)
        }
    }
}

@Composable
private fun PaymentSimulationReceipt(
    receipt: PaymentReceipt,
    currency: Currency
) {
    val statusLabel = when (receipt.status) {
        PaymentStatus.APPROVED -> stringResource(R.string.payment_status_approved)
        PaymentStatus.DECLINED -> stringResource(R.string.payment_status_declined)
        PaymentStatus.CANCELLED -> stringResource(R.string.payment_status_cancelled)
    }
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                stringResource(R.string.payment_sim_receipt_title),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Text(stringResource(R.string.payment_sim_receipt_status, statusLabel))
            Text(stringResource(R.string.payment_sim_receipt_amount, receipt.amount.toMoney(currency)))
            Text(
                stringResource(
                    R.string.payment_sim_receipt_method,
                    receipt.touristCountry.flag + " " + stringResource(receipt.touristCountry.labelRes),
                    stringResource(receipt.method.labelRes)
                )
            )
            Text(
                stringResource(R.string.payment_sim_receipt_reference, receipt.reference),
                style = MaterialTheme.typography.labelSmall
            )
            Text(
                stringResource(R.string.payment_sim_receipt_no_money),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.tertiary
            )
        }
    }
}

@Composable
private fun FeedbackCard(
    state: GuestUiState,
    onType: (FeedbackType) -> Unit,
    onText: (String) -> Unit,
    onSend: () -> Unit
) {
    AppCard {
        Text(stringResource(R.string.feedback_title), style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FeedbackType.entries.forEach { type ->
                FilterChip(
                    selected = state.feedbackType == type,
                    onClick = { onType(type) },
                    label = { Text(stringResource(type.titleRes)) }
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = state.feedbackText,
            onValueChange = onText,
            label = { Text(stringResource(R.string.feedback_hint)) },
            supportingText = { Text("${state.feedbackText.length}/500") },
            minLines = 3,
            maxLines = 6,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onSend,
            enabled = state.feedbackText.isNotBlank() && !state.isSendingFeedback,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            if (state.isSendingFeedback) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            } else {
                Text(stringResource(R.string.action_send), fontWeight = FontWeight.Bold)
            }
        }
    }
}
