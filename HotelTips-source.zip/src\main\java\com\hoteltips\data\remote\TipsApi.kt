package com.hoteltips.data.remote

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface TipsApi {

    @POST("tips/")
    suspend fun createTip(@Body tip: TipRequest): TipResponse

    @GET("tips/{id}")
    suspend fun getTip(@Path("id") id: Int): TipResponse
}