package com.hoteltips

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.hoteltips.ui.AppRoot
import com.hoteltips.ui.common.LocalAppLanguage
import com.hoteltips.ui.theme.HotelTipsTheme
import com.hoteltips.util.LocaleHelper

class MainActivity : ComponentActivity() {

    /** One-shot payload when Android opens the app from a room QR deep link. */
    private var incomingQrCode by mutableStateOf<String?>(null)

    /** Применяем выбранный язык интерфейса ко всем ресурсам Activity. */
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        captureIncomingQr(intent)
        // В боевой сборке запрещаем скриншоты, запись экрана и миниатюру в списке недавних:
        // на экране суммы и данные гостей.
        if (!BuildConfig.DEBUG) {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        }
        // Тема приложения всегда тёмная, поэтому и иконки системных панелей — светлые.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        val container = (application as HotelTipsApp).container
        setContent {
            CompositionLocalProvider(LocalAppLanguage provides LocaleHelper.current(this)) {
                HotelTipsTheme {
                    AppRoot(
                        container = container,
                        incomingQrCode = incomingQrCode,
                        onIncomingQrConsumed = { incomingQrCode = null }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        captureIncomingQr(intent)
    }

    private fun captureIncomingQr(source: Intent?) {
        val raw = source?.dataString
        incomingQrCode = raw?.takeIf { it.startsWith("hoteltips://guest", ignoreCase = true) }
        // Prevent Android from replaying the same link after an activity recreation.
        source?.data = null
    }
}
