    package com.hoteltips.domain.usecase

    import com.hoteltips.R
    import com.hoteltips.domain.common.AppException
    import com.hoteltips.domain.common.UiText
    import com.hoteltips.domain.model.AppLanguage
    import com.hoteltips.domain.model.Employee
    import com.hoteltips.domain.model.EmployeeDashboard
    import com.hoteltips.domain.model.EmployeeDraft
    import com.hoteltips.domain.model.FeedbackLimits
    import com.hoteltips.domain.model.FeedbackType
    import com.hoteltips.domain.model.NewFeedback
    import com.hoteltips.domain.model.NewTip
    import com.hoteltips.domain.model.PaymentRequest
    import com.hoteltips.domain.model.PaymentStatus
    import com.hoteltips.domain.model.PaymentSimulationOutcome
    import com.hoteltips.domain.model.SendTipResult
    import com.hoteltips.domain.model.SimulatedPaymentMethod
    import com.hoteltips.domain.model.TouristCountry
    import com.hoteltips.domain.model.User
    import com.hoteltips.domain.repository.AuthRepository
    import com.hoteltips.domain.repository.EmployeeRepository
    import com.hoteltips.domain.repository.FeedbackRepository
    import com.hoteltips.domain.repository.HotelRepository
    import com.hoteltips.domain.repository.PaymentGateway
    import com.hoteltips.data.remote.TipApiClient
    import com.hoteltips.data.remote.TipCreateRequest
    import com.hoteltips.domain.repository.TipRepository
    import com.hoteltips.domain.security.PasswordPolicy
    import kotlinx.coroutines.ExperimentalCoroutinesApi
    import kotlinx.coroutines.flow.Flow
    import kotlinx.coroutines.flow.combine
    import kotlinx.coroutines.flow.flatMapLatest
    import kotlinx.coroutines.flow.flowOf
    import java.time.Clock

    private val LOGIN_REGEX = Regex("^[a-z0-9_.]{3,32}$")

    /** Панель сотрудника: профиль + отель + чаевые + выводы, пересчитывается при любом изменении. */
    class ObserveEmployeeDashboardUseCase(
        private val employees: EmployeeRepository,
        private val tips: TipRepository,
        private val hotels: HotelRepository,
        private val clock: Clock = Clock.systemDefaultZone()
    ) {
        @OptIn(ExperimentalCoroutinesApi::class)
        operator fun invoke(userId: Long): Flow<EmployeeDashboard?> =
            employees.observeByUserId(userId).flatMapLatest { employee ->
                if (employee == null) {
                    flowOf(null)
                } else {
                    combine(
                        tips.observeTips(employee.id),
                        tips.observeWithdrawnTotal(employee.id),
                        hotels.observeById(employee.hotelId)
                    ) { list, withdrawn, hotel ->
                        DashboardCalculator.build(employee, hotel, list, withdrawn, clock)
                    }
                }
            }
    }

    class SendTipUseCase(
        private val tips: TipRepository,
        private val payments: PaymentGateway,
        /** Если задан — чаевые дублируются на сервер Timeweb (источник истины для облака). */
            private val tipApi: TipApiClient? = null
    ) {
        /**
         * 1) Проверяет лимиты локально.
         * 2) Если подключён [tipApi] — создаёт запись на сервере (pending до Stripe).
         * 3) Локальный simulator / payment gateway.
         * 4) При успехе пишет tip в локальный ledger сотрудника.
         */
        suspend operator fun invoke(
            guest: User,
            employee: Employee,
            amount: Long,
            message: String,
            languageCode: String,
            currencyCode: String,
            touristCountry: TouristCountry,
            paymentMethod: SimulatedPaymentMethod,
            simulationOutcome: PaymentSimulationOutcome
        ): Result<SendTipResult> {
            val room = guest.roomNumber
                ?: return Result.failure(AppException(R.string.err_room_missing))
            val hotelId = guest.hotelId
                ?: return Result.failure(AppException(R.string.err_hotel_not_found))
            if (message.length > FeedbackLimits.MAX_LENGTH) {
                return Result.failure(AppException(R.string.err_message_too_long))
            }
            if (amount <= 0) {
                return Result.failure(AppException(R.string.payment_sim_invalid_amount))
            }
            if (!paymentMethod.supports(touristCountry)) {
                return Result.failure(AppException(R.string.payment_sim_invalid_method))
            }

            val allowed = tips.checkTipAllowed(employee.id, amount)
            if (allowed.isFailure) return Result.failure(allowed.exceptionOrNull()!!)

            // --- Синхронизация с сервером (обязательна, если tipApi задан) ---
            var serverRef: String? = null
            if (tipApi != null) {
                val remote = tipApi.createTip(
                    TipCreateRequest(
                        hotel_id = "hotel_$hotelId",
                        room_number = room.toString(),
                        amount = amount.toDouble(),
                        currency = currencyCode,
                        guest_name = guest.displayName,
                        message = message.trim().ifEmpty { null },
                        employee_id = "emp_${employee.id}"
                    )
                )
                if (remote.isFailure) {
                    return Result.failure(
                        AppException(UiText.res(R.string.err_server_unreachable), remote.exceptionOrNull())
                    )
                }
                serverRef = "SRV-${remote.getOrThrow().id}"
            }

            val payment = payments.charge(
                PaymentRequest(
                    amount = amount,
                    currencyCode = currencyCode,
                    description = "Tip for ${employee.fullName}, room $room",
                    touristCountry = touristCountry,
                    method = paymentMethod,
                    // Если сервер уже принял tip — считаем платёж «принятым в обработку»
                    outcome = if (serverRef != null) PaymentSimulationOutcome.APPROVED else simulationOutcome
                )
            )
            if (payment.isFailure) return Result.failure(payment.exceptionOrNull()!!)
            var receipt = payment.getOrThrow()
            if (serverRef != null) {
                receipt = receipt.copy(reference = serverRef, isSimulation = false)
            }

            if (receipt.status != PaymentStatus.APPROVED) {
                return Result.success(SendTipResult(receipt = receipt, tipRecorded = false))
            }

            val saved = tips.addTip(
                NewTip(
                    employeeId = employee.id,
                    guestUserId = guest.id,
                    roomNumber = room,
                    amount = amount,
                    message = message.trim(),
                    languageCode = languageCode
                )
            )
            if (saved.isFailure) return Result.failure(saved.exceptionOrNull()!!)
            return Result.success(SendTipResult(receipt = receipt, tipRecorded = true))
        }
    }

    class SendFeedbackUseCase(private val feedback: FeedbackRepository) {
        suspend operator fun invoke(
            guest: User,
            employee: Employee,
            type: FeedbackType,
            text: String,
            languageCode: String
        ): Result<Unit> {
            val room = guest.roomNumber
                ?: return Result.failure(AppException(R.string.err_room_missing))
            val clean = text.trim()
            if (clean.isEmpty()) return Result.failure(AppException(R.string.err_feedback_empty))
            if (clean.length > FeedbackLimits.MAX_LENGTH) {
                return Result.failure(AppException(R.string.err_feedback_too_long, FeedbackLimits.MAX_LENGTH))
            }
            return feedback.add(
                NewFeedback(
                    employeeId = employee.id,
                    guestUserId = guest.id,
                    roomNumber = room,
                    type = type,
                    text = clean,
                    languageCode = languageCode
                )
            )
        }
    }

    class SaveEmployeeUseCase(private val employees: EmployeeRepository) {

        /** [employeeId] == null — создание, иначе — редактирование. */
        suspend operator fun invoke(employeeId: Long?, draft: EmployeeDraft): Result<Unit> {
            val clean = draft.copy(
                fullName = draft.fullName.trim(),
                position = draft.position.trim(),
                login = draft.login.trim().lowercase(),
                password = draft.password?.takeIf { it.isNotEmpty() }
            )
            validate(clean, isNew = employeeId == null)?.let { return Result.failure(it) }
            return if (employeeId == null) employees.create(clean) else employees.update(employeeId, clean)
        }

        private fun validate(d: EmployeeDraft, isNew: Boolean): AppException? {
            val password = d.password
            return when {
                d.hotelId <= 0 -> AppException(R.string.err_choose_hotel)
                d.fullName.isBlank() -> AppException(R.string.err_enter_employee_name)
                d.position.isBlank() -> AppException(R.string.err_enter_position)
                d.roomFrom <= 0 || d.roomTo < d.roomFrom -> AppException(R.string.err_rooms_range)
                !LOGIN_REGEX.matches(d.login) -> AppException(R.string.err_login_format)
                isNew && password == null -> AppException(R.string.err_set_password)
                password != null -> PasswordPolicy.validate(password, d.login)?.let { AppException(it) }
                else -> null
            }
        }
    }

    class RegisterGuestUseCase(private val auth: AuthRepository) {

        suspend operator fun invoke(
            login: String,
            password: String,
            displayName: String,
            hotelId: Long?,
            roomNumber: Int?,
            language: AppLanguage
        ): Result<User> {
            val cleanLogin = login.trim().lowercase()
            val error: AppException? = when {
                hotelId == null -> AppException(R.string.err_choose_hotel)
                displayName.isBlank() -> AppException(R.string.err_enter_guest_name)
                !LOGIN_REGEX.matches(cleanLogin) -> AppException(R.string.err_login_format)
                roomNumber == null || roomNumber <= 0 -> AppException(R.string.err_enter_room)
                else -> PasswordPolicy.validate(password, cleanLogin)?.let { AppException(it) }
            }
            if (error != null) return Result.failure(error)
            return auth.registerGuest(cleanLogin, password, displayName.trim(), hotelId!!, roomNumber!!, language)
        }
    }

    /** Создание первого администратора при первом запуске (в боевой сборке пользователей изначально нет). */
    class CreateInitialAdminUseCase(private val auth: AuthRepository) {
        suspend operator fun invoke(login: String, password: String, displayName: String): Result<User> {
            val cleanLogin = login.trim().lowercase()
            val error: AppException? = when {
                displayName.isBlank() -> AppException(R.string.err_enter_admin_name)
                !LOGIN_REGEX.matches(cleanLogin) -> AppException(R.string.err_login_format)
                else -> PasswordPolicy.validate(password, cleanLogin)?.let { AppException(it) }
            }
            if (error != null) return Result.failure(error)
            return auth.createInitialAdmin(cleanLogin, password, displayName.trim())
        }
    }

    /**
     * Вывод средств. Требует повторного ввода пароля: если кто-то получил доступ к
     * разблокированному телефону, он всё равно не сможет вывести деньги.
     */
    class WithdrawUseCase(
        private val auth: AuthRepository,
        private val tips: TipRepository
    ) {
        suspend operator fun invoke(employeeId: Long, password: String): Result<Long> {
            if (password.isEmpty()) return Result.failure(AppException(R.string.err_enter_password))
            val verified = auth.verifyPassword(password)
            if (verified.isFailure) {
                return Result.failure(verified.exceptionOrNull() ?: AppException(R.string.err_bad_password))
            }
            return tips.withdrawAll(employeeId)
        }
    }
