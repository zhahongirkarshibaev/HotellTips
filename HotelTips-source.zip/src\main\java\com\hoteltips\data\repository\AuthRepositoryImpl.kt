package com.hoteltips.data.repository

import com.hoteltips.R
import com.hoteltips.data.local.dao.EmployeeDao
import com.hoteltips.data.local.dao.HotelDao
import com.hoteltips.data.local.dao.UserDao
import com.hoteltips.data.local.entity.UserEntity
import com.hoteltips.data.mapper.toDomain
import com.hoteltips.data.security.AuditLogger
import com.hoteltips.data.security.PasswordHasher
import com.hoteltips.domain.common.AppException
import com.hoteltips.domain.common.UiText
import com.hoteltips.domain.common.safeCall
import com.hoteltips.domain.model.AppLanguage
import com.hoteltips.domain.model.Role
import com.hoteltips.domain.model.User
import com.hoteltips.domain.repository.AuthRepository
import com.hoteltips.domain.security.AccessGuard
import com.hoteltips.domain.security.PasswordPolicy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.util.UUID

class AuthRepositoryImpl(
    private val userDao: UserDao,
    private val employeeDao: EmployeeDao,
    private val hotelDao: HotelDao,
    private val hasher: PasswordHasher,
    private val guard: AccessGuard,
    private val audit: AuditLogger
) : AuthRepository {

    /** Хеш несуществующего пользователя: даёт то же время ответа и не выдаёт, что логин не найден. */
    private val dummyHash: String by lazy { hasher.hash("dummy-password-for-timing") }

    override suspend fun login(login: String, password: String): Result<User> = safeCall {
        val entity = userDao.findByLogin(login.trim().lowercase())
        if (entity == null) {
            withContext(Dispatchers.Default) { hasher.verify(password, dummyHash) }
            audit.log(null, "LOGIN_UNKNOWN_USER")
            throw AppException(R.string.err_bad_credentials)
        }
        authenticate(entity, password, R.string.err_bad_credentials)
        audit.log(entity.id, "LOGIN_OK")
        entity.toDomain()
    }

    override suspend fun registerGuest(
        login: String,
        password: String,
        displayName: String,
        hotelId: Long,
        roomNumber: Int,
        language: AppLanguage
    ): Result<User> = safeCall {
        if (userDao.findByLogin(login) != null) throw AppException(R.string.err_login_taken)
        if (hotelDao.findById(hotelId) == null) throw AppException(R.string.err_hotel_not_found)
        if (employeeDao.findByRoom(hotelId, roomNumber) == null) {
            throw AppException(R.string.err_no_employee_for_room, roomNumber)
        }
        val hash = withContext(Dispatchers.Default) { hasher.hash(password) }
        val entity = UserEntity(
            login = login,
            passwordHash = hash,
            displayName = displayName,
            role = Role.GUEST,
            languageCode = language.code,
            hotelId = hotelId,
            roomNumber = roomNumber
        )
        val id = userDao.insert(entity)
        audit.log(id, "GUEST_REGISTERED", "hotel=$hotelId, room=$roomNumber")
        entity.copy(id = id).toDomain()
    }

    override suspend fun enterGuestFromQr(
        installationKey: String,
        hotelId: Long,
        roomNumber: Int,
        displayName: String,
        language: AppLanguage
    ): Result<User> = safeCall {
        // The QR identifies a room, not a person. Resolve it against the local hotel directory.
        if (hotelId <= 0L || roomNumber !in 1..999_999 || installationKey.isBlank()) {
            throw AppException(R.string.err_qr_invalid)
        }
        if (hotelDao.findById(hotelId) == null) {
            throw AppException(R.string.err_hotel_not_found)
        }
        if (employeeDao.findByRoom(hotelId, roomNumber) == null) {
            throw AppException(R.string.err_no_employee_for_room, roomNumber)
        }

        val cleanName = displayName.trim()
        if (cleanName.isEmpty()) throw AppException(R.string.err_qr_name_required)
        if (cleanName.length > 50) throw AppException(R.string.err_qr_name_too_long)

        // Stable for this installation + hotel + room. It avoids a new guest row on every scan.
        val digest = MessageDigest.getInstance("SHA-256")
            .digest("$installationKey:$hotelId:$roomNumber".toByteArray(Charsets.UTF_8))
        val stableLogin = "qr_" + digest.take(24).joinToString("") { "%02x".format(it) }
        val existing = userDao.findByLogin(stableLogin)
        if (existing != null) {
            // Never convert an account of another role (or another room) into a QR guest.
            if (existing.role != Role.GUEST || existing.hotelId != hotelId || existing.roomNumber != roomNumber) {
                throw AppException(R.string.err_qr_account_conflict)
            }
            val refreshed = existing.copy(
                displayName = cleanName,
                languageCode = language.code,
                failedAttempts = 0,
                lockedUntil = 0
            )
            userDao.update(refreshed)
            audit.log(refreshed.id, "GUEST_QR_LOGIN", "hotel=$hotelId, room=$roomNumber")
            refreshed.toDomain()
        } else {
            // The QR flow has no password. Store a hash of an unguessable throwaway secret so
            // this account cannot be entered through the password form with a known credential.
            val throwawaySecret = UUID.randomUUID().toString() + "-Aa1!" + UUID.randomUUID()
            val passwordHash = withContext(Dispatchers.Default) { hasher.hash(throwawaySecret) }
            val entity = UserEntity(
                login = stableLogin,
                passwordHash = passwordHash,
                displayName = cleanName,
                role = Role.GUEST,
                languageCode = language.code,
                hotelId = hotelId,
                roomNumber = roomNumber
            )
            val id = userDao.insert(entity)
            audit.log(id, "GUEST_QR_CREATED", "hotel=$hotelId, room=$roomNumber")
            entity.copy(id = id).toDomain()
        }
    }

    override suspend fun getUser(id: Long): User? = userDao.findById(id)?.toDomain()

    override suspend fun hasAnyUser(): Boolean = userDao.count() > 0

    override suspend fun createInitialAdmin(
        login: String,
        password: String,
        displayName: String
    ): Result<User> = safeCall {
        if (userDao.count() > 0) throw AppException(R.string.err_system_configured)
        val hash = withContext(Dispatchers.Default) { hasher.hash(password) }
        val entity = UserEntity(
            login = login,
            passwordHash = hash,
            displayName = displayName,
            role = Role.ADMIN,
            languageCode = "ru"
        )
        val id = userDao.insert(entity)
        audit.log(id, "ADMIN_CREATED")
        entity.copy(id = id).toDomain()
    }

    override suspend fun verifyPassword(password: String): Result<Unit> = safeCall {
        val current = guard.requireUser()
        val entity = userDao.findById(current.id) ?: throw AppException(R.string.err_account_not_found)
        authenticate(entity, password, R.string.err_bad_password)
    }

    override suspend fun changePassword(oldPassword: String, newPassword: String): Result<Unit> = safeCall {
        val current = guard.requireUser()
        val entity = userDao.findById(current.id) ?: throw AppException(R.string.err_account_not_found)
        authenticate(entity, oldPassword, R.string.err_old_password_wrong)
        PasswordPolicy.validate(newPassword, entity.login)?.let { throw AppException(it) }
        if (newPassword == oldPassword) throw AppException(R.string.err_new_password_same)
        val hash = withContext(Dispatchers.Default) { hasher.hash(newPassword) }
        userDao.updatePasswordHash(entity.id, hash)
        audit.log(entity.id, "PASSWORD_CHANGED")
    }

    /**
     * Проверка пароля с защитой от перебора: после [MAX_ATTEMPTS] ошибок подряд
     * учётная запись блокируется на [LOCK_MS]. Хеш сравнивается за постоянное время.
     */
    private suspend fun authenticate(entity: UserEntity, password: String, badPasswordMessage: Int) {
        val now = System.currentTimeMillis()
        if (entity.lockedUntil > now) {
            val minutes = ((entity.lockedUntil - now) / 60_000 + 1).toInt()
            throw AppException(R.string.err_locked_wait, minutes)
        }
        val ok = withContext(Dispatchers.Default) { hasher.verify(password, entity.passwordHash) }
        if (!ok) {
            val attempts = entity.failedAttempts + 1
            if (attempts >= MAX_ATTEMPTS) {
                userDao.updateAttempts(entity.id, 0, now + LOCK_MS)
                audit.log(entity.id, "ACCOUNT_LOCKED")
                throw AppException(UiText.Res(R.string.err_locked_now))
            }
            userDao.updateAttempts(entity.id, attempts, 0)
            audit.log(entity.id, "AUTH_FAILED", "attempt=$attempts")
            throw AppException(badPasswordMessage)
        }
        if (entity.failedAttempts != 0 || entity.lockedUntil != 0L) {
            userDao.updateAttempts(entity.id, 0, 0)
        }
        if (hasher.needsRehash(entity.passwordHash)) {
            val newHash = withContext(Dispatchers.Default) { hasher.hash(password) }
            userDao.updatePasswordHash(entity.id, newHash)
        }
    }

    private companion object {
        const val MAX_ATTEMPTS = 5
        const val LOCK_MS = 15L * 60 * 1000
    }
}
