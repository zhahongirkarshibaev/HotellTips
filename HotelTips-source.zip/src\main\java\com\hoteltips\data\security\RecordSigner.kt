package com.hoteltips.data.security

import android.util.Base64
import com.hoteltips.data.local.entity.TipEntity
import com.hoteltips.data.local.entity.WithdrawalEntity
import java.security.MessageDigest

/**
 * Подпись финансовых записей (HMAC-SHA256, ключ в Keystore).
 * Запись, изменённая или добавленная в обход приложения, не пройдёт проверку
 * и не будет учтена в балансе; при попытке вывода операция блокируется.
 */
class RecordSigner(private val keystore: KeystoreManager) {

    fun signTip(
        employeeId: Long,
        guestUserId: Long,
        roomNumber: Int,
        amount: Long,
        message: String,
        languageCode: String,
        createdAt: Long
    ): String = sign("tip|$employeeId|$guestUserId|$roomNumber|$amount|$createdAt|$languageCode|$message")

    fun signWithdrawal(employeeId: Long, amount: Long, createdAt: Long): String =
        sign("withdrawal|$employeeId|$amount|$createdAt")

    fun verify(tip: TipEntity): Boolean = matches(
        tip.signature,
        signTip(
            tip.employeeId, tip.guestUserId, tip.roomNumber, tip.amount,
            tip.message, tip.languageCode, tip.createdAt
        )
    )

    fun verify(withdrawal: WithdrawalEntity): Boolean = matches(
        withdrawal.signature,
        signWithdrawal(withdrawal.employeeId, withdrawal.amount, withdrawal.createdAt)
    )

    private fun sign(payload: String): String =
        Base64.encodeToString(keystore.hmac(payload.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)

    private fun matches(actual: String, expected: String): Boolean =
        MessageDigest.isEqual(actual.toByteArray(Charsets.UTF_8), expected.toByteArray(Charsets.UTF_8))
}
