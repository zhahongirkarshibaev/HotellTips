package com.hoteltips.ui.common

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hoteltips.domain.model.Hotel
import com.hoteltips.ui.theme.AppShapes
import com.hoteltips.ui.theme.NavyBorder
import com.hoteltips.ui.theme.Teal

/** Карточка выбора: подсвечивается рамкой и фоном, когда выбрана. */
@Composable
fun SelectCard(
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = AppShapes.card,
        color = if (selected) Teal.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surface,
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Teal else NavyBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            content = content
        )
    }
}

/** Сетка из двух колонок без вложенной прокрутки (карточки в ряду одной высоты). */
@Composable
fun <T> TwoColumnGrid(
    items: List<T>,
    modifier: Modifier = Modifier,
    itemContent: @Composable (T) -> Unit
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items.chunked(2).forEach { row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                row.forEach { item ->
                    Box(Modifier.weight(1f).fillMaxHeight()) { itemContent(item) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

/** "Город, Страна" на выбранном языке. */
fun Hotel.placeLabel(languageCode: String): String {
    val cityName = city?.name?.forLanguage(languageCode) ?: cityCode
    val countryName = country?.name?.forLanguage(languageCode) ?: countryCode
    return "$cityName, $countryName"
}
