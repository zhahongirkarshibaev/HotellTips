package com.hoteltips.domain.model

data class Employee(
    val id: Long,
    val userId: Long,
    val hotelId: Long,
    val fullName: String,
    val position: String,
    val roomFrom: Int,
    val roomTo: Int
) {
    /** "Ман Ле" -> "М.Л" */
    val initials: String
        get() = fullName.split(" ")
            .filter { it.isNotBlank() }
            .take(2)
            .joinToString(".") { it.first().uppercase() }

    val roomsLabel: String
        get() = if (roomFrom == roomTo) "$roomFrom" else "$roomFrom–$roomTo"

    fun serves(room: Int): Boolean = room in roomFrom..roomTo
}

/** Данные формы администратора. password == null или пусто при редактировании = не менять. */
data class EmployeeDraft(
    val hotelId: Long,
    val fullName: String,
    val position: String,
    val roomFrom: Int,
    val roomTo: Int,
    val login: String,
    val password: String?
)

data class EmployeeSummary(
    val employee: Employee,
    val hotel: Hotel?,
    val totalTips: Long,
    val tipsCount: Int,
    val complaintsCount: Int
) {
    val currency: Currency get() = hotel?.currency ?: Currency.VND
}
