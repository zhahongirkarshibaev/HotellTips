package com.hoteltips.domain.model

enum class Role { ADMIN, GUEST, EMPLOYEE }

data class User(
    val id: Long,
    val login: String,
    val displayName: String,
    val role: Role,
    val languageCode: String,
    /** Отель и номер комнаты — только у гостя. */
    val hotelId: Long?,
    val roomNumber: Int?
)

/** Языки интерфейса. Тот же язык используется для сообщений гостя. */
enum class AppLanguage(val code: String, val nativeName: String, val flag: String) {
    RUSSIAN("ru", "Русский", "🇷🇺"),
    ENGLISH("en", "English", "🇬🇧"),
    JAPANESE("ja", "日本語", "🇯🇵"),
    CHINESE("zh", "中文", "🇨🇳");

    companion object {
        private val EXTRA_FLAGS = mapOf("vi" to "🇻🇳", "ko" to "🇰🇷", "th" to "🇹🇭")

        fun fromCode(code: String?): AppLanguage? = entries.firstOrNull { it.code == code }

        /** Флаг для кода языка из старых данных тоже подбирается. */
        fun flagFor(code: String): String = fromCode(code)?.flag ?: EXTRA_FLAGS[code] ?: "🌐"
    }
}
