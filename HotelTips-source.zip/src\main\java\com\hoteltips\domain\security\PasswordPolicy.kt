package com.hoteltips.domain.security

import com.hoteltips.R
import com.hoteltips.domain.common.UiText

/**
 * Политика паролей (усиленная):
 *  - минимум 10 символов;
 *  - хотя бы одна строчная, одна заглавная, одна цифра и один спецсимвол;
 *  - не совпадает с логином;
 *  - не из списка самых частых.
 */
object PasswordPolicy {
    const val MIN_LENGTH = 10
    private const val MAX_LENGTH = 128

    private val SPECIAL = Regex("""[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?`~]""")

    private val COMMON = setOf(
        "12345678", "123456789", "1234567890", "11111111", "password", "password1",
        "qwerty123", "qwertyui", "admin123", "iloveyou1", "letmein123",
        "password12", "password123", "welcome1", "welcome12", "abc123456",
        "qwerty1234", "admin1234", "admin12345", "passw0rd", "p@ssw0rd",
        "p@ssword1", "changeme1", "letmein12", "monkey123", "dragon123",
        "master123", "login1234", "starwars1", "football1", "baseball1",
        "trustno1", "whatever1", "1234qwer", "1q2w3e4r", "q1w2e3r4",
        "admin@123", "admin!123", "root123456", "user123456", "test123456",
        "pass123456", "default1!", "summer2024", "summer2025", "winter2024",
        "lotus2026", "hotel1234", "hoteltips1"
    )

    /** Возвращает ошибку или null, если пароль подходит. */
    fun validate(password: String, login: String? = null): UiText? = when {
        password.length < MIN_LENGTH -> UiText.res(R.string.pw_too_short, MIN_LENGTH)
        password.length > MAX_LENGTH -> UiText.res(R.string.pw_too_long)
        password.none { it.isLowerCase() } -> UiText.res(R.string.pw_need_lower)
        password.none { it.isUpperCase() } -> UiText.res(R.string.pw_need_upper)
        password.none { it.isDigit() } -> UiText.res(R.string.pw_need_digit)
        !SPECIAL.containsMatchIn(password) -> UiText.res(R.string.pw_need_special)
        login != null && password.equals(login, ignoreCase = true) -> UiText.res(R.string.pw_same_as_login)
        password.lowercase() in COMMON -> UiText.res(R.string.pw_too_common)
        login != null && password.lowercase().startsWith(login.lowercase()) &&
            password.drop(login.length).all { it.isDigit() || it in "!@#" } ->
            UiText.res(R.string.pw_too_common)
        else -> null
    }
}
