package com.hoteltips.domain.model

/** Название на четырёх языках интерфейса. */
data class LocalizedName(val ru: String, val en: String, val ja: String, val zh: String) {
    fun forLanguage(code: String): String = when (code) {
        "ru" -> ru
        "ja" -> ja
        "zh" -> zh
        else -> en
    }
}

private fun n(ru: String, en: String, ja: String, zh: String) = LocalizedName(ru, en, ja, zh)

/**
 * Валюты стран региона. Суммы хранятся в целых единицах валюты.
 * Быстрые суммы и лимиты подобраны ориентировочно (примерно 1–20 USD на чаевые)
 * и при необходимости правятся здесь, в одном месте.
 */
enum class Currency(
    val code: String,
    val symbol: String,
    val presets: List<Long>,
    val minTip: Long,
    val maxTip: Long,
    val maxPerDay: Long
) {
    VND("VND", "₫", listOf(20_000L, 50_000L, 100_000L), 10_000L, 10_000_000L, 20_000_000L),
    THB("THB", "฿", listOf(20L, 50L, 100L), 10L, 5_000L, 10_000L),
    LAK("LAK", "₭", listOf(10_000L, 20_000L, 50_000L), 5_000L, 5_000_000L, 10_000_000L),
    KHR("KHR", "៛", listOf(2_000L, 5_000L, 10_000L), 1_000L, 1_000_000L, 2_000_000L),
    MMK("MMK", "Ks", listOf(1_000L, 2_000L, 5_000L), 500L, 500_000L, 1_000_000L),
    MYR("MYR", "RM", listOf(5L, 10L, 20L), 2L, 1_000L, 2_000L),
    SGD("SGD", "S$", listOf(2L, 5L, 10L), 1L, 500L, 1_000L),
    IDR("IDR", "Rp", listOf(10_000L, 20_000L, 50_000L), 5_000L, 6_000_000L, 12_000_000L),
    PHP("PHP", "₱", listOf(50L, 100L, 200L), 20L, 20_000L, 40_000L),
    BND("BND", "B$", listOf(2L, 5L, 10L), 1L, 500L, 1_000L)
}

data class City(val code: String, val name: LocalizedName)

data class Country(
    val code: String,
    val flag: String,
    val currency: Currency,
    val name: LocalizedName,
    val cities: List<City>
)

/** Справочник стран и городов Юго-Восточной Азии. Отели хранятся в БД и добавляются администратором. */
object Geo {

    val countries: List<Country> = listOf(
        Country(
            "VN", "🇻🇳", Currency.VND, n("Вьетнам", "Vietnam", "ベトナム", "越南"),
            listOf(
                City("VN-HAN", n("Ханой", "Hanoi", "ハノイ", "河内")),
                City("VN-SGN", n("Хошимин", "Ho Chi Minh City", "ホーチミン", "胡志明市")),
                City("VN-DAD", n("Дананг", "Da Nang", "ダナン", "岘港")),
                City("VN-NHA", n("Нячанг", "Nha Trang", "ニャチャン", "芽庄")),
                City("VN-PQC", n("Фукуок", "Phu Quoc", "フーコック島", "富国岛")),
                City("VN-HOI", n("Хойан", "Hoi An", "ホイアン", "会安"))
            )
        ),
        Country(
            "TH", "🇹🇭", Currency.THB, n("Таиланд", "Thailand", "タイ", "泰国"),
            listOf(
                City("TH-BKK", n("Бангкок", "Bangkok", "バンコク", "曼谷")),
                City("TH-HKT", n("Пхукет", "Phuket", "プーケット", "普吉岛")),
                City("TH-PYX", n("Паттайя", "Pattaya", "パタヤ", "芭堤雅")),
                City("TH-CNX", n("Чиангмай", "Chiang Mai", "チェンマイ", "清迈")),
                City("TH-KBV", n("Краби", "Krabi", "クラビ", "甲米")),
                City("TH-USM", n("Самуи", "Koh Samui", "サムイ島", "苏梅岛"))
            )
        ),
        Country(
            "LA", "🇱🇦", Currency.LAK, n("Лаос", "Laos", "ラオス", "老挝"),
            listOf(
                City("LA-VTE", n("Вьентьян", "Vientiane", "ビエンチャン", "万象")),
                City("LA-LPQ", n("Луангпрабанг", "Luang Prabang", "ルアンパバーン", "琅勃拉邦"))
            )
        ),
        Country(
            "KH", "🇰🇭", Currency.KHR, n("Камбоджа", "Cambodia", "カンボジア", "柬埔寨"),
            listOf(
                City("KH-PNH", n("Пномпень", "Phnom Penh", "プノンペン", "金边")),
                City("KH-REP", n("Сиемреап", "Siem Reap", "シェムリアップ", "暹粒")),
                City("KH-KOS", n("Сиануквиль", "Sihanoukville", "シアヌークビル", "西哈努克市"))
            )
        ),
        Country(
            "MM", "🇲🇲", Currency.MMK, n("Мьянма", "Myanmar", "ミャンマー", "缅甸"),
            listOf(
                City("MM-RGN", n("Янгон", "Yangon", "ヤンゴン", "仰光")),
                City("MM-MDL", n("Мандалай", "Mandalay", "マンダレー", "曼德勒")),
                City("MM-BAG", n("Баган", "Bagan", "バガン", "蒲甘"))
            )
        ),
        Country(
            "MY", "🇲🇾", Currency.MYR, n("Малайзия", "Malaysia", "マレーシア", "马来西亚"),
            listOf(
                City("MY-KUL", n("Куала-Лумпур", "Kuala Lumpur", "クアラルンプール", "吉隆坡")),
                City("MY-PEN", n("Пенанг", "Penang", "ペナン", "槟城")),
                City("MY-LGK", n("Лангкави", "Langkawi", "ランカウイ", "兰卡威")),
                City("MY-BKI", n("Кота-Кинабалу", "Kota Kinabalu", "コタキナバル", "亚庇"))
            )
        ),
        Country(
            "SG", "🇸🇬", Currency.SGD, n("Сингапур", "Singapore", "シンガポール", "新加坡"),
            listOf(City("SG-SIN", n("Сингапур", "Singapore", "シンガポール", "新加坡")))
        ),
        Country(
            "ID", "🇮🇩", Currency.IDR, n("Индонезия", "Indonesia", "インドネシア", "印度尼西亚"),
            listOf(
                City("ID-DPS", n("Бали", "Bali", "バリ島", "巴厘岛")),
                City("ID-JKT", n("Джакарта", "Jakarta", "ジャカルタ", "雅加达")),
                City("ID-JOG", n("Джокьякарта", "Yogyakarta", "ジョグジャカルタ", "日惹")),
                City("ID-LOP", n("Ломбок", "Lombok", "ロンボク島", "龙目岛"))
            )
        ),
        Country(
            "PH", "🇵🇭", Currency.PHP, n("Филиппины", "Philippines", "フィリピン", "菲律宾"),
            listOf(
                City("PH-MNL", n("Манила", "Manila", "マニラ", "马尼拉")),
                City("PH-CEB", n("Себу", "Cebu", "セブ", "宿务")),
                City("PH-MPH", n("Боракай", "Boracay", "ボラカイ島", "长滩岛")),
                City("PH-PPS", n("Палаван", "Palawan", "パラワン島", "巴拉望岛"))
            )
        ),
        Country(
            "BN", "🇧🇳", Currency.BND, n("Бруней", "Brunei", "ブルネイ", "文莱"),
            listOf(
                City("BN-BWN", n("Бандар-Сери-Бегаван", "Bandar Seri Begawan", "バンダルスリブガワン", "斯里巴加湾市"))
            )
        )
    )

    fun country(code: String): Country? = countries.firstOrNull { it.code == code }

    fun city(countryCode: String, cityCode: String): City? =
        country(countryCode)?.cities?.firstOrNull { it.code == cityCode }
}

data class Hotel(
    val id: Long,
    val countryCode: String,
    val cityCode: String,
    val name: String
) {
    val country: Country? get() = Geo.country(countryCode)
    val city: City? get() = Geo.city(countryCode, cityCode)
    val currency: Currency get() = country?.currency ?: Currency.VND
}
