package com.hoteltips.domain.usecase

import com.hoteltips.domain.model.Employee
import com.hoteltips.domain.model.Tip
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.Clock
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.temporal.ChronoUnit

class DashboardCalculatorTest {

    private val now = Instant.parse("2026-10-12T10:00:00Z")
    private val clock = Clock.fixed(now, ZoneOffset.UTC)
    private val employee = Employee(1, 1, 1, "Ман Ле", "Горничная", 401, 430)

    private fun tip(id: Long, amount: Long, daysAgo: Long) = Tip(
        id = id,
        employeeId = 1,
        guestUserId = 10,
        roomNumber = 410,
        amount = amount,
        message = "",
        languageCode = "ru",
        createdAt = now.minus(2, ChronoUnit.HOURS).minus(daysAgo, ChronoUnit.DAYS)
    )

    @Test
    fun availableIsTotalMinusWithdrawn() {
        val tips = listOf(tip(1, 100_000, 0), tip(2, 50_000, 3))
        val result = DashboardCalculator.build(employee, null, tips, withdrawn = 30_000, clock = clock)
        assertEquals(120_000L, result.available)
    }

    @Test
    fun periodsIncludeOnlyTheirDays() {
        val tips = listOf(
            tip(1, 10_000, 0),   // сегодня
            tip(2, 20_000, 6),   // в пределах 7 дней
            tip(3, 40_000, 7),   // только 30 дней
            tip(4, 80_000, 29),  // граница 30 дней
            tip(5, 160_000, 30)  // за пределами
        )
        val result = DashboardCalculator.build(employee, null, tips, 0, clock)
        assertEquals(10_000L, result.today)
        assertEquals(30_000L, result.last7Days)
        assertEquals(150_000L, result.last30Days)
    }

    @Test
    fun weekHasSevenDaysEndingToday() {
        val result = DashboardCalculator.build(employee, null, listOf(tip(1, 5_000, 2)), 0, clock)
        assertEquals(7, result.week.size)
        assertEquals(LocalDate.of(2026, 10, 12), result.week.last().date)
        assertEquals(LocalDate.of(2026, 10, 6), result.week.first().date)
        assertEquals(5_000L, result.week[4].amount) // 2 дня назад
    }
}
