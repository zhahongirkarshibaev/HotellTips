package com.hoteltips.data.security

import android.util.Base64
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Криптографическая привязка QR-кода номера.
 *
 * Формат deep link:
 *   hoteltips://guest?v=1&hotelId={id}&room={n}&sig={base64url}
 *
 * Каноническая строка для подписи: `v1|{hotelId}|{roomNumber}`
 *
 * Без сервера compile-time material + R8 — практичный компромисс;
 * при подключении backend замените на JWT/JWS от сервера.
 */
class QrSigner(private val keystore: KeystoreManager) {

    fun sign(hotelId: Long, roomNumber: Int): String {
        val canonical = canonical(hotelId, roomNumber)
        val inner = appHmac(canonical.toByteArray(Charsets.UTF_8))
        val outer = keystore.hmac(inner)
        return b64Url(outer)
    }

    fun verify(hotelId: Long, roomNumber: Int, signature: String): Boolean {
        if (signature.isBlank()) return false
        val canonical = canonical(hotelId, roomNumber)
        val expectedDual = runCatching {
            b64Url(keystore.hmac(appHmac(canonical.toByteArray(Charsets.UTF_8))))
        }.getOrNull()
        val expectedApp = b64Url(appHmac(canonical.toByteArray(Charsets.UTF_8)))
        return constantTimeEquals(signature, expectedDual) ||
            constantTimeEquals(signature, expectedApp)
    }

    fun buildDeepLink(hotelId: Long, roomNumber: Int): String {
        require(hotelId > 0L && roomNumber in 1..999_999)
        val sig = sign(hotelId, roomNumber)
        return "hoteltips://guest?v=1&hotelId=$hotelId&room=$roomNumber&sig=$sig"
    }

    fun signAppOnly(hotelId: Long, roomNumber: Int): String =
        b64Url(appHmac(canonical(hotelId, roomNumber).toByteArray(Charsets.UTF_8)))

    companion object {
        fun canonical(hotelId: Long, roomNumber: Int): String = "v1|$hotelId|$roomNumber"

        private val APP_MATERIAL: ByteArray = byteArrayOf(
            0x48, 0x6f, 0x74, 0x65, 0x6c, 0x54, 0x69, 0x70,
            0x73, 0x51, 0x52, 0x76, 0x31, 0x2d, 0x32, 0x30,
            0x32, 0x36, 0x21, 0x6b, 0x39, 0x4d, 0x78, 0x51,
            0x7a, 0x4c, 0x70, 0x33, 0x52, 0x6e, 0x57, 0x38
        )

        private fun appHmac(data: ByteArray): ByteArray {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(APP_MATERIAL, "HmacSHA256"))
            return mac.doFinal(data)
        }

        private fun b64Url(bytes: ByteArray): String =
            Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

        private fun constantTimeEquals(a: String, b: String?): Boolean {
            if (b == null) return false
            return MessageDigest.isEqual(
                a.toByteArray(Charsets.UTF_8),
                b.toByteArray(Charsets.UTF_8)
            )
        }
    }
}
