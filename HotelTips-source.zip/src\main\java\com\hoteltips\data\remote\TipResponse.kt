package com.hoteltips.data.remote

data class TipResponse(
    val id: Int,
    val hotel_id: String,
    val employee_id: String? = null,
    val room_number: String?,
    val amount: Double,
    val currency: String,
    val guest_name: String?,
    val message: String?,
    val payment_status: String,
    val created_at: String
)