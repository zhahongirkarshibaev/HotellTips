package com.hoteltips.data.local

import android.content.Context
import androidx.room.Room
import com.hoteltips.data.security.DatabaseKeyProvider
import com.hoteltips.data.security.KeystoreManager
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

/**
 * Создаёт БД, зашифрованную SQLCipher (AES-256). Файл базы на диске — набор случайных байт:
 * без ключа из Android Keystore ни логины, ни хеши, ни суммы прочитать нельзя.
 * Приложение хранится в приватной папке, недоступной другим приложениям.
 */
object DatabaseFactory {
    fun create(context: Context, keystore: KeystoreManager): AppDatabase {
        System.loadLibrary("sqlcipher")
        // Старая БД из первой версии лежала без шифрования — удаляем.
        context.deleteDatabase(AppDatabase.LEGACY_NAME)

        val passphrase = DatabaseKeyProvider(context, keystore, AppDatabase.NAME).getOrCreate()
        return Room.databaseBuilder(context, AppDatabase::class.java, AppDatabase.NAME)
            .openHelperFactory(SupportOpenHelperFactory(passphrase))
            // Версия 1 — тестовая сборка без отелей; её демо-данные пересоздаются.
            // С выходом в продакшн схему нужно менять только через Migration.
            .fallbackToDestructiveMigrationFrom(1)
            .build()
    }
}
