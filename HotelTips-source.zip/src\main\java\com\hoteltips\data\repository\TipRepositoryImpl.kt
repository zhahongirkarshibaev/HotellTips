package com.hoteltips.data.repository

import androidx.room.withTransaction
import com.hoteltips.R
import com.hoteltips.data.local.AppDatabase
import com.hoteltips.data.local.entity.TipEntity
import com.hoteltips.data.local.entity.WithdrawalEntity
import com.hoteltips.data.mapper.toDomain
import com.hoteltips.data.security.AuditLogger
import com.hoteltips.data.security.Ledger
import com.hoteltips.data.security.RecordSigner
import com.hoteltips.data.security.guardedFlow
import com.hoteltips.domain.common.AppException
import com.hoteltips.domain.common.safeCall
import com.hoteltips.domain.model.Currency
import com.hoteltips.domain.model.Geo
import com.hoteltips.domain.model.NewTip
import com.hoteltips.domain.model.Role
import com.hoteltips.domain.model.Tip
import com.hoteltips.domain.model.TipLimits
import com.hoteltips.domain.model.User
import com.hoteltips.domain.repository.TipRepository
import com.hoteltips.domain.security.AccessGuard
import com.hoteltips.util.toMoney
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant

class TipRepositoryImpl(
    private val db: AppDatabase,
    private val guard: AccessGuard,
    private val signer: RecordSigner,
    private val ledger: Ledger,
    private val audit: AuditLogger
) : TipRepository {

    private val tipDao = db.tipDao()
    private val withdrawalDao = db.withdrawalDao()
    private val employeeDao = db.employeeDao()
    private val hotelDao = db.hotelDao()

    override suspend fun checkTipAllowed(employeeId: Long, amount: Long): Result<Unit> = safeCall {
        val guest = guard.requireRole(Role.GUEST)
        validateTip(guest, employeeId, amount)
    }

    override suspend fun addTip(tip: NewTip): Result<Unit> = safeCall {
        val guest = guard.requireRole(Role.GUEST)
        // Гость может отправлять чаевые только от своего имени и из своей комнаты.
        if (tip.guestUserId != guest.id || tip.roomNumber != guest.roomNumber) {
            audit.log(guest.id, "TIP_REJECTED_IDENTITY")
            throw AppException(R.string.err_no_access)
        }
        db.withTransaction {
            validateTip(guest, tip.employeeId, tip.amount)
            val now = Instant.now().toEpochMilli()
            tipDao.insert(
                TipEntity(
                    employeeId = tip.employeeId,
                    guestUserId = tip.guestUserId,
                    roomNumber = tip.roomNumber,
                    amount = tip.amount,
                    message = tip.message,
                    languageCode = tip.languageCode,
                    createdAt = now,
                    signature = signer.signTip(
                        tip.employeeId, tip.guestUserId, tip.roomNumber,
                        tip.amount, tip.message, tip.languageCode, now
                    )
                )
            )
        }
        audit.log(guest.id, "TIP_SENT", "employeeId=${tip.employeeId}, amount=${tip.amount}")
    }

    /** Права, диапазон суммы в валюте отеля и антифрод-лимиты. */
    private suspend fun validateTip(guest: User, employeeId: Long, amount: Long) {
        val room = guest.roomNumber ?: throw AppException(R.string.err_room_missing)
        val employee = employeeDao.findById(employeeId) ?: throw AppException(R.string.err_employee_not_found)
        if (employee.hotelId != guest.hotelId || room !in employee.roomFrom..employee.roomTo) {
            audit.log(guest.id, "TIP_REJECTED_WRONG_EMPLOYEE", "employeeId=$employeeId")
            throw AppException(R.string.err_not_serving_room)
        }
        val currency = currencyOf(employee.hotelId)
        if (amount !in currency.minTip..currency.maxTip) {
            throw AppException(
                R.string.err_tip_range, currency.minTip.toMoney(currency), currency.maxTip.toMoney(currency)
            )
        }
        val now = Instant.now().toEpochMilli()
        val perHour = tipDao.countByGuestSince(guest.id, now - HOUR_MS)
        if (perHour >= TipLimits.MAX_COUNT_PER_HOUR) {
            audit.log(guest.id, "TIP_RATE_LIMIT")
            throw AppException(R.string.err_rate_limit_hour)
        }
        val perDay = tipDao.sumByGuestSince(guest.id, now - DAY_MS)
        if (perDay + amount > currency.maxPerDay) {
            audit.log(guest.id, "TIP_DAILY_LIMIT")
            throw AppException(R.string.err_daily_limit, currency.maxPerDay.toMoney(currency))
        }
    }

    private suspend fun currencyOf(hotelId: Long): Currency =
        hotelDao.findById(hotelId)?.let { Geo.country(it.countryCode)?.currency } ?: Currency.VND

    override fun observeTips(employeeId: Long): Flow<List<Tip>> =
        guard.guardedFlow(
            fallback = emptyList(),
            allow = { user -> canAccessEmployee(user, employeeId) }
        ) {
            // В список попадают только записи с верной подписью.
            tipDao.observeForEmployee(employeeId).map { list ->
                list.filter { signer.verify(it) }.map { it.toDomain() }
            }
        }

    override fun observeWithdrawnTotal(employeeId: Long): Flow<Long> =
        guard.guardedFlow(
            fallback = 0L,
            allow = { user -> canAccessEmployee(user, employeeId) }
        ) {
            withdrawalDao.observeForEmployee(employeeId).map { list ->
                list.filter { signer.verify(it) }.sumOf { it.amount }
            }
        }

    override suspend fun withdrawAll(employeeId: Long): Result<Long> = safeCall {
        val user = guard.requireRole(Role.EMPLOYEE)
        val employee = employeeDao.findById(employeeId)
        if (employee == null || employee.userId != user.id) {
            audit.log(user.id, "WITHDRAW_REJECTED_NOT_OWNER", "employeeId=$employeeId")
            throw AppException(R.string.err_no_access)
        }
        // Предварительная проверка вне транзакции, чтобы запись в журнал не откатилась.
        if (ledger.balanceOf(employeeId).tampered) {
            audit.log(user.id, "TAMPERING_DETECTED", "employeeId=$employeeId on withdraw")
            throw AppException(R.string.err_tampered_withdraw)
        }
        db.withTransaction {
            val balance = ledger.balanceOf(employeeId)
            if (balance.tampered) throw AppException(R.string.err_tampered_withdraw)
            val available = balance.available
            if (available <= 0L) throw AppException(R.string.err_no_funds)
            val now = Instant.now().toEpochMilli()
            withdrawalDao.insert(
                WithdrawalEntity(
                    employeeId = employeeId,
                    amount = available,
                    createdAt = now,
                    signature = signer.signWithdrawal(employeeId, available, now)
                )
            )
            available
        }.also { amount -> audit.log(user.id, "WITHDRAWAL", "amount=$amount") }
    }

    private suspend fun canAccessEmployee(user: User, employeeId: Long): Boolean {
        if (user.role == Role.ADMIN) return true
        return user.role == Role.EMPLOYEE && employeeDao.findById(employeeId)?.userId == user.id
    }

    private companion object {
        const val HOUR_MS = 60L * 60 * 1000
        const val DAY_MS = 24L * HOUR_MS
    }
}
