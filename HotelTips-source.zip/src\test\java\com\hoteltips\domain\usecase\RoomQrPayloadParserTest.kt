package com.hoteltips.domain.usecase

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RoomQrPayloadParserTest {

    private val acceptAny: (Long, Int, String) -> Boolean = { _, _, sig -> sig.isNotBlank() }
    private val rejectAll: (Long, Int, String) -> Boolean = { _, _, _ -> false }

    @Test
    fun parsesSignedTipHotelDeepLink() {
        assertEquals(
            com.hoteltips.domain.model.RoomQrPayload(hotelId = 12L, roomNumber = 410),
            RoomQrPayloadParser.parse(
                "hoteltips://guest?v=1&hotelId=12&room=410&sig=abcDEFghiJKLmnop",
                acceptAny
            )
        )
    }

    @Test
    fun parsesHttpsLinkWithAliases() {
        assertEquals(
            com.hoteltips.domain.model.RoomQrPayload(hotelId = 3L, roomNumber = 120),
            RoomQrPayloadParser.parse(
                "https://tiphotel.app/guest?v=1&hotel_id=3&room_number=120&sig=xyz_sig-value",
                acceptAny
            )
        )
    }

    @Test
    fun rejectsUnsignedDeepLink() {
        assertNull(
            RoomQrPayloadParser.parse("hoteltips://guest?hotelId=12&room=410", acceptAny)
        )
    }

    @Test
    fun rejectsJsonPayloadWithoutSignature() {
        assertNull(
            RoomQrPayloadParser.parse("{\"hotelId\":8,\"roomNumber\":512}", acceptAny)
        )
    }

    @Test
    fun rejectsWhenVerifierFails() {
        assertNull(
            RoomQrPayloadParser.parse(
                "hoteltips://guest?v=1&hotelId=12&room=410&sig=bad",
                rejectAll
            )
        )
    }

    @Test
    fun rejectsWhenVerifierIsNull() {
        assertNull(
            RoomQrPayloadParser.parse("hoteltips://guest?v=1&hotelId=12&room=410&sig=abc")
        )
    }

    @Test
    fun rejectsBareRoomNumber() {
        assertNull(RoomQrPayloadParser.parse("410", acceptAny))
    }

    @Test
    fun rejectsIncompleteAndInvalidPayloads() {
        assertNull(RoomQrPayloadParser.parse("hotelId=2&sig=x", acceptAny))
        assertNull(RoomQrPayloadParser.parse("hotelId=0&room=410&sig=x", acceptAny))
        assertNull(RoomQrPayloadParser.parse("hotelId=2&room=0&sig=x", acceptAny))
        assertNull(RoomQrPayloadParser.parse("x".repeat(5000), acceptAny))
    }
}
