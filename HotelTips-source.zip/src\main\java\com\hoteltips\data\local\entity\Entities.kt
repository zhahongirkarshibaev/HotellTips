package com.hoteltips.data.local.entity

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.hoteltips.domain.model.FeedbackType
import com.hoteltips.domain.model.Role

@Entity(tableName = "hotels", indices = [Index("countryCode", "cityCode")])
data class HotelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val countryCode: String,
    val cityCode: String,
    val name: String
)

@Entity(
    tableName = "users",
    foreignKeys = [
        ForeignKey(
            entity = HotelEntity::class,
            parentColumns = ["id"],
            childColumns = ["hotelId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["login"], unique = true), Index("hotelId")]
)
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Всегда в нижнем регистре. */
    val login: String,
    /** Строка формата v1$итерации$соль$хеш. Пароль восстановить из неё нельзя. */
    val passwordHash: String,
    val displayName: String,
    val role: Role,
    val languageCode: String,
    /** Отель и комната — только у гостя. */
    val hotelId: Long? = null,
    val roomNumber: Int? = null,
    val failedAttempts: Int = 0,
    /** Время (мс), до которого вход заблокирован после серии неудачных попыток. */
    val lockedUntil: Long = 0
)

@Entity(
    tableName = "employees",
    foreignKeys = [
        ForeignKey(
            entity = UserEntity::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = HotelEntity::class,
            parentColumns = ["id"],
            childColumns = ["hotelId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["userId"], unique = true), Index("hotelId")]
)
data class EmployeeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val hotelId: Long,
    val fullName: String,
    val position: String,
    val roomFrom: Int,
    val roomTo: Int
)

@Entity(
    tableName = "tips",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("employeeId")]
)
data class TipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val guestUserId: Long,
    val roomNumber: Int,
    val amount: Long,
    val message: String,
    val languageCode: String,
    val createdAt: Long,
    /** HMAC записи (ключ в Keystore) — защита от подделки. */
    val signature: String
)

@Entity(
    tableName = "feedback",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("employeeId")]
)
data class FeedbackEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val guestUserId: Long,
    val roomNumber: Int,
    val type: FeedbackType,
    val text: String,
    val languageCode: String,
    val createdAt: Long
)

@Entity(
    tableName = "withdrawals",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("employeeId")]
)
data class WithdrawalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val amount: Long,
    val createdAt: Long,
    val signature: String
)

@Entity(tableName = "audit_log", indices = [Index("createdAt")])
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long?,
    val action: String,
    /** Никогда не содержит паролей, хешей и других секретов. */
    val details: String,
    val createdAt: Long
)

/** Результат агрегирующего запроса для списка администратора. */
data class EmployeeSummaryRow(
    @Embedded val employee: EmployeeEntity,
    val totalTips: Long,
    val tipsCount: Int,
    val complaintsCount: Int
)
