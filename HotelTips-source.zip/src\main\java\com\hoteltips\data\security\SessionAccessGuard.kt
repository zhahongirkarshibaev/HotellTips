package com.hoteltips.data.security

import com.hoteltips.R
import com.hoteltips.domain.common.AppException
import com.hoteltips.domain.model.Role
import com.hoteltips.domain.model.User
import com.hoteltips.domain.repository.SessionRepository
import com.hoteltips.domain.security.AccessGuard
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow

class SessionAccessGuard(private val session: SessionRepository) : AccessGuard {

    override fun currentUserOrNull(): User? = session.currentUser

    override fun requireUser(): User =
        session.currentUser ?: throw AppException(R.string.err_login_required)

    override fun requireRole(vararg roles: Role): User {
        val user = requireUser()
        if (user.role !in roles) throw AppException(R.string.err_no_access)
        return user
    }
}

/**
 * Поток данных с проверкой прав в момент подписки. Если права нет — отдаёт [fallback]
 * (пустой результат) и никаких чужих данных не раскрывает.
 */
fun <T> AccessGuard.guardedFlow(
    fallback: T,
    allow: suspend (User) -> Boolean,
    source: () -> Flow<T>
): Flow<T> = flow {
    val user = currentUserOrNull()
    if (user != null && allow(user)) emitAll(source()) else emit(fallback)
}
