package com.hoteltips.data.security

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Ключи живут в Android Keystore (аппаратно, где доступно) и **не покидают** его:
 * приложение получает лишь результат операции, но не сам ключ.
 *  • AES-256-GCM — шифрование ключа БД и сессии;
 *  • HMAC-SHA256 — «перец» для паролей, подписи финансовых записей и QR.
 *
 * Ключи требуют разблокировки устройства (PIN/биометрия). После успешной
 * аутентификации ключ можно использовать без повторного запроса в течение
 * [AUTH_VALIDITY_SECONDS] секунд — чтобы не дергать биометрию на каждый хеш.
 *
 * Алиасы v2: при обновлении со старой версии ключи пересоздаются
 * (старая БД станет недоступна — ожидаемо для pre-production).
 */
class KeystoreManager {

    private val keyStore: KeyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    @Synchronized
    private fun aesKey(): SecretKey {
        (keyStore.getKey(AES_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        generator.init(buildAesSpec())
        return generator.generateKey()
    }

    @Synchronized
    private fun hmacKey(): SecretKey {
        (keyStore.getKey(HMAC_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, PROVIDER)
        generator.init(buildHmacSpec())
        return generator.generateKey()
    }

    private fun buildAesSpec(): KeyGenParameterSpec {
        val builder = KeyGenParameterSpec.Builder(
            AES_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
        applyUserAuth(builder)
        return builder.build()
    }

    private fun buildHmacSpec(): KeyGenParameterSpec {
        val builder = KeyGenParameterSpec.Builder(HMAC_ALIAS, KeyProperties.PURPOSE_SIGN)
        applyUserAuth(builder)
        return builder.build()
    }

    private fun applyUserAuth(builder: KeyGenParameterSpec.Builder) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            builder.setUserAuthenticationParameters(
                AUTH_VALIDITY_SECONDS,
                KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL
            )
        } else {
            @Suppress("DEPRECATION")
            builder
                .setUserAuthenticationRequired(true)
                .setUserAuthenticationValidityDurationSeconds(AUTH_VALIDITY_SECONDS)
        }
    }

    fun encrypt(plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(AES_MODE)
        cipher.init(Cipher.ENCRYPT_MODE, aesKey())
        return cipher.iv + cipher.doFinal(plain)
    }

    fun decrypt(data: ByteArray): ByteArray {
        require(data.size > IV_SIZE) { "Повреждённые данные" }
        val cipher = Cipher.getInstance(AES_MODE)
        cipher.init(
            Cipher.DECRYPT_MODE,
            aesKey(),
            GCMParameterSpec(TAG_BITS, data, 0, IV_SIZE)
        )
        return cipher.doFinal(data, IV_SIZE, data.size - IV_SIZE)
    }

    fun hmac(data: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(hmacKey())
        return mac.doFinal(data)
    }

    private companion object {
        const val PROVIDER = "AndroidKeyStore"
        const val AES_ALIAS = "hoteltips_aes_v2"
        const val HMAC_ALIAS = "hoteltips_hmac_v2"
        const val AES_MODE = "AES/GCM/NoPadding"
        const val IV_SIZE = 12
        const val TAG_BITS = 128
        const val AUTH_VALIDITY_SECONDS = 120
    }
}
