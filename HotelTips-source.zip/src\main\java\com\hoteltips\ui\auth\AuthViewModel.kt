package com.hoteltips.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hoteltips.R
import com.hoteltips.domain.common.UiText
import com.hoteltips.domain.common.toUiText
import com.hoteltips.domain.model.AppLanguage
import com.hoteltips.domain.model.City
import com.hoteltips.domain.model.Country
import com.hoteltips.domain.model.Geo
import com.hoteltips.domain.model.Hotel
import com.hoteltips.domain.model.RoomQrPayload
import com.hoteltips.domain.repository.AuthRepository
import com.hoteltips.domain.repository.HotelRepository
import com.hoteltips.domain.repository.SessionRepository
import com.hoteltips.domain.usecase.CreateInitialAdminUseCase
import com.hoteltips.domain.usecase.EnterGuestFromQrUseCase
import com.hoteltips.data.security.QrSigner
import com.hoteltips.domain.usecase.RoomQrPayloadParser
import com.hoteltips.domain.usecase.RegisterGuestUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AuthMode { LOGIN, REGISTER, SETUP }

/** Шаги регистрации гостя. */
enum class RegStep { LANGUAGE, COUNTRY, CITY, HOTEL, DETAILS }

data class AuthUiState(
    val mode: AuthMode = AuthMode.LOGIN,
    val step: RegStep = RegStep.LANGUAGE,
    val hotels: List<Hotel> = emptyList(),
    val hotelsLoaded: Boolean = false,
    val countryCode: String? = null,
    val cityCode: String? = null,
    val hotelId: Long? = null,
    val login: String = "",
    val password: String = "",
    val confirmPassword: String = "",
    val displayName: String = "",
    val room: String = "",
    val isLoading: Boolean = false,
    val error: UiText? = null,
    val pendingQr: RoomQrPayload? = null,
    val isQrSubmitting: Boolean = false,
    val qrError: UiText? = null
) {
    /** Только страны, где уже подключены отели, — тупиков в выборе не бывает. */
    val countries: List<Country>
        get() = Geo.countries.filter { c -> hotels.any { it.countryCode == c.code } }

    val cities: List<City>
        get() {
            val code = countryCode ?: return emptyList()
            return Geo.country(code)?.cities.orEmpty()
                .filter { city -> hotels.any { it.countryCode == code && it.cityCode == city.code } }
        }

    val cityHotels: List<Hotel>
        get() = hotels.filter { it.countryCode == countryCode && it.cityCode == cityCode }

    fun hotelsInCity(cityCode: String): Int =
        hotels.count { it.countryCode == countryCode && it.cityCode == cityCode }

    val selectedHotel: Hotel? get() = hotels.firstOrNull { it.id == hotelId }

    val canGoNext: Boolean
        get() = when (step) {
            RegStep.LANGUAGE -> true
            RegStep.COUNTRY -> countryCode != null
            RegStep.CITY -> cityCode != null
            RegStep.HOTEL -> hotelId != null
            RegStep.DETAILS -> false
        }
}

class AuthViewModel(
    initialMode: AuthMode,
    private val auth: AuthRepository,
    hotels: HotelRepository,
    private val registerGuest: RegisterGuestUseCase,
    private val createInitialAdmin: CreateInitialAdminUseCase,
    private val enterGuestFromQr: EnterGuestFromQrUseCase,
    private val session: SessionRepository,
    private val currentLanguage: () -> AppLanguage,
    private val qrSigner: QrSigner
) : ViewModel() {

    private val _state = MutableStateFlow(AuthUiState(mode = initialMode))
    val state: StateFlow<AuthUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            hotels.observeAll().collect { list ->
                _state.update { it.copy(hotels = list, hotelsLoaded = true) }
            }
        }
    }

    // ---- поля формы ----
    fun onLoginChange(v: String) = _state.update { it.copy(login = v, error = null) }
    fun onPasswordChange(v: String) = _state.update { it.copy(password = v, error = null) }
    fun onConfirmChange(v: String) = _state.update { it.copy(confirmPassword = v, error = null) }
    fun onNameChange(v: String) = _state.update { it.copy(displayName = v, error = null) }
    fun onRoomChange(v: String) =
        _state.update { it.copy(room = v.filter(Char::isDigit).take(5), error = null) }

    fun onToggleMode() = _state.update {
        if (it.mode == AuthMode.SETUP) it
        else it.copy(
            mode = if (it.mode == AuthMode.LOGIN) AuthMode.REGISTER else AuthMode.LOGIN,
            step = RegStep.LANGUAGE,
            password = "",
            confirmPassword = "",
            error = null
        )
    }

    // ---- QR-вход гостя ----
    fun onQrScanned(rawValue: String) {
        val payload = RoomQrPayloadParser.parse(rawValue, qrSigner::verify)
        if (payload == null) {
            _state.update { it.copy(pendingQr = null, isQrSubmitting = false, qrError = UiText.res(R.string.err_qr_invalid)) }
            return
        }
        _state.update { it.copy(pendingQr = payload, qrError = null, error = null) }
    }

    /** Called when Google Play services could not start the scanner or camera scanning failed. */
    fun onQrScanFailed() {
        _state.update { it.copy(qrError = UiText.res(R.string.err_qr_scan_failed)) }
    }

    fun onDismissQr() = _state.update { it.copy(pendingQr = null, qrError = null, isQrSubmitting = false) }

    fun onDismissQrError() = _state.update { it.copy(qrError = null) }

    fun onConfirmQrGuest(displayName: String) {
        val current = _state.value
        val payload = current.pendingQr ?: return
        if (current.isQrSubmitting) return
        _state.update { it.copy(isQrSubmitting = true, qrError = null) }
        viewModelScope.launch {
            enterGuestFromQr(payload, displayName, currentLanguage())
                .onSuccess { user ->
                    // Do not leave guest details or QR state in the auth form after switching roots.
                    _state.update {
                        AuthUiState(
                            mode = AuthMode.LOGIN,
                            hotels = it.hotels,
                            hotelsLoaded = it.hotelsLoaded
                        )
                    }
                    session.start(user)
                }
                .onFailure { error ->
                    _state.update {
                        it.copy(isQrSubmitting = false, qrError = error.toUiText())
                    }
                }
        }
    }

    // ---- шаги регистрации ----
    fun onSelectCountry(code: String) = _state.update { s ->
        val country = Geo.country(code)
        val available = s.copy(countryCode = code, cityCode = null, hotelId = null, error = null).cities
        if (country != null && available.size == 1) {
            // Единственный город (например, Сингапур) выбираем сами и сразу идём к отелям.
            s.copy(
                countryCode = code, cityCode = available.first().code,
                hotelId = null, step = RegStep.HOTEL, error = null
            )
        } else {
            s.copy(countryCode = code, cityCode = null, hotelId = null, step = RegStep.CITY, error = null)
        }
    }

    fun onSelectCity(code: String) = _state.update {
        it.copy(cityCode = code, hotelId = null, step = RegStep.HOTEL, error = null)
    }

    fun onSelectHotel(id: Long) = _state.update {
        it.copy(hotelId = id, step = RegStep.DETAILS, error = null)
    }

    fun onNext() = _state.update { s ->
        if (!s.canGoNext) return@update s
        val next = when (s.step) {
            RegStep.LANGUAGE -> RegStep.COUNTRY
            RegStep.COUNTRY -> RegStep.CITY
            RegStep.CITY -> RegStep.HOTEL
            RegStep.HOTEL -> RegStep.DETAILS
            RegStep.DETAILS -> RegStep.DETAILS
        }
        s.copy(step = next, error = null)
    }

    /** Назад по шагам; с первого шага — к экрану входа. */
    fun onBack() = _state.update { s ->
        when (s.step) {
            RegStep.LANGUAGE -> s.copy(mode = AuthMode.LOGIN, error = null)
            RegStep.COUNTRY -> s.copy(step = RegStep.LANGUAGE, error = null)
            RegStep.CITY -> s.copy(step = RegStep.COUNTRY, error = null)
            RegStep.HOTEL ->
                // Если у страны один город, шаг выбора города пропускался.
                s.copy(step = if (s.cities.size == 1) RegStep.COUNTRY else RegStep.CITY, error = null)
            RegStep.DETAILS -> s.copy(step = RegStep.HOTEL, error = null)
        }
    }

    fun onSubmit() {
        val s = _state.value
        if (s.isLoading) return
        if (s.mode != AuthMode.LOGIN && s.password != s.confirmPassword) {
            _state.update { it.copy(error = UiText.res(R.string.err_passwords_mismatch)) }
            return
        }
        _state.update { it.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            val result = when (s.mode) {
                AuthMode.LOGIN -> auth.login(s.login, s.password)
                AuthMode.REGISTER -> registerGuest(
                    login = s.login,
                    password = s.password,
                    displayName = s.displayName,
                    hotelId = s.hotelId,
                    roomNumber = s.room.toIntOrNull(),
                    // Язык аккаунта — тот, что выбран в интерфейсе (шаг 1 или кнопка с флагом).
                    language = currentLanguage()
                )
                AuthMode.SETUP -> createInitialAdmin(s.login, s.password, s.displayName)
            }
            result
                .onSuccess { user ->
                    // Сразу стираем введённые данные: после выхода форма должна быть пустой.
                    _state.update {
                        AuthUiState(mode = AuthMode.LOGIN, hotels = it.hotels, hotelsLoaded = true)
                    }
                    session.start(user)
                }
                .onFailure { e ->
                    _state.update {
                        it.copy(
                            isLoading = false,
                            password = "",
                            confirmPassword = "",
                            error = e.toUiText()
                        )
                    }
                }
        }
    }
}
