package com.hoteltips.domain.usecase

import com.hoteltips.R
import com.hoteltips.domain.common.AppException
import com.hoteltips.domain.model.AppLanguage
import com.hoteltips.domain.model.RoomQrPayload
import com.hoteltips.domain.model.User
import com.hoteltips.domain.repository.AuthRepository

/**
 * Guest access created by scanning a room QR. The installation key is generated locally and
 * persisted by AppContainer; it prevents repeated scans on one device from creating duplicate
 * anonymous users for the same room. It is not a substitute for a signed server-side QR token.
 */
class EnterGuestFromQrUseCase(
    private val auth: AuthRepository,
    private val installationKey: String
) {
    suspend operator fun invoke(
        payload: RoomQrPayload,
        displayName: String,
        language: AppLanguage
    ): Result<User> {
        if (payload.hotelId <= 0 || payload.roomNumber !in 1..999_999) {
            return Result.failure(AppException(R.string.err_qr_invalid))
        }
        val cleanName = displayName.trim()
        if (cleanName.isEmpty()) {
            return Result.failure(AppException(R.string.err_qr_name_required))
        }
        if (cleanName.length > 50) {
            return Result.failure(AppException(R.string.err_qr_name_too_long))
        }
        if (installationKey.isBlank()) {
            return Result.failure(AppException(R.string.err_generic))
        }
        return auth.enterGuestFromQr(
            installationKey = installationKey,
            hotelId = payload.hotelId,
            roomNumber = payload.roomNumber,
            displayName = cleanName,
            language = language
        )
    }
}
