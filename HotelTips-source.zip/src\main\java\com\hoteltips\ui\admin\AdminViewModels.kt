package com.hoteltips.ui.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hoteltips.R
import com.hoteltips.domain.common.UiText
import com.hoteltips.domain.common.toUiText
import com.hoteltips.domain.model.Currency
import com.hoteltips.domain.model.EmployeeDraft
import com.hoteltips.domain.model.EmployeeSummary
import com.hoteltips.domain.model.Hotel
import com.hoteltips.domain.repository.EmployeeRepository
import com.hoteltips.domain.repository.HotelRepository
import com.hoteltips.domain.usecase.SaveEmployeeUseCase
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

// ------------------------------------------------------------------ Список

data class AdminListUiState(
    val isLoading: Boolean = true,
    val employees: List<EmployeeSummary> = emptyList(),
    val hotels: List<Hotel> = emptyList()
) {
    /** Суммы в разных валютах не складываются — показываем по каждой валюте отдельно. */
    val totalsByCurrency: List<Pair<Currency, Long>>
        get() = employees
            .groupBy { it.currency }
            .map { (currency, list) -> currency to list.sumOf { it.totalTips } }
            .sortedBy { it.first.code }

    val totalComplaints: Int get() = employees.sumOf { it.complaintsCount }
}

class AdminListViewModel(
    private val employees: EmployeeRepository,
    private val hotels: HotelRepository
) : ViewModel() {

    val state: StateFlow<AdminListUiState> =
        combine(employees.observeSummaries(), hotels.observeAll()) { emps, hs ->
            AdminListUiState(isLoading = false, employees = emps, hotels = hs)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AdminListUiState())

    private val _events = Channel<UiText>(Channel.BUFFERED)
    val events: Flow<UiText> = _events.receiveAsFlow()

    fun onDeleteEmployee(employeeId: Long) {
        viewModelScope.launch {
            employees.delete(employeeId)
                .onSuccess { _events.trySend(UiText.res(R.string.msg_employee_deleted)) }
                .onFailure { _events.trySend(it.toUiText()) }
        }
    }

    fun onDeleteHotel(hotelId: Long) {
        viewModelScope.launch {
            hotels.delete(hotelId)
                .onSuccess { _events.trySend(UiText.res(R.string.msg_hotel_deleted)) }
                .onFailure { _events.trySend(it.toUiText()) }
        }
    }
}

// ------------------------------------------------------- Редактирование сотрудника

data class AdminEditUiState(
    val isNew: Boolean = true,
    val isLoading: Boolean = false,
    val isSaving: Boolean = false,
    val hotels: List<Hotel> = emptyList(),
    val hotelId: Long? = null,
    val fullName: String = "",
    val position: String = "",
    val roomFrom: String = "",
    val roomTo: String = "",
    val login: String = "",
    val password: String = "",
    val error: UiText? = null
) {
    val selectedHotel: Hotel? get() = hotels.firstOrNull { it.id == hotelId }
}

sealed interface AdminEditEvent {
    data object Saved : AdminEditEvent
    data class Message(val text: UiText) : AdminEditEvent
}

class AdminEditViewModel(
    private val employeeId: Long?,
    private val employees: EmployeeRepository,
    hotels: HotelRepository,
    private val saveEmployee: SaveEmployeeUseCase
) : ViewModel() {

    private val _state = MutableStateFlow(
        AdminEditUiState(isNew = employeeId == null, isLoading = employeeId != null)
    )
    val state: StateFlow<AdminEditUiState> = _state.asStateFlow()

    private val _events = Channel<AdminEditEvent>(Channel.BUFFERED)
    val events: Flow<AdminEditEvent> = _events.receiveAsFlow()

    init {
        viewModelScope.launch {
            hotels.observeAll().collect { list -> _state.update { it.copy(hotels = list) } }
        }
        if (employeeId != null) {
            viewModelScope.launch {
                val draft = employees.getDraft(employeeId)
                if (draft == null) {
                    _events.trySend(AdminEditEvent.Message(UiText.res(R.string.err_employee_not_found)))
                    _events.trySend(AdminEditEvent.Saved)
                } else {
                    _state.update {
                        it.copy(
                            isLoading = false,
                            hotelId = draft.hotelId,
                            fullName = draft.fullName,
                            position = draft.position,
                            roomFrom = draft.roomFrom.toString(),
                            roomTo = draft.roomTo.toString(),
                            login = draft.login
                        )
                    }
                }
            }
        }
    }

    fun onHotel(id: Long) = _state.update { it.copy(hotelId = id, error = null) }
    fun onFullName(v: String) = _state.update { it.copy(fullName = v, error = null) }
    fun onPosition(v: String) = _state.update { it.copy(position = v, error = null) }
    fun onRoomFrom(v: String) = _state.update { it.copy(roomFrom = v.filter(Char::isDigit).take(5), error = null) }
    fun onRoomTo(v: String) = _state.update { it.copy(roomTo = v.filter(Char::isDigit).take(5), error = null) }
    fun onLogin(v: String) = _state.update { it.copy(login = v, error = null) }
    fun onPassword(v: String) = _state.update { it.copy(password = v, error = null) }

    fun onSave() {
        val s = _state.value
        if (s.isSaving) return
        val from = s.roomFrom.toIntOrNull()
        val to = s.roomTo.toIntOrNull()
        if (from == null || to == null) {
            _state.update { it.copy(error = UiText.res(R.string.err_rooms_numbers)) }
            return
        }
        _state.update { it.copy(isSaving = true, error = null) }
        viewModelScope.launch {
            val draft = EmployeeDraft(
                hotelId = s.hotelId ?: 0,
                fullName = s.fullName,
                position = s.position,
                roomFrom = from,
                roomTo = to,
                login = s.login,
                password = s.password
            )
            saveEmployee(employeeId, draft)
                .onSuccess {
                    _events.trySend(
                        AdminEditEvent.Message(
                            UiText.res(if (employeeId == null) R.string.msg_employee_added else R.string.msg_saved)
                        )
                    )
                    _events.trySend(AdminEditEvent.Saved)
                }
                .onFailure { e -> _state.update { it.copy(error = e.toUiText()) } }
            _state.update { it.copy(isSaving = false) }
        }
    }
}

// ------------------------------------------------------------ Редактирование отеля

data class AdminHotelEditUiState(
    val isNew: Boolean = true,
    val isLoading: Boolean = false,
    val isSaving: Boolean = false,
    val countryCode: String? = null,
    val cityCode: String? = null,
    val name: String = "",
    val error: UiText? = null
)

class AdminHotelEditViewModel(
    private val hotelId: Long?,
    private val hotels: HotelRepository
) : ViewModel() {

    private val _state = MutableStateFlow(
        AdminHotelEditUiState(isNew = hotelId == null, isLoading = hotelId != null)
    )
    val state: StateFlow<AdminHotelEditUiState> = _state.asStateFlow()

    private val _events = Channel<AdminEditEvent>(Channel.BUFFERED)
    val events: Flow<AdminEditEvent> = _events.receiveAsFlow()

    init {
        if (hotelId != null) {
            viewModelScope.launch {
                val hotel = hotels.observeById(hotelId).first()
                if (hotel == null) {
                    _events.trySend(AdminEditEvent.Message(UiText.res(R.string.err_hotel_not_found)))
                    _events.trySend(AdminEditEvent.Saved)
                } else {
                    _state.update {
                        it.copy(
                            isLoading = false,
                            countryCode = hotel.countryCode,
                            cityCode = hotel.cityCode,
                            name = hotel.name
                        )
                    }
                }
            }
        }
    }

    fun onCountry(code: String) = _state.update {
        if (!it.isNew) it else it.copy(countryCode = code, cityCode = null, error = null)
    }

    fun onCity(code: String) = _state.update { if (!it.isNew) it else it.copy(cityCode = code, error = null) }
    fun onName(v: String) = _state.update { it.copy(name = v.take(80), error = null) }

    fun onSave() {
        val s = _state.value
        if (s.isSaving) return
        val country = s.countryCode
        val city = s.cityCode
        if (hotelId == null && (country == null || city == null)) {
            _state.update { it.copy(error = UiText.res(R.string.err_hotel_choose_place)) }
            return
        }
        _state.update { it.copy(isSaving = true, error = null) }
        viewModelScope.launch {
            val result =
                if (hotelId == null) hotels.create(country!!, city!!, s.name) else hotels.rename(hotelId, s.name)
            result
                .onSuccess {
                    _events.trySend(
                        AdminEditEvent.Message(
                            UiText.res(if (hotelId == null) R.string.msg_hotel_added else R.string.msg_saved)
                        )
                    )
                    _events.trySend(AdminEditEvent.Saved)
                }
                .onFailure { e -> _state.update { it.copy(error = e.toUiText()) } }
            _state.update { it.copy(isSaving = false) }
        }
    }
}
