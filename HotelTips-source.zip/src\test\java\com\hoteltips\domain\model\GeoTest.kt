package com.hoteltips.domain.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GeoTest {

    @Test
    fun countryAndCityCodesAreUnique() {
        val countryCodes = Geo.countries.map { it.code }
        assertEquals(countryCodes.size, countryCodes.toSet().size)
        val cityCodes = Geo.countries.flatMap { c -> c.cities.map { it.code } }
        assertEquals(cityCodes.size, cityCodes.toSet().size)
    }

    @Test
    fun everyCountryHasCitiesAndNamesInAllLanguages() {
        Geo.countries.forEach { country ->
            assertTrue("${country.code} без городов", country.cities.isNotEmpty())
            listOf("ru", "en", "ja", "zh").forEach { lang ->
                assertTrue(country.name.forLanguage(lang).isNotBlank())
                country.cities.forEach { assertTrue(it.name.forLanguage(lang).isNotBlank()) }
            }
        }
    }

    @Test
    fun cityCodesStartWithCountryCode() {
        Geo.countries.forEach { country ->
            country.cities.forEach { assertTrue(it.code.startsWith(country.code + "-")) }
        }
    }

    @Test
    fun currencyLimitsAreConsistent() {
        Currency.entries.forEach { c ->
            assertEquals(3, c.presets.size)
            assertTrue(c.minTip in 1..c.maxTip)
            assertTrue(c.maxTip <= c.maxPerDay)
            c.presets.forEach { assertTrue("${c.code}: ${it}", it in c.minTip..c.maxTip) }
        }
    }

    @Test
    fun hotelResolvesCurrencyFromCountry() {
        assertEquals(Currency.THB, Hotel(1, "TH", "TH-BKK", "X").currency)
        assertEquals(Currency.VND, Hotel(2, "VN", "VN-DAD", "Y").currency)
        assertNotNull(Hotel(3, "SG", "SG-SIN", "Z").city)
    }
}
