package com.hoteltips.ui.admin

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.hoteltips.R
import com.hoteltips.di.AppContainer
import com.hoteltips.domain.model.EmployeeSummary
import com.hoteltips.domain.model.Geo
import com.hoteltips.domain.model.Hotel
import com.hoteltips.ui.account.ChangePasswordHost
import com.hoteltips.ui.common.AppCard
import com.hoteltips.ui.common.ConfirmDialog
import com.hoteltips.ui.common.EmptyState
import com.hoteltips.ui.common.GradientHeader
import com.hoteltips.ui.common.HeaderActions
import com.hoteltips.ui.common.InitialsAvatar
import com.hoteltips.ui.common.LoadingBox
import com.hoteltips.ui.common.LocalAppLanguage
import com.hoteltips.ui.common.SectionTitle
import com.hoteltips.ui.common.SelectCard
import com.hoteltips.ui.common.asString
import com.hoteltips.ui.common.placeLabel
import com.hoteltips.ui.common.toContentPadding
import com.hoteltips.ui.common.vmFactory
import com.hoteltips.ui.theme.Cyan
import com.hoteltips.ui.theme.Danger
import com.hoteltips.util.toMoney

private object Routes {
    const val LIST = "home"
    const val EMPLOYEE_NEW = "employee/edit"
    const val EMPLOYEE_EDIT = "employee/edit/{id}"
    const val HOTEL_NEW = "hotel/edit"
    const val HOTEL_EDIT = "hotel/edit/{id}"
    fun employee(id: Long) = "employee/edit/$id"
    fun hotel(id: Long) = "hotel/edit/$id"
}

@Composable
fun AdminRoot(container: AppContainer, onLogout: () -> Unit) {
    val nav = rememberNavController()
    val idArg = listOf(navArgument("id") { type = NavType.LongType })

    NavHost(navController = nav, startDestination = Routes.LIST) {
        composable(Routes.LIST) {
            val vm: AdminListViewModel = viewModel(
                factory = vmFactory {
                    AdminListViewModel(container.employeeRepository, container.hotelRepository)
                }
            )
            var showChangePassword by remember { mutableStateOf(false) }
            AdminListScreen(
                vm = vm,
                onAddEmployee = { nav.navigate(Routes.EMPLOYEE_NEW) },
                onEditEmployee = { nav.navigate(Routes.employee(it)) },
                onAddHotel = { nav.navigate(Routes.HOTEL_NEW) },
                onEditHotel = { nav.navigate(Routes.hotel(it)) },
                onChangePassword = { showChangePassword = true },
                onLogout = onLogout
            )
            ChangePasswordHost(
                container = container,
                visible = showChangePassword,
                onDismiss = { showChangePassword = false }
            )
        }
        composable(Routes.EMPLOYEE_NEW) {
            EmployeeEditRoute(container, employeeId = null, onClose = { nav.popBackStack() })
        }
        composable(Routes.EMPLOYEE_EDIT, arguments = idArg) { entry ->
            EmployeeEditRoute(
                container,
                employeeId = entry.arguments?.getLong("id"),
                onClose = { nav.popBackStack() }
            )
        }
        composable(Routes.HOTEL_NEW) {
            HotelEditRoute(container, hotelId = null, onClose = { nav.popBackStack() })
        }
        composable(Routes.HOTEL_EDIT, arguments = idArg) { entry ->
            HotelEditRoute(
                container,
                hotelId = entry.arguments?.getLong("id"),
                onClose = { nav.popBackStack() }
            )
        }
    }
}

// ------------------------------------------------------------------ Список

@Composable
private fun AdminListScreen(
    vm: AdminListViewModel,
    onAddEmployee: () -> Unit,
    onEditEmployee: (Long) -> Unit,
    onAddHotel: () -> Unit,
    onEditHotel: (Long) -> Unit,
    onChangePassword: () -> Unit,
    onLogout: () -> Unit
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var employeeToDelete by remember { mutableStateOf<EmployeeSummary?>(null) }
    var hotelToDelete by remember { mutableStateOf<Hotel?>(null) }
    val context = LocalContext.current

    LaunchedEffect(vm) { vm.events.collect { snackbar.showSnackbar(it.asString(context)) } }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = if (tab == 0) onAddEmployee else onAddHotel,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = stringResource(
                        if (tab == 0) R.string.cd_add_employee else R.string.cd_add_hotel
                    )
                )
            }
        }
    ) { padding ->
        if (state.isLoading) {
            LoadingBox()
            return@Scaffold
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = padding.calculateTopPadding() + 16.dp,
                // Запас под FAB, чтобы он не закрывал последнюю карточку.
                bottom = padding.calculateBottomPadding() + 96.dp
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                GradientHeader {
                    Column(Modifier.weight(1f)) {
                        Text(
                            stringResource(R.string.admin_title),
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            stringResource(R.string.admin_summary, state.employees.size, state.hotels.size),
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White.copy(alpha = 0.92f)
                        )
                    }
                    HeaderActions(onChangePassword, onLogout)
                }
            }
            item {
                AppCard {
                    Text(
                        stringResource(R.string.admin_total_tips),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    if (state.totalsByCurrency.isEmpty()) {
                        Text("—", style = MaterialTheme.typography.headlineMedium)
                    } else {
                        state.totalsByCurrency.forEach { (currency, sum) ->
                            Text(sum.toMoney(currency), style = MaterialTheme.typography.headlineMedium)
                        }
                    }
                    if (state.totalComplaints > 0) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            stringResource(R.string.admin_complaints, state.totalComplaints),
                            color = Danger,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        label = { Text(stringResource(R.string.admin_tab_employees, state.employees.size)) }
                    )
                    FilterChip(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        label = { Text(stringResource(R.string.admin_tab_hotels, state.hotels.size)) }
                    )
                }
            }
            if (tab == 0) {
                if (state.employees.isEmpty()) {
                    item {
                        EmptyState(
                            title = stringResource(R.string.admin_no_employees_title),
                            hint = stringResource(
                                if (state.hotels.isEmpty()) R.string.admin_no_employees_need_hotel
                                else R.string.admin_no_employees_hint
                            )
                        )
                    }
                } else {
                    items(state.employees, key = { "e${it.employee.id}" }) { summary ->
                        EmployeeAdminCard(
                            summary = summary,
                            onEdit = { onEditEmployee(summary.employee.id) },
                            onDelete = { employeeToDelete = summary }
                        )
                    }
                }
            } else {
                if (state.hotels.isEmpty()) {
                    item {
                        EmptyState(
                            title = stringResource(R.string.admin_no_hotels_title),
                            hint = stringResource(R.string.admin_no_hotels_hint)
                        )
                    }
                } else {
                    items(state.hotels, key = { "h${it.id}" }) { hotel ->
                        HotelAdminCard(
                            hotel = hotel,
                            onEdit = { onEditHotel(hotel.id) },
                            onDelete = { hotelToDelete = hotel }
                        )
                    }
                }
            }
        }
    }

    employeeToDelete?.let { summary ->
        ConfirmDialog(
            title = stringResource(R.string.delete_employee_title),
            text = stringResource(R.string.delete_employee_text, summary.employee.fullName),
            confirmText = stringResource(R.string.action_delete),
            onConfirm = {
                vm.onDeleteEmployee(summary.employee.id)
                employeeToDelete = null
            },
            onDismiss = { employeeToDelete = null }
        )
    }
    hotelToDelete?.let { hotel ->
        ConfirmDialog(
            title = stringResource(R.string.delete_hotel_title),
            text = stringResource(R.string.delete_hotel_text, hotel.name),
            confirmText = stringResource(R.string.action_delete),
            onConfirm = {
                vm.onDeleteHotel(hotel.id)
                hotelToDelete = null
            },
            onDismiss = { hotelToDelete = null }
        )
    }
}

@Composable
private fun EmployeeAdminCard(
    summary: EmployeeSummary,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val e = summary.employee
    val lang = LocalAppLanguage.current
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            InitialsAvatar(e.initials, size = 48.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(e.fullName, style = MaterialTheme.typography.titleMedium)
                Text(
                    "${e.position} · ${stringResource(R.string.rooms_label, e.roomsLabel)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                summary.hotel?.let { hotel ->
                    Text(
                        "${hotel.country?.flag.orEmpty()} ${hotel.name} · ${hotel.placeLabel(lang.code)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.cd_edit))
            }
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = stringResource(R.string.cd_delete),
                    tint = Danger
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                summary.totalTips.toMoney(summary.currency),
                color = Cyan,
                fontWeight = FontWeight.ExtraBold,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.width(10.dp))
            Text(
                stringResource(R.string.admin_tips_count, summary.tipsCount),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (summary.complaintsCount > 0) {
                Spacer(Modifier.weight(1f))
                Text(
                    stringResource(R.string.admin_complaints_short, summary.complaintsCount),
                    style = MaterialTheme.typography.labelMedium,
                    color = Danger
                )
            }
        }
    }
}

@Composable
private fun HotelAdminCard(hotel: Hotel, onEdit: () -> Unit, onDelete: () -> Unit) {
    val lang = LocalAppLanguage.current
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(hotel.country?.flag ?: "🏨", fontSize = 30.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(hotel.name, style = MaterialTheme.typography.titleMedium)
                Text(
                    "${hotel.placeLabel(lang.code)} · ${hotel.currency.code}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = stringResource(R.string.cd_edit))
            }
            IconButton(onClick = onDelete) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = stringResource(R.string.cd_delete),
                    tint = Danger
                )
            }
        }
    }
}

// ------------------------------------------------------------- Сотрудник: форма

@Composable
private fun EmployeeEditRoute(container: AppContainer, employeeId: Long?, onClose: () -> Unit) {
    val vm: AdminEditViewModel = viewModel(
        key = "admin-edit-${employeeId ?: "new"}",
        factory = vmFactory {
            AdminEditViewModel(
                employeeId, container.employeeRepository, container.hotelRepository, container.saveEmployee
            )
        }
    )
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(vm) {
        vm.events.collect { event ->
            when (event) {
                AdminEditEvent.Saved -> onClose()
                is AdminEditEvent.Message -> snackbar.showSnackbar(event.text.asString(context))
            }
        }
    }

    EmployeeEditScreen(
        state = state,
        snackbar = snackbar,
        onBack = onClose,
        vm = vm
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EmployeeEditScreen(
    state: AdminEditUiState,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    vm: AdminEditViewModel
) {
    var pickHotel by remember { mutableStateOf(false) }
    val lang = LocalAppLanguage.current

    FormScaffold(
        title = stringResource(if (state.isNew) R.string.employee_new_title else R.string.employee_edit_title),
        snackbar = snackbar,
        onBack = onBack,
        isLoading = state.isLoading
    ) {
        // Выбор отеля
        Box {
            OutlinedTextField(
                value = state.selectedHotel?.let { "${it.country?.flag.orEmpty()} ${it.name}" }.orEmpty(),
                onValueChange = {},
                readOnly = true,
                label = { Text(stringResource(R.string.field_hotel)) },
                supportingText = {
                    state.selectedHotel?.let { Text(it.placeLabel(lang.code)) }
                },
                modifier = Modifier.fillMaxWidth()
            )
            Box(
                Modifier
                    .matchParentSize()
                    .clickable { pickHotel = true }
            )
        }
        OutlinedTextField(
            value = state.fullName,
            onValueChange = vm::onFullName,
            label = { Text(stringResource(R.string.field_full_name)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = state.position,
            onValueChange = vm::onPosition,
            label = { Text(stringResource(R.string.field_position)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = state.roomFrom,
                onValueChange = vm::onRoomFrom,
                label = { Text(stringResource(R.string.field_rooms_from)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = state.roomTo,
                onValueChange = vm::onRoomTo,
                label = { Text(stringResource(R.string.field_rooms_to)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }
        OutlinedTextField(
            value = state.login,
            onValueChange = vm::onLogin,
            label = { Text(stringResource(R.string.field_login_for_entry)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = state.password,
            onValueChange = vm::onPassword,
            label = {
                Text(stringResource(if (state.isNew) R.string.field_password else R.string.field_new_password))
            },
            supportingText = {
                Text(
                    stringResource(
                        if (state.isNew) R.string.password_hint else R.string.password_keep_hint
                    )
                )
            },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        FormError(state.error?.asString())
        SaveButton(state.isSaving, state.isNew, vm::onSave)
    }

    if (pickHotel) {
        HotelPickerDialog(
            hotels = state.hotels,
            selectedId = state.hotelId,
            onSelect = {
                vm.onHotel(it)
                pickHotel = false
            },
            onDismiss = { pickHotel = false }
        )
    }
}

@Composable
private fun HotelPickerDialog(
    hotels: List<Hotel>,
    selectedId: Long?,
    onSelect: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    val lang = LocalAppLanguage.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.field_hotel)) },
        text = {
            if (hotels.isEmpty()) {
                Text(stringResource(R.string.admin_no_hotels_hint))
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(hotels, key = { it.id }) { hotel ->
                        SelectCard(
                            selected = hotel.id == selectedId,
                            onClick = { onSelect(hotel.id) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(hotel.name, style = MaterialTheme.typography.titleMedium, color = Color.White)
                            Text(
                                "${hotel.country?.flag.orEmpty()} ${hotel.placeLabel(lang.code)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) }
        }
    )
}

// ------------------------------------------------------------------ Отель: форма

@Composable
private fun HotelEditRoute(container: AppContainer, hotelId: Long?, onClose: () -> Unit) {
    val vm: AdminHotelEditViewModel = viewModel(
        key = "admin-hotel-${hotelId ?: "new"}",
        factory = vmFactory { AdminHotelEditViewModel(hotelId, container.hotelRepository) }
    )
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(vm) {
        vm.events.collect { event ->
            when (event) {
                AdminEditEvent.Saved -> onClose()
                is AdminEditEvent.Message -> snackbar.showSnackbar(event.text.asString(context))
            }
        }
    }

    val lang = LocalAppLanguage.current
    FormScaffold(
        title = stringResource(if (state.isNew) R.string.hotel_new_title else R.string.hotel_edit_title),
        snackbar = snackbar,
        onBack = onClose,
        isLoading = state.isLoading
    ) {
        val country = state.countryCode?.let { Geo.country(it) }

        if (state.isNew) {
            SectionTitle(stringResource(R.string.field_country))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Geo.countries, key = { it.code }) { c ->
                    FilterChip(
                        selected = c.code == state.countryCode,
                        onClick = { vm.onCountry(c.code) },
                        label = { Text("${c.flag} ${c.name.forLanguage(lang.code)}") }
                    )
                }
            }
            if (country != null) {
                SectionTitle(stringResource(R.string.field_city))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(country.cities, key = { it.code }) { city ->
                        FilterChip(
                            selected = city.code == state.cityCode,
                            onClick = { vm.onCity(city.code) },
                            label = { Text(city.name.forLanguage(lang.code)) }
                        )
                    }
                }
                Text(
                    stringResource(R.string.hotel_currency_hint, country.currency.code, country.currency.symbol),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else if (country != null) {
            // Страну и город существующего отеля менять нельзя: на них завязаны валюта и балансы.
            AppCard {
                Text(
                    "${country.flag} ${country.name.forLanguage(lang.code)}",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    Geo.city(country.code, state.cityCode.orEmpty())?.name?.forLanguage(lang.code).orEmpty(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    stringResource(R.string.hotel_place_locked),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        OutlinedTextField(
            value = state.name,
            onValueChange = vm::onName,
            label = { Text(stringResource(R.string.field_hotel_name)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        FormError(state.error?.asString())
        SaveButton(state.isSaving, state.isNew, vm::onSave)
    }
}

// ------------------------------------------------------------------ Общие части форм

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FormScaffold(
    title: String,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    isLoading: Boolean,
    content: @Composable ColumnScope.() -> Unit
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        if (isLoading) {
            LoadingBox()
            return@Scaffold
        }
        Column(
            modifier = Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
private fun FormError(text: String?) {
    if (text == null) return
    Text(text, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
}

@Composable
private fun SaveButton(isSaving: Boolean, isNew: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = !isSaving,
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
    ) {
        if (isSaving) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.onPrimary
            )
        } else {
            Text(
                stringResource(if (isNew) R.string.action_add else R.string.action_save),
                fontWeight = FontWeight.Bold
            )
        }
    }
}
