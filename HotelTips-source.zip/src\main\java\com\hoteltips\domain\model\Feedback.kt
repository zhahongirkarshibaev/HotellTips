package com.hoteltips.domain.model

import androidx.annotation.StringRes
import com.hoteltips.R
import java.time.Instant

enum class FeedbackType(@StringRes val titleRes: Int) {
    WISH(R.string.feedback_wish),
    COMPLAINT(R.string.feedback_complaint)
}

data class Feedback(
    val id: Long,
    val employeeId: Long,
    val guestUserId: Long,
    val roomNumber: Int,
    val type: FeedbackType,
    val text: String,
    val languageCode: String,
    val createdAt: Instant
)

data class NewFeedback(
    val employeeId: Long,
    val guestUserId: Long,
    val roomNumber: Int,
    val type: FeedbackType,
    val text: String,
    val languageCode: String
)

object FeedbackLimits {
    const val MAX_LENGTH = 500
}
