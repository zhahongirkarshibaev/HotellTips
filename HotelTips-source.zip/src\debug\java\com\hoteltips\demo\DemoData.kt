package com.hoteltips.demo

import androidx.room.withTransaction
import com.hoteltips.data.local.AppDatabase
import com.hoteltips.data.local.entity.EmployeeEntity
import com.hoteltips.data.local.entity.FeedbackEntity
import com.hoteltips.data.local.entity.HotelEntity
import com.hoteltips.data.local.entity.TipEntity
import com.hoteltips.data.local.entity.UserEntity
import com.hoteltips.data.security.PasswordHasher
import com.hoteltips.data.security.RecordSigner
import com.hoteltips.domain.model.FeedbackType
import com.hoteltips.domain.model.Role
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId

/**
 * ТОЛЬКО DEBUG. Этот файл лежит в src/debug и не попадает в release-сборку —
 * в боевом APK нет ни демо-отелей, ни демо-аккаунтов, ни их паролей.
 * Названия отелей вымышленные (помечены «demo»).
 */
object DemoData {

    val hint: String? =
        "Admin: admin / Admin123!x\n" +
            "Employee (VN, ₫): man / Man12345!x\n" +
            "Employee (TH, ฿): somchai / Somchai123!\n" +
            "Guest VN room 410: anna / Anna12345!\n" +
            "Guest TH room 120: emma / Emma12345!"

    suspend fun seedIfEmpty(db: AppDatabase, hasher: PasswordHasher, signer: RecordSigner) {
        if (db.userDao().count() > 0) return
        withContext(Dispatchers.Default) {
            val admin = user(hasher, "admin", "Admin123!x", "Администратор", Role.ADMIN, "ru")
            val manUser = user(hasher, "man", "Man12345!x", "Ман Ле", Role.EMPLOYEE, "ru")
            val hoaUser = user(hasher, "hoa", "Hoa12345!x", "Нгуен Хоа", Role.EMPLOYEE, "ru")
            val minhUser = user(hasher, "minh", "Minh12345!", "Чан Минь", Role.EMPLOYEE, "ru")
            val somchaiUser = user(hasher, "somchai", "Somchai123!", "Somchai P.", Role.EMPLOYEE, "en")

            db.withTransaction {
                val hotels = db.hotelDao()
                val lotus = hotels.insert(HotelEntity(countryCode = "VN", cityCode = "VN-DAD", name = "Lotus Bay Resort (demo)"))
                hotels.insert(HotelEntity(countryCode = "VN", cityCode = "VN-HAN", name = "Old Quarter Hotel (demo)"))
                hotels.insert(HotelEntity(countryCode = "VN", cityCode = "VN-SGN", name = "Saigon Riverside Hotel (demo)"))
                val bangkok = hotels.insert(HotelEntity(countryCode = "TH", cityCode = "TH-BKK", name = "Chao Phraya Hotel (demo)"))
                hotels.insert(HotelEntity(countryCode = "TH", cityCode = "TH-HKT", name = "Andaman Sunset Resort (demo)"))
                hotels.insert(HotelEntity(countryCode = "SG", cityCode = "SG-SIN", name = "Garden City Hotel (demo)"))
                hotels.insert(HotelEntity(countryCode = "ID", cityCode = "ID-DPS", name = "Rice Terrace Villas (demo)"))

                db.userDao().insert(admin)
                val manId = employee(db, manUser, lotus, "Ман Ле", "Горничная", 401, 430)
                employee(db, hoaUser, lotus, "Нгуен Хоа", "Горничная", 431, 460)
                employee(db, minhUser, lotus, "Чан Минь", "Консьерж", 501, 530)
                val somchaiId = employee(db, somchaiUser, bangkok, "Somchai P.", "Housekeeper", 101, 150)

                val anna = db.userDao().insert(guest(hasher, "anna", "Anna12345!", "Анна", "ru", lotus, 410))
                val tanaka = db.userDao().insert(guest(hasher, "tanaka", "Tanaka123!", "Танака", "ja", lotus, 410))
                val emma = db.userDao().insert(guest(hasher, "emma", "Emma12345!", "Emma", "en", bangkok, 120))

                // Вьетнам, ₫
                tip(db, signer, manId, anna, 410, 100_000, "Спасибо за идеальный номер!", "ru", 4)
                tip(db, signer, manId, anna, 410, 30_000, "Спасибо большое за чистоту, было очень уютно!", "ru", 2)
                tip(db, signer, manId, tanaka, 410, 20_000, "お部屋をきれいにしてくれてありがとうございます。", "ja", 1)
                feedback(db, manId, tanaka, 410, FeedbackType.WISH, "明日の朝、タオルを追加でお願いします。", "ja", 1)
                feedback(
                    db, manId, anna, 410, FeedbackType.COMPLAINT,
                    "Вчера вечером в номере долго не работал кондиционер.", "ru", 2
                )
                // Таиланд, ฿
                tip(db, signer, somchaiId, emma, 120, 200, "Wonderful service, thank you so much!", "en", 1)
                tip(db, signer, somchaiId, emma, 120, 100, "The room was spotless. 谢谢!", "en", 3)
                feedback(db, somchaiId, emma, 120, FeedbackType.WISH, "Could we get extra pillows tomorrow, please?", "en", 1)
            }
        }
    }

    private fun user(
        hasher: PasswordHasher,
        login: String,
        password: String,
        name: String,
        role: Role,
        lang: String
    ) = UserEntity(
        login = login,
        passwordHash = hasher.hash(password),
        displayName = name,
        role = role,
        languageCode = lang
    )

    private fun guest(
        hasher: PasswordHasher,
        login: String,
        password: String,
        name: String,
        lang: String,
        hotelId: Long,
        room: Int
    ) = UserEntity(
        login = login,
        passwordHash = hasher.hash(password),
        displayName = name,
        role = Role.GUEST,
        languageCode = lang,
        hotelId = hotelId,
        roomNumber = room
    )

    private suspend fun employee(
        db: AppDatabase,
        user: UserEntity,
        hotelId: Long,
        name: String,
        position: String,
        from: Int,
        to: Int
    ): Long {
        val userId = db.userDao().insert(user)
        return db.employeeDao().insert(
            EmployeeEntity(
                userId = userId,
                hotelId = hotelId,
                fullName = name,
                position = position,
                roomFrom = from,
                roomTo = to
            )
        )
    }

    private fun noonMillis(daysAgo: Long): Long =
        LocalDate.now().minusDays(daysAgo).atTime(12, 0)
            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    private suspend fun tip(
        db: AppDatabase,
        signer: RecordSigner,
        employeeId: Long,
        guestId: Long,
        room: Int,
        amount: Long,
        message: String,
        lang: String,
        daysAgo: Long
    ) {
        val at = noonMillis(daysAgo)
        db.tipDao().insert(
            TipEntity(
                employeeId = employeeId,
                guestUserId = guestId,
                roomNumber = room,
                amount = amount,
                message = message,
                languageCode = lang,
                createdAt = at,
                signature = signer.signTip(employeeId, guestId, room, amount, message, lang, at)
            )
        )
    }

    private suspend fun feedback(
        db: AppDatabase,
        employeeId: Long,
        guestId: Long,
        room: Int,
        type: FeedbackType,
        text: String,
        lang: String,
        daysAgo: Long
    ) {
        db.feedbackDao().insert(
            FeedbackEntity(
                employeeId = employeeId,
                guestUserId = guestId,
                roomNumber = room,
                type = type,
                text = text,
                languageCode = lang,
                createdAt = noonMillis(daysAgo)
            )
        )
    }
}
