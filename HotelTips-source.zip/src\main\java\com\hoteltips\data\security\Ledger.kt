package com.hoteltips.data.security

import com.hoteltips.data.local.dao.TipDao
import com.hoteltips.data.local.dao.WithdrawalDao

/**
 * Расчёт баланса сотрудника только по записям с верной подписью.
 * [Balance.tampered] = true, если в БД найдены записи, добавленные или изменённые в обход приложения.
 */
class Ledger(
    private val tipDao: TipDao,
    private val withdrawalDao: WithdrawalDao,
    private val signer: RecordSigner
) {
    data class Balance(val earned: Long, val withdrawn: Long, val tampered: Boolean) {
        val available: Long get() = earned - withdrawn
    }

    suspend fun balanceOf(employeeId: Long): Balance {
        val tips = tipDao.getAllForEmployee(employeeId)
        val withdrawals = withdrawalDao.getAllForEmployee(employeeId)
        val validTips = tips.filter { signer.verify(it) }
        val validWithdrawals = withdrawals.filter { signer.verify(it) }
        return Balance(
            earned = validTips.sumOf { it.amount },
            withdrawn = validWithdrawals.sumOf { it.amount },
            tampered = validTips.size != tips.size || validWithdrawals.size != withdrawals.size
        )
    }
}
