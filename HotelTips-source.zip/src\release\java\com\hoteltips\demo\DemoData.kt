package com.hoteltips.demo

import com.hoteltips.data.local.AppDatabase
import com.hoteltips.data.security.PasswordHasher
import com.hoteltips.data.security.RecordSigner

/** Release-версия: демо-данных нет. Первого администратора создаёт владелец при первом запуске. */
@Suppress("UNUSED_PARAMETER")
object DemoData {
    val hint: String? = null

    suspend fun seedIfEmpty(db: AppDatabase, hasher: PasswordHasher, signer: RecordSigner) = Unit
}
