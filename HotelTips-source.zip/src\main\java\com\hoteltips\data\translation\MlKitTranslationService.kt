package com.hoteltips.data.translation

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.hoteltips.R
import com.hoteltips.domain.common.AppException
import com.hoteltips.domain.common.UiText
import com.hoteltips.domain.model.AppLanguage
import com.hoteltips.domain.repository.TranslationService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await

/**
 * Перевод на устройстве через ML Kit: сначала определяем язык текста,
 * затем переводим на язык интерфейса пользователя. Модель каждого языка
 * скачивается один раз (~30 МБ).
 */
class MlKitTranslationService : TranslationService {

    private val identifier by lazy { LanguageIdentification.getClient() }

    override suspend fun translate(text: String, target: AppLanguage): Result<String> {
        return try {
            val sourceTag = identifier.identifyLanguage(text).await()
            if (sourceTag == "und") throw AppException(R.string.err_translate_lang_unknown)
            // Текст уже на нужном языке — переводить нечего.
            if (sourceTag == target.code) return Result.success(text)

            val source = TranslateLanguage.fromLanguageTag(sourceTag)
                ?: throw AppException(R.string.err_translate_lang_unsupported, sourceTag)
            val targetLanguage = TranslateLanguage.fromLanguageTag(target.code)
                ?: throw AppException(R.string.err_translate_lang_unsupported, target.code)

            val translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(source)
                    .setTargetLanguage(targetLanguage)
                    .build()
            )
            try {
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                Result.success(translator.translate(text).await())
            } finally {
                translator.close()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: AppException) {
            Result.failure(e)
        } catch (e: Exception) {
            Result.failure(AppException(UiText.Res(R.string.err_translate_failed), e))
        }
    }
}
