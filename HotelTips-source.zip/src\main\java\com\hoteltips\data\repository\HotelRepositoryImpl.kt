package com.hoteltips.data.repository

import com.hoteltips.R
import com.hoteltips.data.local.dao.HotelDao
import com.hoteltips.data.local.entity.HotelEntity
import com.hoteltips.data.mapper.toDomain
import com.hoteltips.data.security.AuditLogger
import com.hoteltips.domain.common.AppException
import com.hoteltips.domain.common.safeCall
import com.hoteltips.domain.model.Geo
import com.hoteltips.domain.model.Hotel
import com.hoteltips.domain.model.Role
import com.hoteltips.domain.repository.HotelRepository
import com.hoteltips.domain.security.AccessGuard
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class HotelRepositoryImpl(
    private val dao: HotelDao,
    private val guard: AccessGuard,
    private val audit: AuditLogger
) : HotelRepository {

    override fun observeAll(): Flow<List<Hotel>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    override fun observeById(id: Long): Flow<Hotel?> =
        dao.observeById(id).map { it?.toDomain() }

    override suspend fun create(countryCode: String, cityCode: String, name: String): Result<Unit> = safeCall {
        val admin = guard.requireRole(Role.ADMIN)
        if (Geo.city(countryCode, cityCode) == null) throw AppException(R.string.err_hotel_geo_invalid)
        val clean = validName(name)
        if (dao.findByCityAndName(cityCode, clean) != null) throw AppException(R.string.err_hotel_exists)
        val id = dao.insert(HotelEntity(countryCode = countryCode, cityCode = cityCode, name = clean))
        audit.log(admin.id, "HOTEL_CREATED", "hotelId=$id")
    }

    override suspend fun rename(id: Long, name: String): Result<Unit> = safeCall {
        val admin = guard.requireRole(Role.ADMIN)
        val hotel = dao.findById(id) ?: throw AppException(R.string.err_hotel_not_found)
        val clean = validName(name)
        val same = dao.findByCityAndName(hotel.cityCode, clean)
        if (same != null && same.id != id) throw AppException(R.string.err_hotel_exists)
        dao.rename(id, clean)
        audit.log(admin.id, "HOTEL_RENAMED", "hotelId=$id")
    }

    override suspend fun delete(id: Long): Result<Unit> = safeCall {
        val admin = guard.requireRole(Role.ADMIN)
        dao.findById(id) ?: throw AppException(R.string.err_hotel_not_found)
        if (dao.countEmployees(id) > 0 || dao.countGuests(id) > 0) {
            throw AppException(R.string.err_hotel_in_use)
        }
        dao.deleteById(id)
        audit.log(admin.id, "HOTEL_DELETED", "hotelId=$id")
    }

    private fun validName(name: String): String {
        val clean = name.trim()
        if (clean.length !in 2..80) throw AppException(R.string.err_hotel_name)
        return clean
    }
}
