package com.hoteltips.data.remote

data class TipCreateRequest(
    val hotel_id: String,
    val room_number: String? = null,
    val amount: Double,
    val currency: String = "USD",
    val guest_name: String? = null,
    val message: String? = null,
    val employee_id: String? = null
)

data class TipRemoteResponse(
    val id: Int,
    val hotel_id: String,
    val room_number: String?,
    val amount: Double,
    val currency: String,
    val guest_name: String?,
    val message: String?,
    val payment_status: String,
    val created_at: String,
    val employee_id: String? = null
)