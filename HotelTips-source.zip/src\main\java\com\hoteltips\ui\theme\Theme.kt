package com.hoteltips.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Navy = Color(0xFF0A1826)
val NavySurface = Color(0xFF11293D)
val NavyBorder = Color(0xFF1F4560)
val Teal = Color(0xFF2FB8C4)
val HeaderStart = Color(0xFF1B9DB0)
val HeaderEnd = Color(0xFF5DD6CB)
val Mint = Color(0xFF7DEFD0)
val Cyan = Color(0xFF29C3F2)
val TextMuted = Color(0xFF9DB4C6)
val Danger = Color(0xFFFF7A7A)

private val HotelColorScheme = darkColorScheme(
    primary = Teal,
    onPrimary = Navy,
    secondary = Mint,
    onSecondary = Navy,
    tertiary = Cyan,
    onTertiary = Navy,
    background = Navy,
    onBackground = Color.White,
    surface = NavySurface,
    onSurface = Color.White,
    surfaceVariant = NavySurface,
    onSurfaceVariant = TextMuted,
    surfaceContainerLowest = Navy,
    surfaceContainerLow = NavySurface,
    surfaceContainer = NavySurface,
    surfaceContainerHigh = NavySurface,
    surfaceContainerHighest = NavyBorder,
    outline = NavyBorder,
    outlineVariant = NavyBorder,
    error = Danger,
    onError = Navy,
    errorContainer = Color(0xFF4A2326),
    onErrorContainer = Color(0xFFFFD9D9)
)

private val HotelTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 32.sp, lineHeight = 38.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 16.sp)
)

object AppShapes {
    val card = RoundedCornerShape(22.dp)
    val header = RoundedCornerShape(24.dp)
    val pill = RoundedCornerShape(50)
    val small = RoundedCornerShape(14.dp)
}

@Composable
fun HotelTipsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = HotelColorScheme,
        typography = HotelTypography,
        content = content
    )
}
