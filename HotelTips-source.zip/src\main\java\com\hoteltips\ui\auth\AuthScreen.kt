package com.hoteltips.ui.auth

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hoteltips.R
import com.hoteltips.demo.DemoData
import com.hoteltips.di.AppContainer
import com.hoteltips.domain.model.City
import com.hoteltips.domain.model.Country
import com.hoteltips.domain.model.Hotel
import com.hoteltips.domain.model.RoomQrPayload
import com.hoteltips.ui.common.AppCard
import com.hoteltips.ui.common.EmptyState
import com.hoteltips.ui.common.GradientHeader
import com.hoteltips.ui.common.LanguageButton
import com.hoteltips.ui.common.LanguageCards
import com.hoteltips.ui.common.LanguageChips
import com.hoteltips.ui.common.LocalAppLanguage
import com.hoteltips.ui.common.SelectCard
import com.hoteltips.ui.common.TwoColumnGrid
import com.hoteltips.ui.common.asString
import com.hoteltips.ui.common.placeLabel
import com.hoteltips.ui.common.vmFactory
import com.hoteltips.ui.theme.Mint
import com.hoteltips.ui.theme.NavyBorder
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

@Composable
fun AuthRoot(
    container: AppContainer,
    needsSetup: Boolean,
    initialQrCode: String? = null,
    onInitialQrHandled: () -> Unit = {}
) {
    val vm: AuthViewModel = viewModel(
        key = if (needsSetup) "auth-setup" else "auth",
        factory = vmFactory {
            AuthViewModel(
                initialMode = if (needsSetup) AuthMode.SETUP else AuthMode.LOGIN,
                auth = container.authRepository,
                hotels = container.hotelRepository,
                registerGuest = container.registerGuest,
                createInitialAdmin = container.createInitialAdmin,
                enterGuestFromQr = container.enterGuestFromQr,
                session = container.sessionRepository,
                currentLanguage = container.currentLanguage,
                qrSigner = container.qrSigner
            )
        }
    )
    val state by vm.state.collectAsStateWithLifecycle()
    androidx.compose.runtime.LaunchedEffect(initialQrCode, needsSetup) {
        if (!needsSetup && !initialQrCode.isNullOrBlank()) {
            vm.onQrScanned(initialQrCode)
            onInitialQrHandled()
        }
    }
    AuthScreen(
        state = state,
        callbacks = AuthCallbacks(
            onLoginChange = vm::onLoginChange,
            onPasswordChange = vm::onPasswordChange,
            onConfirmChange = vm::onConfirmChange,
            onNameChange = vm::onNameChange,
            onRoomChange = vm::onRoomChange,
            onToggleMode = vm::onToggleMode,
            onSelectCountry = vm::onSelectCountry,
            onSelectCity = vm::onSelectCity,
            onSelectHotel = vm::onSelectHotel,
            onNext = vm::onNext,
            onBack = vm::onBack,
            onSubmit = vm::onSubmit,
            onQrScanned = vm::onQrScanned,
            onQrScanFailed = vm::onQrScanFailed,
            onConfirmQrGuest = vm::onConfirmQrGuest,
            onDismissQr = vm::onDismissQr,
            onDismissQrError = vm::onDismissQrError
        )
    )
}

class AuthCallbacks(
    val onLoginChange: (String) -> Unit,
    val onPasswordChange: (String) -> Unit,
    val onConfirmChange: (String) -> Unit,
    val onNameChange: (String) -> Unit,
    val onRoomChange: (String) -> Unit,
    val onToggleMode: () -> Unit,
    val onSelectCountry: (String) -> Unit,
    val onSelectCity: (String) -> Unit,
    val onSelectHotel: (Long) -> Unit,
    val onNext: () -> Unit,
    val onBack: () -> Unit,
    val onSubmit: () -> Unit,
    val onQrScanned: (String) -> Unit,
    val onQrScanFailed: () -> Unit,
    val onConfirmQrGuest: (String) -> Unit,
    val onDismissQr: () -> Unit,
    val onDismissQrError: () -> Unit
)

@Composable
fun AuthScreen(state: AuthUiState, callbacks: AuthCallbacks) {
    Column(
        modifier = Modifier
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AuthHeader(state)

        when (state.mode) {
            AuthMode.LOGIN -> {
                LanguageChips(Modifier.fillMaxWidth())
                LoginCard(state, callbacks)
                DemoData.hint?.let { hint ->
                    AppCard {
                        Text("Demo (debug only)", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            hint,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            AuthMode.SETUP -> {
                LanguageChips(Modifier.fillMaxWidth())
                SetupCard(state, callbacks)
            }
            AuthMode.REGISTER -> RegistrationFlow(state, callbacks)
        }
    }

    state.pendingQr?.let { payload ->
        QrGuestConfirmationDialog(
            payload = payload,
            hotelName = state.hotels.firstOrNull { it.id == payload.hotelId }?.name,
            isSubmitting = state.isQrSubmitting,
            error = state.qrError,
            onConfirm = callbacks.onConfirmQrGuest,
            onDismiss = callbacks.onDismissQr
        )
    } ?: state.qrError?.let { error ->
        AlertDialog(
            onDismissRequest = callbacks.onDismissQrError,
            title = { Text(stringResource(R.string.qr_error_title)) },
            text = { Text(error.asString()) },
            confirmButton = {
                TextButton(onClick = callbacks.onDismissQrError) {
                    Text(stringResource(R.string.action_close))
                }
            }
        )
    }
}

@Composable
private fun AuthHeader(state: AuthUiState) {
    GradientHeader {
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(R.string.app_name),
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                stringResource(
                    when (state.mode) {
                        AuthMode.REGISTER -> R.string.auth_register_title
                        AuthMode.SETUP -> R.string.auth_setup_title
                        AuthMode.LOGIN -> R.string.auth_tagline
                    }
                ),
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.92f)
            )
        }
        LanguageButton()
    }
}

// ---------------------------------------------------------------- вход / настройка

@Composable
private fun LoginCard(state: AuthUiState, c: AuthCallbacks) {
    AppCard {
        Text(stringResource(R.string.auth_login_title), style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            LoginField(state.login, c.onLoginChange)
            PasswordField(R.string.field_password, state.password, c.onPasswordChange)
        }
        ErrorText(state)
        Spacer(Modifier.height(16.dp))
        SubmitButton(stringResource(R.string.action_login), state.isLoading, true, c.onSubmit)
        QrScannerButton(
            enabled = !state.isLoading,
            onScanned = c.onQrScanned,
            onFailure = c.onQrScanFailed
        )
        TextButton(onClick = c.onToggleMode, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.auth_to_register))
        }
    }
}

@Composable
private fun SetupCard(state: AuthUiState, c: AuthCallbacks) {
    AppCard {
        Text(stringResource(R.string.auth_setup_card_title), style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text(
            stringResource(R.string.auth_setup_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = state.displayName,
                onValueChange = c.onNameChange,
                label = { Text(stringResource(R.string.field_your_name)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            LoginField(state.login, c.onLoginChange)
            PasswordField(R.string.field_password, state.password, c.onPasswordChange)
            PasswordField(R.string.field_confirm_password, state.confirmPassword, c.onConfirmChange)
            Text(
                stringResource(R.string.password_hint),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        ErrorText(state)
        Spacer(Modifier.height(16.dp))
        SubmitButton(stringResource(R.string.action_create_admin), state.isLoading, true, c.onSubmit)
    }
}

// ---------------------------------------------------------------- регистрация гостя

@Composable
private fun RegistrationFlow(state: AuthUiState, c: AuthCallbacks) {
    val total = RegStep.entries.size
    val index = state.step.ordinal

    // Индикатор шагов
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            RegStep.entries.forEach { step ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .background(
                            if (step.ordinal <= index) Mint else NavyBorder,
                            MaterialTheme.shapes.small
                        )
                )
            }
        }
        Text(
            stringResource(R.string.step_of, index + 1, total),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    AnimatedContent(
        targetState = state.step,
        transitionSpec = {
            val forward = targetState.ordinal >= initialState.ordinal
            val dir = if (forward) 1 else -1
            (slideInHorizontally(tween(260)) { dir * it / 4 } + fadeIn(tween(260))) togetherWith
                (slideOutHorizontally(tween(200)) { -dir * it / 4 } + fadeOut(tween(200)))
        },
        label = "registration-step"
    ) { step ->
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            when (step) {
                RegStep.LANGUAGE -> LanguageStep()
                RegStep.COUNTRY -> CountryStep(state, c)
                RegStep.CITY -> CityStep(state, c)
                RegStep.HOTEL -> HotelStep(state, c)
                RegStep.DETAILS -> DetailsStep(state, c)
            }
        }
    }

    // Кнопки навигации
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = c.onBack,
            modifier = Modifier
                .weight(1f)
                .height(50.dp)
        ) {
            Text(
                stringResource(if (index == 0) R.string.action_to_login else R.string.action_back)
            )
        }
        if (state.step == RegStep.DETAILS) {
            Box(Modifier.weight(1.4f)) {
                SubmitButton(stringResource(R.string.action_create_account), state.isLoading, true, c.onSubmit)
            }
        } else {
            Button(
                onClick = c.onNext,
                enabled = state.canGoNext,
                modifier = Modifier
                    .weight(1.4f)
                    .height(50.dp)
            ) {
                Text(stringResource(R.string.action_next), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun StepTitle(@androidx.annotation.StringRes title: Int, @androidx.annotation.StringRes hint: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(stringResource(title), style = MaterialTheme.typography.titleLarge)
        Text(
            stringResource(hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun LanguageStep() {
    StepTitle(R.string.step_language_title, R.string.step_language_hint)
    LanguageCards()
}

@Composable
private fun CountryStep(state: AuthUiState, c: AuthCallbacks) {
    val lang = LocalAppLanguage.current.code
    StepTitle(R.string.step_country_title, R.string.step_country_hint)
    if (state.countries.isEmpty()) {
        NoHotels(state.hotelsLoaded)
        return
    }
    TwoColumnGrid(state.countries) { country: Country ->
        SelectCard(
            selected = country.code == state.countryCode,
            onClick = { c.onSelectCountry(country.code) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(country.flag, fontSize = 36.sp)
            Text(
                country.name.forLanguage(lang),
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            Text(
                "${country.currency.code} ${country.currency.symbol}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun CityStep(state: AuthUiState, c: AuthCallbacks) {
    val lang = LocalAppLanguage.current.code
    val country = state.countryCode?.let { com.hoteltips.domain.model.Geo.country(it) }
    StepTitle(R.string.step_city_title, R.string.step_city_hint)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        state.cities.forEach { city: City ->
            SelectCard(
                selected = city.code == state.cityCode,
                onClick = { c.onSelectCity(city.code) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(country?.flag.orEmpty(), fontSize = 26.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            city.name.forLanguage(lang),
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White
                        )
                        Text(
                            stringResource(R.string.hotels_count, state.hotelsInCity(city.code)),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HotelStep(state: AuthUiState, c: AuthCallbacks) {
    val lang = LocalAppLanguage.current.code
    StepTitle(R.string.step_hotel_title, R.string.step_hotel_hint)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        state.cityHotels.forEach { hotel: Hotel ->
            SelectCard(
                selected = hotel.id == state.hotelId,
                onClick = { c.onSelectHotel(hotel.id) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🏨", fontSize = 28.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            hotel.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White
                        )
                        Text(
                            "${hotel.country?.flag.orEmpty()} ${hotel.placeLabel(lang)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailsStep(state: AuthUiState, c: AuthCallbacks) {
    val lang = LocalAppLanguage.current
    StepTitle(R.string.step_details_title, R.string.step_details_hint)

    // Сводка выбора
    state.selectedHotel?.let { hotel ->
        AppCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🏨", fontSize = 28.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(hotel.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${hotel.country?.flag.orEmpty()} ${hotel.placeLabel(lang.code)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(lang.flag, fontSize = 26.sp)
            }
        }
    }

    AppCard {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = state.displayName,
                onValueChange = c.onNameChange,
                label = { Text(stringResource(R.string.field_your_name)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = state.room,
                onValueChange = c.onRoomChange,
                label = { Text(stringResource(R.string.field_room)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            LoginField(state.login, c.onLoginChange)
            PasswordField(R.string.field_password, state.password, c.onPasswordChange)
            PasswordField(R.string.field_confirm_password, state.confirmPassword, c.onConfirmChange)
            Text(
                stringResource(R.string.password_hint),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        ErrorText(state)
    }
}

@Composable
private fun NoHotels(loaded: Boolean) {
    if (!loaded) return
    AppCard {
        EmptyState(
            title = stringResource(R.string.no_hotels_title),
            hint = stringResource(R.string.no_hotels_hint)
        )
    }
}

// ---------------------------------------------------------------- общие элементы формы

@Composable
private fun LoginField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(stringResource(R.string.field_login)) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun PasswordField(
    @androidx.annotation.StringRes label: Int,
    value: String,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(stringResource(label)) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun ErrorText(state: AuthUiState) {
    val error = state.error ?: return
    Spacer(Modifier.height(10.dp))
    Text(
        error.asString(),
        color = MaterialTheme.colorScheme.error,
        style = MaterialTheme.typography.bodyMedium
    )
}

@Composable
private fun SubmitButton(text: String, loading: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled && !loading,
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.onPrimary
            )
        } else {
            Text(text, fontWeight = FontWeight.Bold)
        }
    }
}


/** Opens the Google Play services QR UI; camera permission and camera preview are managed there. */
@Composable
private fun QrScannerButton(
    enabled: Boolean,
    onScanned: (String) -> Unit,
    onFailure: () -> Unit
) {
    val context = LocalContext.current
    OutlinedButton(
        onClick = {
            val activity = context.findActivity()
            if (activity == null) {
                onFailure()
            } else {
                val options = GmsBarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                    .build()
                GmsBarcodeScanning.getClient(activity, options)
                    .startScan()
                    .addOnSuccessListener { barcode ->
                        val value = barcode.rawValue
                        if (value.isNullOrBlank()) onFailure() else onScanned(value)
                    }
                    .addOnCanceledListener { /* Cancelling the camera is not an error. */ }
                    .addOnFailureListener { onFailure() }
            }
        },
        enabled = enabled,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("▦  ${stringResource(R.string.auth_scan_qr)}")
    }
}

@Composable
private fun QrGuestConfirmationDialog(
    payload: RoomQrPayload,
    hotelName: String?,
    isSubmitting: Boolean,
    error: com.hoteltips.domain.common.UiText?,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val defaultName = stringResource(R.string.qr_default_guest_name)
    var displayName by rememberSaveable(payload.hotelId, payload.roomNumber) {
        mutableStateOf(defaultName)
    }
    AlertDialog(
        onDismissRequest = { if (!isSubmitting) onDismiss() },
        title = { Text(stringResource(R.string.qr_dialog_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(stringResource(R.string.qr_dialog_description))
                Text(
                    stringResource(
                        R.string.qr_room_summary,
                        hotelName ?: stringResource(R.string.qr_hotel_id_label, payload.hotelId),
                        payload.roomNumber
                    ),
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it.take(50) },
                    label = { Text(stringResource(R.string.qr_guest_name_label)) },
                    singleLine = true,
                    enabled = !isSubmitting,
                    modifier = Modifier.fillMaxWidth()
                )
                if (error != null) {
                    Text(
                        text = error.asString(),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !isSubmitting,
                onClick = { onConfirm(displayName) }
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    Text(stringResource(R.string.qr_continue))
                }
            }
        },
        dismissButton = {
            TextButton(enabled = !isSubmitting, onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel))
            }
        }
    )
}

private fun Context.findActivity(): Activity? {
    var context = this
    while (context is ContextWrapper) {
        if (context is Activity) return context
        context = context.baseContext
    }
    return null
}
