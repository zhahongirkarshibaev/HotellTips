package com.hoteltips.data.remote
object ApiConfig {
    const val BASE_URL = "https://api.lavishtip.com"
    const val CONNECT_TIMEOUT_SEC = 15L
    const val READ_TIMEOUT_SEC = 20L

    /** Временный ключ для разработки. Смени на длинную случайную строку. */
    const val API_KEY = "ht_live_dfjnirufheroufsdvnlkvdoi4534cje90jij03923es"
}