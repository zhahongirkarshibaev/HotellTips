package com.hoteltips.data.payment

import com.hoteltips.domain.model.PaymentReceipt
import com.hoteltips.domain.model.PaymentRequest
import com.hoteltips.domain.model.PaymentStatus
import com.hoteltips.domain.model.PaymentSimulationOutcome
import com.hoteltips.domain.repository.PaymentGateway
import kotlinx.coroutines.delay
import java.util.UUID

class FakePaymentGateway : PaymentGateway {

    override suspend fun charge(
        request: PaymentRequest
    ): Result<PaymentReceipt> {
        return try {
            require(request.amount > 0) {
                "Payment amount must be positive"
            }

            require(request.method.supports(request.touristCountry)) {
                "Payment method is not available for this market"
            }

            delay(700)

            val status = when (request.outcome) {
                PaymentSimulationOutcome.APPROVED ->
                    PaymentStatus.APPROVED

                PaymentSimulationOutcome.DECLINED ->
                    PaymentStatus.DECLINED

                PaymentSimulationOutcome.CANCELLED ->
                    PaymentStatus.CANCELLED
            }

            val reference = "SIM-" +
                    UUID.randomUUID().toString()
                        .replace("-", "")
                        .take(10)
                        .uppercase()

            Result.success(
                PaymentReceipt(
                    reference = reference,
                    status = status,
                    amount = request.amount,
                    currencyCode = request.currencyCode,
                    touristCountry = request.touristCountry,
                    method = request.method,
                    isSimulation = true
                )
            )
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
