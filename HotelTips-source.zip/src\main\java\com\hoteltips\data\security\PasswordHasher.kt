package com.hoteltips.data.security

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Хранение паролей:
 *  1. PBKDF2-HMAC-SHA256, индивидуальная соль 16 байт, [ITERATIONS] итераций — замедляет перебор;
 *  2. результат дополнительно подписывается HMAC-ключом из Android Keystore («перец»).
 *     Даже если файл БД будет скопирован целиком, подобрать пароли без ключа Keystore
 *     этого устройства невозможно — ключ не извлекается.
 *  3. Сравнение выполняется за постоянное время (MessageDigest.isEqual).
 *
 * Формат строки в БД: `v1$итерации$соль$хеш` — итерации можно повышать в будущем,
 * старые записи будут пересчитаны при следующем входе (см. [needsRehash]).
 * Расшифровать пароль из этой строки невозможно — для него не существует обратной операции.
 */
class PasswordHasher(private val keystore: KeystoreManager) {

    fun hash(password: String): String {
        val salt = ByteArray(SALT_BYTES).also { SecureRandom().nextBytes(it) }
        val digest = derive(password, salt, ITERATIONS)
        return listOf(VERSION, ITERATIONS.toString(), b64(salt), b64(digest)).joinToString(SEP)
    }

    fun verify(password: String, encoded: String): Boolean {
        val parts = encoded.split(SEP)
        if (parts.size != 4 || parts[0] != VERSION) return false
        val iterations = parts[1].toIntOrNull() ?: return false
        if (iterations < MIN_ACCEPTED_ITERATIONS) return false
        val salt = runCatching { Base64.decode(parts[2], Base64.NO_WRAP) }.getOrNull() ?: return false
        val expected = runCatching { Base64.decode(parts[3], Base64.NO_WRAP) }.getOrNull() ?: return false
        return MessageDigest.isEqual(derive(password, salt, iterations), expected)
    }

    fun needsRehash(encoded: String): Boolean {
        val iterations = encoded.split(SEP).getOrNull(1)?.toIntOrNull() ?: return true
        return iterations < ITERATIONS
    }

    private fun derive(password: String, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, iterations, KEY_BITS)
        try {
            val derived = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec).encoded
            return keystore.hmac(derived)
        } finally {
            spec.clearPassword()
        }
    }

    private fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)

    private companion object {
        const val VERSION = "v1"
        const val SEP = "$"
        const val ITERATIONS = 310_000
        const val MIN_ACCEPTED_ITERATIONS = 100_000
        const val SALT_BYTES = 16
        const val KEY_BITS = 256
    }
}
