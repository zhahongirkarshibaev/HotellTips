package com.hoteltips.data.repository

import com.hoteltips.R
import com.hoteltips.data.local.AppDatabase
import com.hoteltips.data.local.entity.FeedbackEntity
import com.hoteltips.data.mapper.toDomain
import com.hoteltips.data.security.AuditLogger
import com.hoteltips.data.security.guardedFlow
import com.hoteltips.domain.common.AppException
import com.hoteltips.domain.common.safeCall
import com.hoteltips.domain.model.Feedback
import com.hoteltips.domain.model.NewFeedback
import com.hoteltips.domain.model.Role
import com.hoteltips.domain.repository.FeedbackRepository
import com.hoteltips.domain.security.AccessGuard
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant

class FeedbackRepositoryImpl(
    db: AppDatabase,
    private val guard: AccessGuard,
    private val audit: AuditLogger
) : FeedbackRepository {

    private val dao = db.feedbackDao()
    private val employeeDao = db.employeeDao()

    override suspend fun add(feedback: NewFeedback): Result<Unit> = safeCall {
        val guest = guard.requireRole(Role.GUEST)
        if (feedback.guestUserId != guest.id || feedback.roomNumber != guest.roomNumber) {
            throw AppException(R.string.err_no_access)
        }
        val employee = employeeDao.findById(feedback.employeeId)
            ?: throw AppException(R.string.err_employee_not_found)
        if (employee.hotelId != guest.hotelId || feedback.roomNumber !in employee.roomFrom..employee.roomTo) {
            throw AppException(R.string.err_not_serving_room)
        }
        val now = Instant.now().toEpochMilli()
        // Защита от спама: не более 5 обращений в час.
        if (dao.countByGuestSince(guest.id, now - HOUR_MS) >= MAX_PER_HOUR) {
            throw AppException(R.string.err_feedback_rate)
        }
        dao.insert(
            FeedbackEntity(
                employeeId = feedback.employeeId,
                guestUserId = feedback.guestUserId,
                roomNumber = feedback.roomNumber,
                type = feedback.type,
                text = feedback.text,
                languageCode = feedback.languageCode,
                createdAt = now
            )
        )
        audit.log(guest.id, "FEEDBACK_SENT", "type=${feedback.type}")
    }

    override fun observeForEmployee(employeeId: Long): Flow<List<Feedback>> =
        guard.guardedFlow(
            fallback = emptyList(),
            allow = { user ->
                user.role == Role.ADMIN ||
                    (user.role == Role.EMPLOYEE && employeeDao.findById(employeeId)?.userId == user.id)
            }
        ) { dao.observeForEmployee(employeeId).map { list -> list.map { it.toDomain() } } }

    private companion object {
        const val HOUR_MS = 60L * 60 * 1000
        const val MAX_PER_HOUR = 5
    }
}
