package com.hoteltips.ui.common

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.hoteltips.R
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

/** «сегодня» / «вчера» / «3 дн. назад» / дата — на языке интерфейса. */
@Composable
fun Instant.relativeDay(): String {
    val zone = ZoneId.systemDefault()
    val date = atZone(zone).toLocalDate()
    val days = ChronoUnit.DAYS.between(date, LocalDate.now(zone))
    return when {
        days <= 0L -> stringResource(R.string.time_today)
        days == 1L -> stringResource(R.string.time_yesterday)
        days < 7L -> stringResource(R.string.time_days_ago, days.toInt())
        else -> DateTimeFormatter.ofPattern("dd.MM.yyyy").format(date)
    }
}
