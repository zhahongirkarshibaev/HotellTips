package com.hoteltips.data.payment

import com.hoteltips.domain.model.PaymentReceipt
import com.hoteltips.domain.model.PaymentRequest
import com.hoteltips.domain.model.PaymentSimulationOutcome
import com.hoteltips.domain.model.PaymentStatus
import com.hoteltips.domain.repository.PaymentGateway
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import java.util.Locale
import java.util.UUID

/**
 * Local-only payment simulator. It performs no network requests and never asks for card data.
 * Replace this binding only after the payment provider and its server-side flow are selected.
 */
class SimulatedPaymentGateway(
    private val responseDelayMillis: Long = 650L
) : PaymentGateway {

    override suspend fun charge(request: PaymentRequest): Result<PaymentReceipt> {
        return try {
            require(request.amount > 0) { "Simulation amount must be positive" }
            require(request.currencyCode.matches(Regex("^[A-Z]{3}$"))) { "Invalid currency code" }
            require(request.method.supports(request.touristCountry)) {
                "Payment method is not available for this demo market"
            }
            require(responseDelayMillis >= 0) { "Delay cannot be negative" }

            if (responseDelayMillis > 0) delay(responseDelayMillis)

            val status = when (request.outcome) {
                PaymentSimulationOutcome.APPROVED -> PaymentStatus.APPROVED
                PaymentSimulationOutcome.DECLINED -> PaymentStatus.DECLINED
                PaymentSimulationOutcome.CANCELLED -> PaymentStatus.CANCELLED
            }
            val shortId = UUID.randomUUID().toString().replace("-", "")
                .take(10).uppercase(Locale.ROOT)

            Result.success(
                PaymentReceipt(
                    reference = "SIM-$shortId",
                    status = status,
                    amount = request.amount,
                    currencyCode = request.currencyCode,
                    touristCountry = request.touristCountry,
                    method = request.method,
                    isSimulation = true
                )
            )
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: IllegalArgumentException) {
            Result.failure(error)
        } catch (error: Exception) {
            Result.failure(error)
        }
    }
}
