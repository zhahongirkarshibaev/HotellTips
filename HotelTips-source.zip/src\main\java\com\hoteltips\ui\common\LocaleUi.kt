package com.hoteltips.ui.common

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hoteltips.R
import com.hoteltips.domain.model.AppLanguage
import com.hoteltips.ui.theme.Teal
import com.hoteltips.util.LocaleHelper

/** Текущий язык интерфейса — доступен любому экрану. */
val LocalAppLanguage = staticCompositionLocalOf { AppLanguage.ENGLISH }

private fun Context.findActivity(): Activity? {
    var ctx: Context = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

/** Сохраняет язык и пересоздаёт Activity. ViewModel и введённые данные при этом сохраняются. */
fun switchLanguage(context: Context, language: AppLanguage) {
    val activity = context.findActivity() ?: return
    if (LocaleHelper.current(activity) == language) return
    LocaleHelper.save(activity, language)
    activity.recreate()
}

/** Кнопка с флагом текущего языка (для шапок). По нажатию — выбор языка. */
@Composable
fun LanguageButton(modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    val current = LocalAppLanguage.current
    TextButton(onClick = { open = true }, modifier = modifier) {
        Text(current.flag, fontSize = 22.sp)
    }
    if (open) LanguageDialog(onDismiss = { open = false })
}

@Composable
fun LanguageDialog(onDismiss: () -> Unit) {
    val current = LocalAppLanguage.current
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.language_title)) },
        text = {
            Column {
                AppLanguage.entries.forEach { lang ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onDismiss()
                                switchLanguage(context, lang)
                            }
                            .padding(vertical = 12.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(lang.flag, fontSize = 24.sp)
                        Spacer(Modifier.width(14.dp))
                        Text(
                            lang.nativeName,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f)
                        )
                        if (lang == current) {
                            Text("✓", color = Teal, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) }
        }
    )
}

/** Выбор языка крупными карточками (для регистрации). */
@Composable
fun LanguageCards(modifier: Modifier = Modifier) {
    val current = LocalAppLanguage.current
    val context = LocalContext.current
    TwoColumnGrid(items = AppLanguage.entries, modifier = modifier) { lang ->
        SelectCard(
            selected = lang == current,
            onClick = { switchLanguage(context, lang) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(lang.flag, fontSize = 36.sp)
            Text(
                lang.nativeName,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
        }
    }
}

/** Компактный выбор языка чипами — для экрана входа. */
@Composable
fun LanguageChips(modifier: Modifier = Modifier) {
    val current = LocalAppLanguage.current
    val context = LocalContext.current
    Row(
        modifier = modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AppLanguage.entries.forEach { lang ->
            androidx.compose.material3.FilterChip(
                selected = lang == current,
                onClick = { switchLanguage(context, lang) },
                label = { Text("${lang.flag} ${lang.nativeName}", maxLines = 1) }
            )
        }
    }
}
